<?php

namespace App\Services;

use App\Analyzer\AnalyzerRegistry;
use App\Analyzer\ContractAnalyzer;
use App\Exception\MissingErpDataException;
use App\MessageBuilder\EmailMessageBuilder;
use App\Producer\EmailMessageProducer;
use App\Repository\EmailRepository;
use Exception;
use OldSound\RabbitMqBundle\RabbitMq\ConsumerInterface;
use PhpAmqpLib\Message\AMQPMessage;
use Psr\Log\LoggerInterface;
use Sfk\MailRouterMessages\Model\TemplateDesigner\EmailType;
use Sfk\MailRouterMessages\Serializer\TemplateDesigner\EmailMessageSerializer;
use Sfk\MailRouterMessages\Services\JsonSchemaService;

/**
 * Class ContractConsumerService.
 *
 * Listen contracts updates (and events)
 */
class ContractConsumerService implements ConsumerInterface
{
    /**
     * Field used in maxwell message for current object data.
     */
    public const MESSAGE_DATA_KEY = 'data';

    /**
     * Field used in maxwell message for database.
     */
    public const MESSAGE_DATABASE_KEY = 'database';

    /**
     * Field used in maxwell message for table.
     */
    public const MESSAGE_TABLE_KEY = 'table';

    /**
     * Field used in maxwell message for type.
     */
    public const MESSAGE_TYPE_KEY = 'type';

    /**
     * Field used in maxwell message to give details of updated data.
     */
    public const MESSAGE_OLD_KEY = 'old';

    public const EXCHANGE_ROUTING_KEY_AUTOMATIC = 'automatic';

    /**
     * @var AnalyzerRegistry
     */
    protected $analyzerRegistry;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var EmailMessageBuilder
     */
    private $emailMessageBuilder;

    /**
     * @var EmailMessageProducer
     */
    private $emailMessageProducer;

    /**
     * @var EmailRepository
     */
    private $emailRepository;

    /**
     * ContractConsumerService constructor.
     *
     * @param AnalyzerRegistry     $analyzerRegistry
     * @param EmailMessageBuilder  $emailMessageBuilder
     * @param EmailMessageProducer $emailMessageProducer
     * @param EmailRepository      $emailRepository
     * @param LoggerInterface      $logger
     */
    public function __construct(AnalyzerRegistry $analyzerRegistry, EmailMessageBuilder $emailMessageBuilder, EmailMessageProducer $emailMessageProducer, EmailRepository $emailRepository, LoggerInterface $logger)
    {
        $this->analyzerRegistry = $analyzerRegistry;
        $this->logger = $logger;
        $this->emailMessageBuilder = $emailMessageBuilder;
        $this->emailMessageProducer = $emailMessageProducer;
        $this->emailRepository = $emailRepository;
    }

    /**
     * @param AMQPMessage $msg
     *
     * @return bool|mixed
     *
     * @throws \Throwable
     */
    public function execute(AMQPMessage $msg)
    {
        $message = json_decode($msg->getBody(), true);

        if (!$this->isValidBinlogMessage($message)) {
            $this->logger->error('Analyze error', ['message' => 'Message received does not contain minimal binlog attributes']);

            return true;
        }

        $databaseName = $message[self::MESSAGE_DATABASE_KEY] ?? '';
        $tableName = $message[self::MESSAGE_TABLE_KEY] ?? '';
        $typeName = $message[self::MESSAGE_TYPE_KEY] ?? '';
        $currentData = $message[self::MESSAGE_DATA_KEY] ?? [];
        $oldData = $message[self::MESSAGE_OLD_KEY] ?? [];
        $dataId = $message[self::MESSAGE_DATA_KEY]['id'] ?? -1;

        $category = $this->inferContractCategoryCode($typeName, $tableName);

        try {
            /** @var ContractAnalyzer $analyzer */
            $analyzer = $this->analyzerRegistry->getAnalyzer($tableName);
            $contractId = $currentData[$analyzer->getIdentifier()];
            $usefulData = $analyzer->getUsefulData($typeName, $currentData, $oldData);

            if (!empty($usefulData)) {
                $contract = $analyzer->analyze(['contract_id' => $contractId, 'type' => $typeName]);
                if ($contract) {
                    // @todo Push contract to another queue from which we shall retrieve matching templates
                    $matchingTemplates = $this->emailRepository->findMatchingTemplates($contract, $analyzer->getTypeOfAct(), $category);
                    foreach ($matchingTemplates as $matchingTemplate) {
                        try {
                            $message = $this->emailMessageBuilder->buildData($matchingTemplate, $contract, EmailType::AUTOMATIC);
                            $jsonSchemaService = new JsonSchemaService();
                            $messageSerializer = new EmailMessageSerializer($jsonSchemaService);
                            $jsonMessage = $messageSerializer->serialize($message);
                            $this->emailMessageProducer->publish($jsonMessage, self::EXCHANGE_ROUTING_KEY_AUTOMATIC);
                        } catch (\Exception $e) {
                            $this->logger->error(sprintf('Error when sending the email : %s', $e->getMessage()));
                        }
                    }
                }
            }
        } catch (MissingErpDataException $exception) {
            $this->logger->error(
                'Analyzer error : bad or missing ERP data. Message not delivered',
                [
                    'database' => $databaseName,
                    'table' => $tableName,
                    'type' => $typeName,
                    'id' => $dataId,
                    'exception' => $exception,
                ]
            );

            return true;
        } catch (Exception $exception) {
            // @todo Implement retry process
            $this->logger->error(
                'Analyzer error : message not delivered',
                [
                    'database' => $databaseName,
                    'table' => $tableName,
                    'type' => $typeName,
                    'id' => $dataId,
                    'exception' => $exception,
                ]
            );

            return false;
        }

        $this->logger->info(
            'Analyze done.',
            [
                'database' => $databaseName,
                'table' => $tableName,
                'type' => $typeName,
                'id' => $dataId,
            ]
        );

        return true;
    }

    /**
     * Simply check if message has valid minimal binlog properties.
     *
     * @param array $message
     *
     * @return bool
     */
    protected function isValidBinlogMessage(array $message): bool
    {
        $isValid = isset($message[self::MESSAGE_DATABASE_KEY]);
        $isValid = $isValid && isset($message[self::MESSAGE_TABLE_KEY]);
        $isValid = $isValid && isset($message[self::MESSAGE_DATA_KEY]);
        $isValid = $isValid && isset($message[self::MESSAGE_TYPE_KEY]);

        return $isValid;
    }

    /**
     * @param $typeName
     * @param $tableName
     *
     * @return string|null
     */
    protected function inferContractCategoryCode($typeName, $tableName): ?string
    {
        if ('insert' === $typeName && false === strpos($tableName, '_events')) {
            return 'SIGN';
        }

        return null;
    }
}
