<?php

namespace App\Services;

use App\Entity\ContractPackage;
use App\Entity\TypeOfAct;
use Doctrine\ORM\EntityManagerInterface;

/**
 * Class ContractPackageService.
 */
class ContractPackageService
{
    /**
     * @var EntityManagerInterface
     */
    private $entityManager;

    /**
     * ContractStatusService constructor.
     *
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param TypeOfAct $type
     * @param array     $ids
     *
     * @return array
     */
    protected function getAllByTypeAndIds(TypeOfAct $type, array $ids = [])
    {
        if (empty($ids)) {
            return [];
        }

        return $this
            ->entityManager
            ->getRepository(ContractPackage::class)
            ->getAllByTypeAndIds($type, $ids, 'erpId');
    }

    /**
     * @param TypeOfAct $type
     * @param array     $packages
     */
    public function resetContractPackagesFromErpService(TypeOfAct $type, array $packages = [])
    {
        $erpPackages = [];
        foreach ($packages as $package) {
            $erpPackages[$package->getId()] = $package;
        }

        $existingPackages = $this->getAllByTypeAndIds($type, array_keys($erpPackages));

        foreach ($erpPackages as $packageId => $package) {
            if (!isset($existingPackages[$packageId])) {
                $newContractPackage = new ContractPackage();
                $newContractPackage->setTypeOfAct($type);
                $newContractPackage->setErpId($package->getId());
            } else {
                $newContractPackage = $existingPackages[$packageId];
            }

            $newContractPackage->setName($package->getName());
            $this->entityManager->persist($newContractPackage);
        }
        $this->entityManager->flush();
    }
}
