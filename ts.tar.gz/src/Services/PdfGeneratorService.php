<?php

namespace App\Services;

use App\Entity\Template;
use App\Entity\TemplateInterface;
use ErrorException;
use JsonSchema\Exception\InvalidSchemaException;
use Sfk\Lib\ErpClient\ApiException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Error\SyntaxError;

/**
 * Class PdfGeneratorService.
 */
class PdfGeneratorService
{
    /**
     * @var TemplateService
     */
    private $templateService;
    /**
     * @var HtmlToPdfClient
     */
    private $htmlToPdfClient;
    /**
     * @var JsonSchemaService
     */
    private $schemaService;

    /**
     * PdfGeneratorService constructor.
     *
     * @param TemplateService   $templateService
     * @param HtmlToPdfClient   $htmlToPdfClient
     * @param JsonSchemaService $schemaService
     */
    public function __construct(TemplateService $templateService, HtmlToPdfClient $htmlToPdfClient, JsonSchemaService $schemaService)
    {
        $this->templateService = $templateService;
        $this->htmlToPdfClient = $htmlToPdfClient;
        $this->schemaService = $schemaService;
    }

    /**
     * @param TemplateInterface $template
     * @param string            $data     Data in JSON format
     * @param string            $filename
     *
     * @return JsonResponse|Response
     *
     * @throws ApiException
     * @throws LoaderError
     * @throws SyntaxError
     */
    public function generate(TemplateInterface $template, string $data, string $filename)
    {
        /* @var Template $template */
        try {
            $this->schemaService->validate($data, $template->getJsonSchema());
        } catch (InvalidSchemaException $e) {
            return new JsonResponse(['message' => sprintf('Invalid schema. JSON does not validate due to violations : %s', $e->getMessage())], JsonResponse::HTTP_BAD_REQUEST);
        }

        try {
            $context = $this->templateService->getContextData($template, json_decode($data, true));
            $html = $this->templateService->render($template, TemplateService::TEMPLATE_MODE_RAW, $context);
        } catch (ErrorException | RuntimeError $e) {
            return new JsonResponse($e->getMessage(), JsonResponse::HTTP_BAD_REQUEST);
        }

        try {
            $response = $this->htmlToPdfClient->convert($html, $filename);
            $statusCode = $response->getStatusCode();
            if ($statusCode < 200 || $statusCode > 299) {
                return new Response('Htmltopdf response: '.$response->getBody(), $statusCode);
            }

            return new Response($response->getBody(), $response->getStatusCode(), $response->getHeaders());
        } catch (\Exception $ex) {
            return new Response($ex->getMessage(), Response::HTTP_BAD_REQUEST);
        }
    }
}
