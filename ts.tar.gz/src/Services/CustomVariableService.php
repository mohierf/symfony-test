<?php

namespace App\Services;

use App\Entity\CustomVariable;
use App\Entity\TemplateInterface;
use App\Repository\CustomVariableRepository;

/**
 * Class CustomVariableService.
 */
class CustomVariableService
{
    /**
     * @var CustomVariableRepository
     */
    private $customVariableRepository;

    /**
     * CustomVariableService constructor.
     *
     * @param CustomVariableRepository $customVariableRepository
     */
    public function __construct(CustomVariableRepository $customVariableRepository)
    {
        $this->customVariableRepository = $customVariableRepository;
    }

    /**
     * @param CustomVariable $customVariable
     *
     * @return array
     */
    public function getTemplatesByCustomVariable(CustomVariable $customVariable): array
    {
        return $this->customVariableRepository->findTemplatesByCustomVariable($customVariable);
    }

    /**
     * @param TemplateInterface $template
     *
     * @return array
     */
    public function getCustomVariablesNamesIndexedByDisplayName(TemplateInterface $template): array
    {
        $list = [];
        $customVariables = $this->getCustomVariablesByTemplate($template);
        /** @var CustomVariable $customVariable */
        foreach ($customVariables as $customVariable) {
            $list[$customVariable->displayName()] = $customVariable->__toString();
        }

        return $list;
    }

    /**
     * @param TemplateInterface $template
     *
     * @return array
     */
    public function getCustomVariablesDisplayNamesIndexedByStoreName(TemplateInterface $template): array
    {
        $list = [];
        $customVariables = $this->getCustomVariablesByTemplate($template);
        /** @var CustomVariable $customVariable */
        foreach ($customVariables as $customVariable) {
            $list[$customVariable->getStoreName()] = $customVariable->displayName();
        }

        return $list;
    }

    /**
     * @param TemplateInterface $template
     *
     * @return array
     */
    public function getCustomVariablesByTemplate(TemplateInterface $template): array
    {
        return $this->customVariableRepository->findCustomVariablesByTemplate($template);
    }

    /**
     * @param TemplateInterface $template
     *
     * @return array
     */
    public function getCustomVariablesNamesIndexedByStoreName(TemplateInterface $template): array
    {
        $list = [];
        $customVariables = $this->getCustomVariablesByTemplate($template);
        /** @var CustomVariable $customVariable */
        foreach ($customVariables as $customVariable) {
            $list[$customVariable->getStoreName()] = $customVariable->__toString();
        }

        return $list;
    }

    /**
     * @param TemplateInterface $template
     *
     * @return array
     */
    public function getCustomVariablesContents(TemplateInterface $template): array
    {
        $list = [];
        $customVariables = $this->getCustomVariablesByTemplate($template);
        /** @var CustomVariable $customVariable */
        foreach ($customVariables as $customVariable) {
            $list[$customVariable->getStoreName()] = $customVariable->getEmbeddedContent();
        }

        return $list;
    }

    /**
     * @param string $html
     *
     * @return string|string[]|null
     */
    public function transformCustomVariableDisplayNameToStoreName(string $html)
    {
        return preg_replace('/{{ (cv\d*)_[^}]*}}/', '{{ \1 }}', $html);
    }
}
