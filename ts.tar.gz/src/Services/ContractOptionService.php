<?php

namespace App\Services;

use App\Entity\ContractOption;
use App\Entity\TypeOfAct;
use Doctrine\ORM\EntityManagerInterface;

/**
 * Class ContractOptionService.
 */
class ContractOptionService
{
    /**
     * @var EntityManagerInterface
     */
    private $entityManager;

    /**
     * ContractStatusService constructor.
     *
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param TypeOfAct $type
     * @param array     $options
     */
    public function resetContractOptionsFromErpService(TypeOfAct $type, array $options = []): void
    {
        $erpOptions = [];

        foreach ($options as $option) {
            $erpOptions[$option->getId()] = $option;
        }

        $existingOptions = $this->getAllByTypeAndIds($type, array_keys($erpOptions));

        foreach ($erpOptions as $optionId => $option) {
            if (!isset($existingOptions[$optionId])) {
                $newContractOption = new ContractOption();
                $newContractOption->setTypeOfAct($type);
                $newContractOption->setErpId($option->getId());
            } else {
                $newContractOption = $existingOptions[$optionId];
            }

            $newContractOption->setName($option->getName());
            $this->entityManager->persist($newContractOption);
        }

        $this->entityManager->flush();
    }

    /**
     * @param TypeOfAct $type
     * @param array     $ids
     *
     * @return array
     */
    protected function getAllByTypeAndIds(TypeOfAct $type, array $ids = []): array
    {
        if (empty($ids)) {
            return [];
        }

        return $this
            ->entityManager
            ->getRepository(ContractOption::class)
            ->getAllByTypeAndIds($type, $ids, 'erpId');
    }
}
