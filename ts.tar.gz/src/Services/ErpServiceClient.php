<?php

namespace App\Services;

use App\Entity\Email;
use App\Entity\TemplateInterface;
use App\Entity\TypeOfAct;
use GuzzleHttp\Client;
use Sfk\ErpClientBundle\Services\ClientRegistryInterface;
use Sfk\ErpClientBundle\Services\ClientRegistryTrait;

/**
 * Class ErpServiceClient.
 */
class ErpServiceClient implements ClientRegistryInterface
{
    use ClientRegistryTrait;

    const API = 'api/template-designer/';

    /** @var Client */
    protected $client;

    /** @var string */
    protected $token;

    /**
     * @var RetryService
     */
    protected $retryService;

    /**
     * ErpServiceClient constructor.
     *
     * @param Client $client
     * @param $token
     * @param RetryService $retryService
     */
    public function __construct(Client $client, $token, RetryService $retryService)
    {
        $this->client = $client;
        $this->token = $token;
        $this->retryService = $retryService;
    }

    /**
     * @param $query
     * @param $body
     *
     * @return \Psr\Http\Message\ResponseInterface
     *
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    protected function getCountResultsByPostProtocol($query, $body)
    {
        return $this->client->request(
            'POST',
            self::API.$query.'?itemsPerPage=0&partial=false', [
                'headers' => [
                    'content-type' => 'application/ld+json',
                    'accept' => 'application/ld+json',
                    'X-AUTH-TOKEN' => $this->token,
                ],
                'body' => $body,
            ]
        );
    }

    /**
     * Return "paginated" contracts by type from erp-service.
     *
     * @param Email $template
     * @param int   $page
     * @param int   $limit
     * @param array $rules
     *
     * @return array
     *
     * @throws \Exception
     */
    public function getContractsForTemplateDesigner(Email $template, int $page, int $limit, array $rules)
    {
        $erpClientApi = $this->getErpClient()->getAppApi();
        $type = $template->getTypeOfAct()->getName();
        $methodCollection = sprintf('get%sForTemplateDesignerAppCollection', ucfirst($type));

        if (!method_exists($erpClientApi, $methodCollection)) {
            throw new \Exception(sprintf(
                'Method "%s" not found in object "%s". Please, check Contract type.',
                $methodCollection,
                get_class($erpClientApi)
            ));
        }

        return $this->retryService->callRetry(function () use ($erpClientApi, $methodCollection, $page, $limit, $rules) {
            $params = [
                'page' => $page,
                'items_per_page' => $limit,
                'rules' => $rules,
            ];

            return $erpClientApi->$methodCollection($params);
        });
    }

    /**
     * @param TemplateInterface $template
     * @param array             $rules
     *
     * @return int
     *
     * @throws \Exception
     */
    public function getContractCountForTemplate(TemplateInterface $template, array $rules): int
    {
        $apiByType = [
            TypeOfAct::INSURANCE => 'insurance-contract',
            TypeOfAct::PRIVILEGE => 'privilege-contract',
            TypeOfAct::WEBSITE => 'website-contract',
        ];

        $type = $template->getTypeOfAct()->getName();
        if (!isset($apiByType[$type])) {
            throw new \Exception(sprintf('Invalid type "%s"', $type));
        }

        $query = $apiByType[$type];
        $result = $this->retryService->callRetry(function () use ($query, $rules) {
            return $this->getCountResultsByPostProtocol($query, json_encode($rules));
        });

        $decoded = json_decode($result->getBody()->getContents(), true);

        if (!isset($decoded['hydra:totalItems'])) {
            throw new \Exception('"hydra:totalItems" not found in API result.');
        }

        return (int) $decoded['hydra:totalItems'];
    }
}
