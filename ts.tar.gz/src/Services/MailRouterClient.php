<?php

namespace App\Services;

use Doctrine\ORM\EntityManagerInterface;
use GuzzleHttp\Client;

/**
 * Class MailRouterClient.
 */
class MailRouterClient
{
    const SEND_EMAIL_URI = 'smtp/email';

    /**
     * @var EntityManagerInterface
     */
    private $mailRouterClient;

    /**
     * MailRouterClient constructor.
     *
     * @param Client $mailRouterClient
     */
    public function __construct(Client $mailRouterClient)
    {
        $this->mailRouterClient = $mailRouterClient;
    }

    /**
     * @param array $data
     */
    public function sendEmail(array $data)
    {
        $this->mailRouterClient->post(self::SEND_EMAIL_URI, [
                'headers' => [
                    'content-type' => 'application/json',
                    'accept' => 'application/json',
                ],
                'body' => json_encode($data),
            ]
        );
    }
}
