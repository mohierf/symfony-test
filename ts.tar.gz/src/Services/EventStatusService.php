<?php

namespace App\Services;

use App\Entity\EventStatus;
use App\Entity\TypeOfAct;
use Doctrine\ORM\EntityManagerInterface;

/**
 * Class EventStatusService.
 */
class EventStatusService
{
    /**
     * @var EntityManagerInterface
     */
    private $entityManager;

    /**
     * ContractPaymentStatusService constructor.
     *
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param TypeOfAct $type
     * @param array     $statuses
     *
     * @return array
     */
    protected function getAllByStatusesAndType(TypeOfAct $type, array $statuses = [])
    {
        if (empty($statuses)) {
            return [];
        }

        return $this
            ->entityManager
            ->getRepository(EventStatus::class)
            ->getAllByStatusesAndType($type, $statuses, 'status');
    }

    /**
     * @param TypeOfAct $type
     * @param array     $statuses
     */
    public function resetEventStatusesFromErpService(TypeOfAct $type, array $statuses = [])
    {
        $erpStatuses = [];
        foreach ($statuses as $status) {
            $erpStatuses[$status->getStatus()] = $status;
        }

        $existingStatuses = $this->getAllByStatusesAndType($type, array_keys($erpStatuses));

        foreach ($erpStatuses as $statusString => $status) {
            if (!isset($existingStatuses[$statusString])) {
                $newEventStatus = new EventStatus();
                $newEventStatus->setTypeOfAct($type);
            } else {
                $newEventStatus = $existingStatuses[$statusString];
            }

            $newEventStatus->setStatus($status->getStatus());
            $this->entityManager->persist($newEventStatus);
        }
        $this->entityManager->flush();
    }
}
