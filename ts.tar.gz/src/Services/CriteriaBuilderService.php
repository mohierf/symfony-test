<?php

namespace App\Services;

use App\Entity\Company;
use App\Entity\ContractStatus;
use App\Entity\Country;
use App\Entity\CriteriaHolderInterface;
use App\Entity\Document;
use App\Entity\Email;
use App\Entity\EventStatus;
use App\Entity\EventType;
use App\Entity\Language;
use App\Entity\ObjectAgencyLinkInterface;
use App\Model\Scope\ScopeOperator;
use Doctrine\ORM\PersistentCollection;
use Exception;

/**
 * Class CriteriaBuilderService.
 */
class CriteriaBuilderService
{
    /**
     * @param Email|Document|CriteriaHolderInterface $entity
     *
     * @return array
     *
     * @throws \Exception
     */
    public function getRules(CriteriaHolderInterface $entity): array
    {
        return [
            'table' => $entity->getTypeOfAct()->getName(),
            'search' => $this->prepareSearchCriteria($entity),
        ];
    }

    /**
     * $search[] = ['eq' => ['column' => 'company', 'value' => $this->getScope()->getCompany()->getId()]]
     * $search[] = ScopeOperator::addOperator('=', [$this->getScope()->getCompany()->getId()], 'company');
     * $search[] = ScopeOperator::eq('company', $this->getScope()->getCompany()->getId());.
     *
     * @param CriteriaHolderInterface $entity
     *
     * @return array
     *
     * @throws \Exception
     */
    protected function prepareSearchCriteria(CriteriaHolderInterface $entity): array
    {
        $search = [];

        foreach ($entity->getCriteriaList() as $criteria) {
            $method = 'prepareSearchCriteria'.ucfirst($criteria);

            if (!method_exists(__CLASS__, $method)) {
                throw new Exception(sprintf('The required method "%s" does not exist for %s', $method, get_class($this)));
            }

            if ($searchPart = $this->$method($entity)) {
                $search[] = $searchPart;
            }
        }

        return ScopeOperator::and($search);
    }

    /**
     * Duration with now.
     *
     * @param string   $column
     * @param int|null $durationMin Number of months
     * @param int|null $durationMax Number of months
     *
     * @return array|null
     *
     * @throws \Exception
     */
    public function criteriaDuration(string $column, ?int $durationMin, ?int $durationMax): ?array
    {
        $dateMin = (int) $durationMin > 0
            ? (new \DateTime('now'))->sub(new \DateInterval('P'.$durationMin.'M'))
            : '';

        $dateMax = (int) $durationMax > 0
            ? (new \DateTime('now'))->sub(new \DateInterval('P'.$durationMax.'M'))
            : '';

        return $this->criteriaDate($column, $dateMin, $dateMax, 0, 0);
    }

    /**
     * Compute date criteria.
     *
     * @param string         $column
     * @param \DateTime|null $beginDate
     * @param \DateTime|null $endDate
     * @param int|null       $min
     * @param int|null       $max
     *
     * @return array|null
     *
     * @throws \Exception
     */
    public function criteriaDate(string $column, ?\DateTime $beginDate, ?\DateTime $endDate, ?int $min, ?int $max): ?array
    {
        if (null === $beginDate) {
            $hasBegin = false;
        } else {
            $beginDate = new \DateTime($beginDate);
            $hasBegin = true;
        }

        if (null === $endDate) {
            $hasEnd = false;
        } else {
            $endDate = new \DateTime($endDate);
            $hasEnd = true;
        }

        if ($hasBegin && $hasEnd) {
            $search = ScopeOperator::between(
                $column,
                $beginDate->format('Y-m-d'),
                $endDate->format('Y-m-d'),
                ScopeOperator::TYPE_DATETIME
            );
        } elseif ($hasBegin) {
            $search = ScopeOperator::gte($column, $hasBegin, ScopeOperator::TYPE_DATETIME);
        } elseif ($hasEnd) {
            $search = ScopeOperator::lte($column, $hasEnd, ScopeOperator::TYPE_DATETIME);
        } else {
            $search = $this->criteriaRangeDayAfter($column, null, $min, $max);
        }

        return $search;
    }

    /**
     * Duration with now.
     *
     * @param string      $column
     * @param string|null $date
     * @param int|null    $min    Number of days
     * @param int|null    $max    Number of days
     *
     * @return array
     *
     * @throws \Exception
     */
    public function criteriaRangeDayAfter(string $column, ?string $date, ?int $min, ?int $max): array
    {
        $search = [];
        if (max([$min, $max]) > 0) {
            $begin = new \DateTime($date);
            $end = new \DateTime($begin->format('Y-m-d'));
            if ($min > 0) {
                if ($max > 0) {
                    $search = ScopeOperator::between(
                        $column,
                        $begin->sub(new \DateInterval('P'.$max.'D'))->format('Y-m-d'),
                        $end->sub(new \DateInterval('P'.$min.'D'))->format('Y-m-d'),
                        ScopeOperator::TYPE_DATETIME
                    );
                } else {
                    $search = ScopeOperator::lte($column, $end->sub(new \DateInterval('P'.$min.'D'))->format('Y-m-d'), ScopeOperator::TYPE_DATETIME);
                }
            } else {
                $search = ScopeOperator::gte($column, $begin->sub(new \DateInterval('P'.$max.'D'))->format('Y-m-d'), ScopeOperator::TYPE_DATETIME);
            }
        }

        return $search;
    }

    /**
     * @param Email|Document|CriteriaHolderInterface $entity
     *
     * @return array
     */
    protected function prepareSearchCriteriaCompany(CriteriaHolderInterface $entity): array
    {
        if (($company = $entity->getCompany()) && ($company instanceof Company)) {
            return ['table' => 'company', 'search' => ScopeOperator::eq('id', $company->getErpId(), ScopeOperator::TYPE_INTEGER)];
        }

        return [];
    }

    /**
     * @param Email|Document|CriteriaHolderInterface $entity
     *
     * @return array
     */
    protected function prepareSearchCriteriaLanguage(CriteriaHolderInterface $entity): array
    {
        if (($language = $entity->getLanguage()) && ($language instanceof Language)) {
            return ['table' => 'agencyLanguage', 'search' => ScopeOperator::eq('id', $language->getErpId(), ScopeOperator::TYPE_INTEGER)];
        }

        return [];
    }

    /**
     * @param Email|Document|CriteriaHolderInterface $entity
     *
     * @return array
     */
    protected function prepareSearchCriteriaCountry(CriteriaHolderInterface $entity): array
    {
        if (($country = $entity->getCountry()) && ($country instanceof Country)) {
            return ['table' => 'clientCountry', 'search' => ScopeOperator::eq('id', $country->getErpId(), ScopeOperator::TYPE_INTEGER)];
        }

        return [];
    }

    /**
     * @param Email|Document|CriteriaHolderInterface $entity
     *
     * @return array
     *
     * @throws \Exception
     */
    protected function prepareSearchCriteriaContractStatuses(CriteriaHolderInterface $entity): array
    {
        $search = [];

        foreach ($entity->getContractStatuses() as $contractStatus) {
            $searchParts = [];

            /** @var ContractStatus $status */
            $status = $contractStatus->getContractStatus();
            $searchParts[] = ScopeOperator::eq('status', $status->getStatus());

            $searchParts[] = $this->criteriaMinMax(
                'statusModificationDatetime',
                $contractStatus->getMinDelaySinceStatusChange(),
                $contractStatus->getMaxDelaySinceStatusChange()
            );

            $search[] = $this->combineRulesWithOperator($searchParts);
        }

        return !empty($search) ? ['table' => 'self', 'search' => ScopeOperator::or($search)] : [];
    }

    /**
     * @param string   $column
     * @param int|null $min    Number of days
     * @param int|null $max    Number of days
     *
     * @return array|null
     *
     * @throws \Exception
     */
    public function criteriaMinMax(string $column, ?int $min, ?int $max): ?array
    {
        return $this->criteriaDate($column, null, null, $min, $max);
    }

    /**
     * Combine multiple rules with an operator operator. Empty rules are ignored.
     *
     * @param array  $rules
     * @param string $operator
     *
     * @return array
     */
    public function combineRulesWithOperator(array $rules, $operator = ScopeOperator::AND_FUNCTION): array
    {
        $rulesWithoutEmptyElements = array_filter(
            $rules,
            function ($element) {
                return !empty($element) && [] !== $element;
            }
        );

        if (count($rulesWithoutEmptyElements) > 1) {
            $search = ScopeOperator::{$operator}($rulesWithoutEmptyElements);
        } else {
            $search = $rulesWithoutEmptyElements[0];
        }

        return $search;
    }

    /**
     * @param Email|Document|CriteriaHolderInterface $entity
     *
     * @return array
     *
     * @throws \Exception
     */
    protected function prepareSearchCriteriaContractEvents(CriteriaHolderInterface $entity): array
    {
        $search = [];

        foreach ($entity->getContractEvents() as $event) {
            $searchParts = [];

            /** @var EventType $eventType */
            $eventType = $event->getEventType();
            $searchParts[] = ScopeOperator::eq('type', $eventType->getErpId(), ScopeOperator::TYPE_INTEGER);

            /** @var EventStatus $eventStatus */
            $eventStatus = $event->getEventStatus();
            $searchParts[] = ScopeOperator::eq('status', $eventStatus->getStatus());

            $searchParts[] = $this->criteriaMinMax(
                'creation',
                $event->getMinDelaySinceEventCreation(),
                $event->getMaxDelaySinceEventCreation()
            );

            $search[] = $this->combineRulesWithOperator($searchParts);
        }

        return !empty($search) ? ['table' => 'event', 'search' => ScopeOperator::or($search)] : [];
    }

    /**
     * @param Email|Document|CriteriaHolderInterface $entity
     *
     * @return array
     */
    protected function prepareSearchCriteriaPackages(CriteriaHolderInterface $entity): array
    {
        foreach ($entity->getPackages() as $package) {
            $searchParts[] = ScopeOperator::eq('id', $package->getErpId(), ScopeOperator::TYPE_INTEGER);
        }

        return !empty($searchParts) ? ['table' => 'package', 'search' => $this->combineRulesWithOperator($searchParts, ScopeOperator::OR_FUNCTION)] : [];
    }

    /**
     * @param Email|Document|CriteriaHolderInterface $entity
     *
     * @return array
     */
    protected function prepareSearchCriteriaPaymentStatuses(CriteriaHolderInterface $entity): array
    {
        foreach ($entity->getPaymentStatuses() as $paymentStatus) {
            $searchParts[] = ScopeOperator::eq('paymentStatus', $paymentStatus->getStatus());
        }

        return !empty($searchParts) ? ['table' => 'self', 'search' => $this->combineRulesWithOperator($searchParts, ScopeOperator::OR_FUNCTION)] : [];
    }

    /**
     * @param Email|Document|CriteriaHolderInterface $entity
     *
     * @return array
     */
    protected function prepareSearchCriteriaAgencies(CriteriaHolderInterface $entity): array
    {
        $search = [];
        $agencies = [];

        /** @var PersistentCollection $collectionAgencies */
        $collectionAgencies = $entity->getAgencies();
        $fullAgencies = $collectionAgencies->toArray();

        foreach ($fullAgencies as $agency) {
            if ($agency instanceof ObjectAgencyLinkInterface) {
                $agencies[$agency->getType()][] = $agency->getAgency()->getErpId();
            }
        }

        if (!empty($agencies[ObjectAgencyLinkInterface::TYPE_AGENCY])) {
            $search[] = $this->criteriaAgency('agency', $agencies[ObjectAgencyLinkInterface::TYPE_AGENCY]);
        }
        if (!empty($agencies[ObjectAgencyLinkInterface::TYPE_MAIN_AGENCY])) {
            $search[] = $this->criteriaAgency('mainAgency', $agencies[ObjectAgencyLinkInterface::TYPE_MAIN_AGENCY]);
        }
        if (!empty($agencies[ObjectAgencyLinkInterface::TYPE_GROUP_AGENCY])) {
            $search[] = $this->criteriaAgency('groupAgency', $agencies[ObjectAgencyLinkInterface::TYPE_GROUP_AGENCY]);
        }

        return !empty($search) ? ['table' => 'agencies', 'search' => ScopeOperator::or($search)] : [];
    }

    /**
     * @param string     $column
     * @param array|null $agencies
     *
     * @return array
     */
    protected function criteriaAgency(string $column, ?array $agencies): array
    {
        return ScopeOperator::in($column, $agencies, ScopeOperator::TYPE_INTEGER);
    }
}
