<?php

namespace App\Services;

use App\Entity\Agency;
use Doctrine\ORM\EntityManagerInterface;
use Sfk\Lib\ErpClient\Model\AgencyRead;

/**
 * Class AgencyService.
 */
class AgencyService
{
    /**
     * @var EntityManagerInterface
     */
    private $entityManager;

    /**
     * AgencyService constructor.
     *
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param array $ids
     *
     * @return array|mixed
     */
    protected function getAgenciesByIds(array $ids = [])
    {
        if (empty($ids)) {
            return [];
        }

        return $this
            ->entityManager
            ->getRepository(Agency::class)
            ->getAllByIds($ids, 'erpId');
    }

    /**
     * Create or update an agency
     * Create relations with main and group agencies if needed.
     *
     * @param array $erpAgencies
     * @param array $erpAgenciesLinks
     * @param array $groupAgencies
     * @param array $mainAgencies
     *
     * @return array
     */
    protected function upsertAgenciesFromErpAgencies(array $erpAgencies, array $erpAgenciesLinks = [], array $groupAgencies = [], array $mainAgencies = [])
    {
        $existingAgencies = $this->getAgenciesByIds(array_keys($erpAgencies));
        $upsertAgencies = [];
        foreach ($erpAgencies as $agencyId => $agency) {
            if (!isset($existingAgencies[$agencyId])) {
                $newAgency = new Agency();
                $newAgency->setErpId($agency->getId());
            } else {
                $newAgency = $existingAgencies[$agencyId];
            }
            $newAgency->setName($agency->getName() ?? '');

            $agencyLinks = $erpAgenciesLinks[$agency->getId()] ?? null;
            if (isset($agencyLinks['group'])) {
                $group = $agencyLinks['group'];
                $newAgency->setGroupAgency($groupAgencies[$group->getId()] ?? null);
            }
            if (isset($agencyLinks['main'])) {
                $main = $agencyLinks['main'];
                $newAgency->setMainAgency($mainAgencies[$main->getId()] ?? null);
            }

            $this->entityManager->persist($newAgency);

            // To create relations between agencies and main or group agencies,
            // We need to cache them to avoid extra db requests later.
            $upsertAgencies[$newAgency->getErpId()] = $newAgency;
        }
        $this->entityManager->flush();

        return $upsertAgencies;
    }

    /**
     * @param array $agencies
     */
    public function resetAgenciesFromErpService(array $agencies = [])
    {
        $erpAgenciesLinks = [];
        $erpAgencies = [];
        $erpMainAgencies = [];
        $erpGroupAgencies = [];

        /** @var AgencyRead $agency */
        foreach ($agencies as $agency) {
            if (null !== $agency->getMainAgency()) {
                // We need to manage the case where the main agency is the agency herself.
                // So far, the case is when all main agency fields are null.
                $main = (int) $agency->getId() === $agency->getMainAgencyId() ? $agency : $agency->getMainAgency();
                $erpMainAgencies[$main->getId()] = $main;
                $erpAgenciesLinks[$agency->getId()]['main'] = $main;
            }
            if (null !== $agency->getGroupAgency()) {
                $group = (int) $agency->getId() === $agency->getGroupAgencyId() ? $agency : $agency->getGroupAgency();
                $erpGroupAgencies[$group->getId()] = $group;
                $erpAgenciesLinks[$agency->getId()]['group'] = $group;
            }
            $erpAgencies[$agency->getId()] = $agency;
        }

        // Before saving agencies we need to save main and group Agencies
        $mainAgencies = $this->upsertAgenciesFromErpAgencies($erpMainAgencies);
        $groupAgencies = $this->upsertAgenciesFromErpAgencies($erpGroupAgencies);

        // At the end we need to save agencies and relations with main and group agencies
        $this->upsertAgenciesFromErpAgencies($erpAgencies, $erpAgenciesLinks, $groupAgencies, $mainAgencies);

        $this->entityManager->flush();
        $this->entityManager->clear();
    }
}
