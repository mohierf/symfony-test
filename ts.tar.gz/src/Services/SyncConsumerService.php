<?php

namespace App\Services;

use App\Synchronizer\SynchronizerInterface;
use App\Synchronizer\SynchronizerRegistry;
use OldSound\RabbitMqBundle\RabbitMq\ConsumerInterface;
use PhpAmqpLib\Message\AMQPMessage;
use Psr\Log\LoggerInterface;

/**
 * Class SyncConsumerService.
 */
class SyncConsumerService implements ConsumerInterface
{
    /**
     * Field used in maxwell message for current object data.
     */
    const MESSAGE_DATA_KEY = 'data';

    /**
     * Field used in maxwell message for database.
     */
    const MESSAGE_DATABASE_KEY = 'database';

    /**
     * Field used in maxwell message for table.
     */
    const MESSAGE_TABLE_KEY = 'table';

    /**
     * Field used in maxwell message for type.
     */
    const MESSAGE_TYPE_KEY = 'type';

    /**
     * @var SynchronizerRegistry
     */
    protected $synchronizerRegistry;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * SyncConsumerService constructor.
     *
     * @param SynchronizerRegistry $synchronizerRegistry
     */
    public function __construct(SynchronizerRegistry $synchronizerRegistry, LoggerInterface $logger)
    {
        $this->synchronizerRegistry = $synchronizerRegistry;
        $this->logger = $logger;
    }

    /**
     * Simply check if message has valid minimal binlog properties.
     *
     * @param array $message
     *
     * @return bool
     */
    protected function isValidBinlogMessage(array $message)
    {
        $isValid = isset($message[self::MESSAGE_DATABASE_KEY]);
        $isValid = $isValid && isset($message[self::MESSAGE_TABLE_KEY]);
        $isValid = $isValid && isset($message[self::MESSAGE_DATA_KEY]);
        $isValid = $isValid && isset($message[self::MESSAGE_TYPE_KEY]);

        return $isValid;
    }

    /**
     * @param AMQPMessage $msg
     *
     * @return bool|mixed
     */
    public function execute(AMQPMessage $msg)
    {
        $message = json_decode($msg->getBody(), true);

        if (!$this->isValidBinlogMessage($message)) {
            $this->logger->error('Synchronization error', [
                'message' => 'Message received does not contain minimal binlog attributes',
            ]);

            return true;
        }

        $databaseName = $message[self::MESSAGE_DATABASE_KEY] ?? '';
        $tableName = $message[self::MESSAGE_TABLE_KEY] ?? '';
        $typeName = $message[self::MESSAGE_TYPE_KEY] ?? '';
        $dataId = $message[self::MESSAGE_DATA_KEY]['id'] ?? -1;

        try {
            /** @var SynchronizerInterface $synchronizer */
            $synchronizer = $this->synchronizerRegistry->getSynchronizer($tableName);
            $usefulData = $synchronizer->getUsefulData($message[self::MESSAGE_DATA_KEY]);

            // We call synchronizer only if we have more data than only identifiers.
            if (!empty($usefulData)) {
                $synchronizer->synchronize([
                    'database' => $databaseName,
                    'table' => $tableName,
                    'type' => $typeName,
                    'data' => $usefulData,
                ]);
            }
        } catch (\Exception $exception) {
            $this->logger->error('Synchronization error', [
                'database' => $databaseName,
                'table' => $tableName,
                'type' => $typeName,
                'id' => $dataId,
                'exception' => $exception,
            ]);

            return false;
        }

        $this->logger->info('Synchronization done.', [
            'database' => $databaseName,
            'table' => $message['table'],
            'type' => $typeName,
            'id' => $dataId,
        ]);

        return true;
    }
}
