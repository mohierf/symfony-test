<?php

namespace App\Services;

use App\Entity\Country;
use App\Entity\Language;
use Doctrine\ORM\EntityManagerInterface;
use Sfk\Lib\ErpClient\Model\CountryRead;

/**
 * Class CountryService.
 */
class CountryService
{
    /**
     * @var EntityManagerInterface
     */
    private $entityManager;

    /**
     * CountryService constructor.
     *
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param array $ids
     *
     * @return array|mixed
     */
    protected function getCountriesByIds(array $ids = [])
    {
        if (empty($ids)) {
            return [];
        }

        return $this
            ->entityManager
            ->getRepository(Country::class)
            ->getAllByIds($ids, 'erpId');
    }

    /**
     * @param array $countries
     */
    public function resetCountriesFromErpService(array $countries = [])
    {
        $erpCountries = [];
        /** @var CountryRead $country * */
        foreach ($countries as $country) {
            $erpCountries[$country->getId()] = $country;
        }

        $existingCountries = $this->getCountriesByIds(array_keys($erpCountries));

        /** @var CountryRead $country * */
        foreach ($erpCountries as $countryId => $country) {
            if (!isset($existingCountries[$countryId])) {
                $newCountry = new Country();
                $newCountry->setErpId($country->getId());
            } else {
                /** @var Country $newCountry */
                $newCountry = $existingCountries[$countryId];
            }

            $newCountry->setCode($country->getCode());

            // We want to print a correctly translated country name to users.
            $newCountry->translate(Language::LANGUAGE_FR)->setName($country->getName());
            $newCountry->mergeNewTranslations();

            $this->entityManager->persist($newCountry);
        }

        $this->entityManager->flush();
        $this->entityManager->clear();
    }
}
