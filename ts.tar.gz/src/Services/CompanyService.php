<?php

namespace App\Services;

use App\Entity\Company;
use Doctrine\ORM\EntityManagerInterface;
use Sfk\Lib\ErpClient\Model\CompanyRead;

/**
 * Class CompanyService.
 */
class CompanyService
{
    /**
     * @var EntityManagerInterface
     */
    private $entityManager;

    /**
     * @param array $ids
     *
     * @return array|mixed
     */
    protected function getCompaniesByIds(array $ids = [])
    {
        if (empty($ids)) {
            return [];
        }

        return $this
            ->entityManager
            ->getRepository(Company::class)
            ->getAllByIds($ids, 'erpId');
    }

    /**
     * CompanyService constructor.
     *
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param array $companies
     */
    public function resetCompaniesFromErpService(array $companies = [])
    {
        $erpCompanies = [];
        foreach ($companies as $company) {
            $erpCompanies[$company->getId()] = $company;
        }

        $existingCompanies = $this->getCompaniesByIds(array_keys($erpCompanies));

        /** @var CompanyRead $company * */
        foreach ($erpCompanies as $companyId => $company) {
            if (!isset($existingCompanies[$companyId])) {
                $newCompany = new Company();
                $newCompany->setErpId($company->getId());
            } else {
                $newCompany = $existingCompanies[$companyId];
            }
            $newCompany->setName($company->getName());
            $newCompany->setCode($company->getCode() ?? '');
            $this->entityManager->persist($newCompany);
        }
        $this->entityManager->flush();
    }
}
