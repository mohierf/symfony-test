<?php

namespace App\Services;

use App\Entity\Document;
use App\Entity\Email;
use App\Entity\Template;
use App\Entity\TemplateInterface;
use App\Model\ActContext;
use App\Model\GlobalContext;
use App\Model\InsuranceContext;
use App\Model\PrivilegeContext;
use App\Model\TemplateContext;
use App\Model\WebsiteContext;
use Exception;
use Psr\Log\LoggerInterface;
use ReflectionClass;
use ReflectionException;
use RuntimeException;
use Sfk\ErpClientBundle\Services\ClientRegistryInterface;
use Sfk\ErpClientBundle\Services\ClientRegistryTrait;
use Sfk\Lib\ErpClient\ApiException;
use Symfony\Component\Translation\TranslatorInterface;
use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Error\SyntaxError;

/**
 * Class TemplateService.
 */
class TemplateService implements ClientRegistryInterface
{
    public const TEMPLATE_MODE_PREVIEW = 'template_preview';
    public const TEMPLATE_MODE_CONTENT = 'template_content';
    public const TEMPLATE_MODE_RAW = 'template_raw';

    public const GLOBAL_CONTEXT = 'global';
    public const ACT_CONTEXT = 'act';
    public const INSURANCE_CONTEXT = 'insurance';
    public const PRIVILEGE_CONTEXT = 'privilege';
    public const WEBSITE_CONTEXT = 'website';
    public const TEMPLATE_CONTEXT = 'template';

    public const CONTEXTS
        = [
            self::GLOBAL_CONTEXT,
            self::ACT_CONTEXT,
            self::INSURANCE_CONTEXT,
            self::PRIVILEGE_CONTEXT,
            self::WEBSITE_CONTEXT,
            self::TEMPLATE_CONTEXT,
        ];

    public const CONTEXT_CLASS
        = [
            self::GLOBAL_CONTEXT => GlobalContext::class,
            self::ACT_CONTEXT => ActContext::class,
            self::INSURANCE_CONTEXT => InsuranceContext::class,
            self::PRIVILEGE_CONTEXT => PrivilegeContext::class,
            self::WEBSITE_CONTEXT => WebsiteContext::class,
            self::TEMPLATE_CONTEXT => TemplateContext::class,
        ];

    /**
     * @var TranslatorInterface
     */
    private $translator;
    private $twig;
    private $logger;

    /**
     * @var JsonSchemaService
     */
    private $jsonSchemaService;

    /**
     * @var CustomVariableService
     */
    private $customVariableService;

    use ClientRegistryTrait;

    /**
     * TemplateService constructor.
     *
     * @param Environment           $twig
     * @param TranslatorInterface   $translator
     * @param LoggerInterface       $logger
     * @param JsonSchemaService     $jsonSchemaService
     * @param CustomVariableService $customVariableService
     */
    public function __construct(Environment $twig, TranslatorInterface $translator, LoggerInterface $logger, JsonSchemaService $jsonSchemaService, CustomVariableService $customVariableService)
    {
        $this->twig = $twig;
        $this->translator = $translator;
        $this->logger = $logger;
        $this->jsonSchemaService = $jsonSchemaService;
        $this->customVariableService = $customVariableService;
    }

    /**
     * @param $param
     *
     * @return array
     *
     * @throws ReflectionException
     */
    public function getTranslatedPlaceholders($param): array
    {
        $translatedPlaceholders = [];
        $placeholders = $this->getPlaceholders($param);

        foreach ($placeholders as $k => $v) {
            $translatedPlaceholders[$v] = $this->translator->trans($v, [], 'placeholders');
        }

        return $translatedPlaceholders;
    }

    /**
     * @param $param
     *
     * @return mixed
     *
     * @throws ReflectionException
     */
    public function getPlaceholders($param): array
    {
        if ($param instanceof TemplateInterface) {
            return $this->getPlaceholdersByTemplate($param);
        }

        return $this->getPlaceholdersByContextName($param);
    }

    /**
     * @param TemplateInterface $template
     *
     * @return mixed
     *
     * @throws ReflectionException
     */
    public function getPlaceholdersByTemplate(TemplateInterface $template)
    {
        $context = $this->getContextNameFromTemplate($template);
        $placeholders = $this->getPlaceholdersByContextName($context);
        /** @var Template $template */
        if (property_exists(get_class($template), 'jsonSchema') && $jsonSchema = $template->getJsonSchema()) {
            $placeholders = array_merge($placeholders, $this->jsonSchemaService->getPlaceholdersFromSchema($jsonSchema));
        }

        asort($placeholders);

        return $placeholders;
    }

    /**
     * @param TemplateInterface $template
     *
     * @return string
     *
     * @throws ReflectionException
     */
    public function getContextNameFromTemplate(TemplateInterface $template): string
    {
        /** @var Email|Document $template */
        if (property_exists($template, 'typeOfAct')) {
            $contextName = $template->getTypeOfAct() ? $template->getTypeOfAct()->getName() : null;
        } else {
            $reflect = new ReflectionClass($template);
            $contextName = strtolower($reflect->getShortName());
        }

        return $this->getContextNameFromString($contextName);
    }

    /**
     * @param string $string
     *
     * @return string
     */
    public function getContextNameFromString(?string $string): string
    {
        return in_array($string, self::CONTEXTS, true) ? $string : self::GLOBAL_CONTEXT;
    }

    /**
     * @param string $context
     *
     * @return mixed
     */
    public function getPlaceholdersByContextName(string $context)
    {
        $context = $this->getContextNameFromString($context);

        $contextClassname = self::CONTEXT_CLASS[$context];
        $placeholders = $contextClassname::getConstants();
        asort($placeholders);

        return $placeholders;
    }

    /**
     * @param TemplateInterface $template
     * @param string            $mode
     * @param null              $context
     *
     * @return false|string
     *
     * @throws LoaderError
     * @throws RuntimeError
     * @throws SyntaxError
     */
    public function render(TemplateInterface $template, $mode = self::TEMPLATE_MODE_CONTENT, $context = null)
    {
        $context = array_merge($context, $this->customVariableService->getCustomVariablesContents($template));

        return $this->twig->createTemplate($this->getHtmlSource($template, $mode))->render($context);
    }

    /**
     * @param TemplateInterface $template
     * @param string            $mode
     *
     * @return string
     *
     * @throws LoaderError
     * @throws RuntimeError
     * @throws SyntaxError
     */
    private function getHtmlSource(TemplateInterface $template, $mode = self::TEMPLATE_MODE_CONTENT): string
    {
        $html = $this->replaceLoopVariables($template->getHtml(), 'html', $template);
        $html = $this->replaceCustomVariables($html, 'html', $template);

        if (self::TEMPLATE_MODE_RAW === $mode) {
            /* @var Email|$template */
            return $this->twig->render(
                $template->getType().'/raw.html.twig',
                [
                    'css' => $template->getCss(),
                    'html' => $html,
                ]
            );
        }

        $previewData = [];

        if ((self::TEMPLATE_MODE_PREVIEW === $mode) && $template instanceof Email) {
            $subject = $this->replaceLoopVariables($template->getSubject(), 'text', $template);
            $subject = $this->replaceCustomVariables($subject, 'text', $template);
            $previewData['mail_object'] = $subject;
        }

        return $this->twig->render(
            $template->getType().'/preview.html.twig',
            [
                'css' => $template->getCss(),
                'html' => $html,
                'preview' => $previewData,
            ]
        );
    }

    /**
     * Handle loop variables.
     *
     * @param string            $string
     * @param string            $format   Could be : 'html', 'text'
     * @param TemplateInterface $template
     *
     * @return string
     */
    public function replaceLoopVariables(?string $string, string $format, TemplateInterface $template): string
    {
        if (!$string || !in_array($format, ['html', 'text'], true)) {
            return (string) $string;
        }

        // Replace variables whose name contains a special suffix with a twig for-loop structure
        // @TODO Only used with emails templates. Will disappear to be replaced by a more generic implementation (see '_handleIterableVariables' method).
        $string = $this->_handleListVariables($string, $format);

        // Replace iterables variables with a twig for-loop structure
        /** @var Template $template */
        if (property_exists(get_class($template), 'jsonSchema')
            && ($jsonSchema = $template->getJsonSchema())
            && ($iterableElements = $this->jsonSchemaService->getIterableElements($jsonSchema->getContent()))
        ) {
            $string = $this->_handleIterableVariables($string, $iterableElements);
        }

        return $string;
    }

    /**
     * @param string $string
     * @param string $format
     *
     * @return string
     */
    private function _handleListVariables(string $string, string $format): string
    {
        $replacements = [
            'list' => [
                'text' => '{{ $2|join(", ") }}',
                'html' => function () {
                    return $this->twig->load('templating/_list.html.twig')->getSourceContext()->getCode();
                },
            ],
            'listk' => [
                'text' => '{{ $2|join(", ") }}',
                'html' => function () {
                    return $this->twig->load('templating/_listk.html.twig')->getSourceContext()->getCode();
                },
            ],
        ];

        // Search for loop variables whose suffix is defined in $replacements
        $pattern = '/{{ (\w*_('.implode('|', array_keys($replacements)).')) }}/';
        preg_match_all($pattern, $string, $matches);
        [, $placeholders, $types] = $matches;

        foreach ($placeholders as $key => $placeholder) {
            $type = $types[$key];
            if (array_key_exists($type, $replacements)) {
                $string = preg_replace(
                    '/(\{\{ ('.$placeholders[$key].') \}\})/',
                    str_replace('_data', '$2', $replacements[$type][$format]()),
                    $string
                );
            }
        }

        return $string;
    }

    /**
     * @param string $string
     * @param array  $iterableElements
     * @param string $currentElement
     *
     * @return mixed|string
     */
    private function _handleIterableVariables(string $string, array $iterableElements, string $currentElement = '')
    {
        foreach ($iterableElements as $parent => $children) {
            $pattern = '/(<tr[^>]*(?:(?!<\/tr>).)*{{ ('.$parent.'\w*) }}(?:(?!<\/tr>).)*<\/tr>)/';
            preg_match($pattern, $string, $matches);

            // Search for
            if ($matches) {
                [, $original_row,] = $matches;
                $element = $parent.'Child';
                $new_row = str_replace($parent.'_', $element.'.', $original_row);

                if ('' !== $currentElement) {
                    $replacement = '{% if '.$currentElement.'.'.$parent.' is defined %}{% for '.$element.' in '.$currentElement.'.'.$parent.' %}'.$new_row.'{% endfor %}{% endif %}';
                } else {
                    $replacement = '{% if '.$parent.' is defined %}{% for '.$element.' in '.$parent.' %}'.$new_row.'{% endfor %}{% endif %}';
                }

                $string = str_replace($original_row, $replacement, $string);

                // Move children to the end of the parent block
                if ('' !== $currentElement) {
                    $pattern2 = '/({% for '.$currentElement.'(?:(?!{% endfor %}).)*)({% endfor %})/';
                    preg_match($pattern2, $string, $matches);
                    [$parentBlock, $begin, $end] = $matches;
                    $string = str_replace([$replacement, $parentBlock], ['', $begin.$replacement.$end], $string);
                }

                if ($children) {
                    $string = $this->_handleIterableVariables($string, $iterableElements[$parent], $element);
                }
            }
        }

        return $string;
    }

    /**
     * Handle loop variables.
     *
     * @param string            $string
     * @param string            $format   Could be : 'html', 'text'
     * @param TemplateInterface $template
     *
     * @return string
     */
    public function replaceCustomVariables(?string $string, string $format, TemplateInterface $template): string
    {
        if (!$string || !in_array($format, ['html', 'text'], true)) {
            return (string) $string;
        }

        $customVariables = $this->customVariableService->getCustomVariablesContents($template);
        $customVariablePattern = '/({{ (cv\d*[^}]*) }})/';
        preg_match_all($customVariablePattern, $string, $matches);

        foreach ($matches[0] as $key => $match) {
            $pattern = $matches[1][$key];
            $name = $matches[2][$key];
            $string = str_replace($pattern, $customVariables[$name], $string);
        }

        return $string;
    }

    /**
     * @param TemplateInterface $template
     * @param mixed             $data
     *
     * @return array
     *
     * @throws ApiException
     * @throws Exception
     */
    public function getContextData(TemplateInterface $template, $data = null): array
    {
        if (empty($data)) {
            return array_flip($this->getPlaceholders($template));
        }

        $context = null;
        $contextName = $this->getContextNameFromTemplate($template);
        $erpClient = $this->getErpClient();
        try {
            switch ($contextName) {
                case self::INSURANCE_CONTEXT:
                    $contract = $erpClient->getInsuranceContractApi()->getInsuranceContractItem(['id' => $data]);
                    $context = (new InsuranceContext($contract))->getContext();
                    break;
                case self::PRIVILEGE_CONTEXT:
                    $contract = $erpClient->getPrivilegeContractApi()->getPrivilegeContractItem(['id' => $data]);
                    $context = (new PrivilegeContext($contract))->getContext();
                    break;
                case self::WEBSITE_CONTEXT:
                    $contract = $erpClient->getWebsiteContractApi()->getWebsiteContractItem(['id' => $data]);
                    $context = (new WebsiteContext($contract))->getContext();
                    break;
                case self::TEMPLATE_CONTEXT:
                    $context = (new TemplateContext($data))->getContext();
                    break;
                default:
                    $context = (new GlobalContext())->getContext();
                    break;
            }
        } catch (ApiException $exception) {
            $this->logger->error(
                'Error getting contract from ERP service',
                [
                    'message' => $exception->getMessage(),
                    'file ' => $exception->getFile(),
                    'code' => $exception->getCode(),
                ]
            );
            throw $exception;
        }

        return $context;
    }

    /**
     * @param Email $template
     * @param       $context
     *
     * @return string
     *
     * @throws LoaderError
     * @throws SyntaxError
     */
    public function renderSubject(Email $template, $context): string
    {
        return $this->twig->createTemplate($this->replaceLoopVariables($template->getSubject(), 'text', $template))->render($context);
    }

    /**
     * @param TemplateInterface $template
     * @param                   $context
     *
     * @return string
     *
     * @throws LoaderError
     * @throws SyntaxError
     */
    public function renderContent(TemplateInterface $template, $context): string
    {
        $html = $this->replaceLoopVariables($template->getHtml(), 'html', $template);

        $content = '<html><head><style>'.$template->getCss().'</style></head><body>'.$html.'</body></html>';

        return $this->twig->createTemplate($content)->render($context);
    }

    /**
     * @param TemplateInterface $template
     * @param                   $contract
     *
     * @return array
     *
     * @throws Exception
     */
    public function getContext(TemplateInterface $template, $contract = null): array
    {
        try {
            $contextName = $this->getContextNameFromTemplate($template);
            $context = null;

            switch ($contextName) {
                case self::INSURANCE_CONTEXT:
                    $context = (new InsuranceContext($contract))->getContext();
                    break;
                case self::PRIVILEGE_CONTEXT:
                    $context = (new PrivilegeContext($contract))->getContext();
                    break;
                case self::WEBSITE_CONTEXT:
                    $context = (new WebsiteContext($contract))->getContext();
                    break;
                default:
                    $context = (new GlobalContext())->getContext();
                    break;
            }

            return $context;
        } catch (Exception $exception) {
            $this->logger->error(
                'Error context transformation',
                [
                    'message' => $exception->getMessage(),
                    'file ' => $exception->getFile(),
                    'code' => $exception->getCode(),
                ]
            );
            throw new RuntimeException('Error context transformation', 0, $exception);
        }
    }
}
