<?php

namespace App\Services;

use App\Entity\Language;
use Doctrine\ORM\EntityManagerInterface;
use Sfk\Lib\ErpClient\Model\LanguageRead;

/**
 * Class LanguageService.
 */
class LanguageService
{
    /**
     * @var EntityManagerInterface
     */
    private $entityManager;

    /**
     * LanguageService constructor.
     *
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param array $ids
     *
     * @return array|mixed
     */
    protected function getLanguagesByIds(array $ids = [])
    {
        if (empty($ids)) {
            return [];
        }

        return $this
            ->entityManager
            ->getRepository(Language::class)
            ->getAllByIds($ids, 'erpId');
    }

    /**
     * @param array $languages
     */
    public function resetLanguagesFromErpService(array $languages = [])
    {
        $erpLanguages = [];
        /** @var LanguageRead $language * */
        foreach ($languages as $language) {
            $erpLanguages[$language->getId()] = $language;
        }

        $existingLanguages = $this->getLanguagesByIds(array_keys($erpLanguages));

        /** @var LanguageRead $language * */
        foreach ($erpLanguages as $languageId => $language) {
            if (!isset($existingLanguages[$languageId])) {
                $newLanguage = new Language();
                $newLanguage->setErpId($language->getId());
            } else {
                $newLanguage = $existingLanguages[$languageId];
            }
            $newLanguage->setCode($language->getCode());
            $this->entityManager->persist($newLanguage);
        }

        $this->entityManager->flush();
        $this->entityManager->clear();
    }
}
