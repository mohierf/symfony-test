<?php

namespace App\Services;

use App\Entity\EventType;
use App\Entity\TypeOfAct;
use Doctrine\ORM\EntityManagerInterface;

/**
 * Class EventTypeService.
 */
class EventTypeService
{
    /**
     * @var EntityManagerInterface
     */
    private $entityManager;

    /**
     * ContractStatusService constructor.
     *
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param TypeOfAct $type
     * @param array     $eventTypes
     */
    public function resetEventTypesFromErpService(TypeOfAct $type, array $eventTypes = []): void
    {
        $erpEventTypes = [];

        foreach ($eventTypes as $eventType) {
            $erpEventTypes[$eventType->getId()] = $eventType;
        }

        $existingEventTypes = $this->getAllByTypeAndIds($type, array_keys($erpEventTypes));

        foreach ($erpEventTypes as $eventTypeId => $eventType) {
            if (!isset($existingEventTypes[$eventTypeId])) {
                $newEventType = new EventType();
                $newEventType->setTypeOfAct($type);
                $newEventType->setErpId($eventType->getId());
            } else {
                $newEventType = $existingEventTypes[$eventTypeId];
            }

            $newEventType->setName($eventType->getName());
            $this->entityManager->persist($newEventType);
        }

        $this->entityManager->flush();
    }

    /**
     * @param TypeOfAct $type
     * @param array     $ids
     *
     * @return array
     */
    protected function getAllByTypeAndIds(TypeOfAct $type, array $ids = []): array
    {
        if (empty($ids)) {
            return [];
        }

        return $this
            ->entityManager
            ->getRepository(EventType::class)
            ->getAllByTypeAndIds($type, $ids, 'erpId');
    }
}
