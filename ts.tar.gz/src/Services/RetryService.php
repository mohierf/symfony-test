<?php

namespace App\Services;

use Psr\Log\LoggerInterface;

/**
 * Class RetryService.
 */
class RetryService
{
    /**
     * How many time we want to try.
     */
    const DEFAULT_MAX_RETRY_COUNT = 5;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * RetryService constructor.
     *
     * @param LoggerInterface $logger
     */
    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    /**
     * @param callable $function
     * @param int      $maxRetry
     *
     * @throws \Exception
     */
    public function callRetry(callable $function, $maxRetry = self::DEFAULT_MAX_RETRY_COUNT)
    {
        $result = null;
        $tries = 0;
        while (true) {
            ++$tries;
            try {
                $result = $function();

                return $result;
            } catch (\Exception $exception) {
                if ($tries >= $maxRetry) {
                    throw $exception;
                }
                $this->logger->error('Sleeping... ', [
                    'message' => $exception->getMessage(),
                    'file' => $exception->getFile(),
                    'line' => $exception->getLine(),
                ]);
                sleep($tries);
            }
        }
    }
}
