<?php

namespace App\Services;

use App\Entity\ContractPaymentStatus;
use App\Entity\TypeOfAct;
use Doctrine\ORM\EntityManagerInterface;

/**
 * Class ContractPaymentStatusService.
 */
class ContractPaymentStatusService
{
    /**
     * @var EntityManagerInterface
     */
    private $entityManager;

    /**
     * ContractPaymentStatusService constructor.
     *
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @param TypeOfAct $type
     * @param array     $statuses
     *
     * @return array
     */
    protected function getAllByStatusesAndType(TypeOfAct $type, array $statuses = [])
    {
        if (empty($statuses)) {
            return [];
        }

        return $this
            ->entityManager
            ->getRepository(ContractPaymentStatus::class)
            ->getAllByStatusesAndType($type, $statuses, 'status');
    }

    /**
     * @param TypeOfAct $type
     * @param array     $statuses
     */
    public function resetContractStatusesFromErpService(TypeOfAct $type, array $statuses = [])
    {
        $erpStatuses = [];
        foreach ($statuses as $status) {
            $erpStatuses[$status->getStatus()] = $status;
        }

        $existingStatuses = $this->getAllByStatusesAndType($type, array_keys($erpStatuses));

        foreach ($erpStatuses as $statusString => $status) {
            if (!isset($existingStatuses[$statusString])) {
                $newContractStatus = new ContractPaymentStatus();
                $newContractStatus->setTypeOfAct($type);
            } else {
                $newContractStatus = $existingStatuses[$statusString];
            }

            $newContractStatus->setStatus($status->getStatus());
            $this->entityManager->persist($newContractStatus);
        }
        $this->entityManager->flush();
    }
}
