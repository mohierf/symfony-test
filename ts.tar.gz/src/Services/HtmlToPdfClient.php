<?php

namespace App\Services;

use GuzzleHttp\Client;
use Psr\Http\Message\ResponseInterface;
use Psr\Log\LoggerInterface;

/**
 * Class HtmlToPdfClient.
 */
class HtmlToPdfClient
{
    public const CONVERT_TO_PDF_URI = 'v1/convert';

    /**
     * @var Client
     */
    private $client;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * HtmlToPdfClient constructor.
     *
     * @param LoggerInterface $logger
     * @param Client          $client
     */
    public function __construct(LoggerInterface $logger, Client $client)
    {
        $this->logger = $logger;
        $this->client = $client;
    }

    /**
     * @param string $html
     * @param string $filename
     *
     * @return ResponseInterface
     *
     * @throws \Exception
     */
    public function convert(string $html, string $filename): ResponseInterface
    {
        $data = [
            'to' => 'pdf',
            'filename' => $filename,
            'data' => base64_encode($html),
            'options' => [
                'no-outline' => true,
                'page-size' => 'A4',
                'encoding' => 'UTF-8',
                'zoom' => 1,
                'viewport-size' => '1280x1024',
                'footer-right' => '[page]/[topage]',
                'footer-font-name' => 'Verdana',
                'footer-font-size' => 8,
            ],
        ];

        try {
            $response = $this->client->post(
                self::CONVERT_TO_PDF_URI,
                [
                    'headers' => [
                        'content-type' => 'application/json',
                        'accept' => 'application/json',
                    ],
                    'body' => json_encode($data),
                ]
            );

            $statusCode = $response->getStatusCode();
            if ($statusCode < 200 || $statusCode > 299) {
                $this->logger->error('htmltopdf error', ['message' => $response->getBody()->getContents()]);
            }

            return $response;
        } catch (\Exception $ex) {
            $this->logger->error('htmltopdf error', ['message' => $ex->getMessage()]);
            throw $ex;
        }
    }
}
