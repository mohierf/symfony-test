<?php

namespace App\DependencyInjection;

use App\Analyzer\AnalyzerRegistry;
use App\Producer\ProducerRegistry;
use App\Services\ErpServiceClient;
use App\Synchronizer\SynchronizerRegistry;
use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class CompilerPass implements CompilerPassInterface
{
    public const ENV_PROD = 'prod';

    /**
     * {@inheritdoc}
     */
    public function process(ContainerBuilder $container)
    {
        $env = $container->getParameter('kernel.environment');
        $synchronizerRegistry = $container->getDefinition(SynchronizerRegistry::class);
        $producerRegistry = $container->getDefinition(ProducerRegistry::class);
        $analyzerRegistry = $container->getDefinition(AnalyzerRegistry::class);

        $synchronizers = $container->getParameter('template_designer.synchronizers');
        $analyzers = $container->getParameter('template_designer.analyzers');

        foreach ($synchronizers as $synchronizer) {
            $configService = $container->getDefinition(sprintf('app.synchronizer.%s', $synchronizer['table']));
            $configService->addArgument($container->getDefinition('doctrine'));
            $synchronizerRegistry->addMethodCall('addSynchronizer', [$synchronizer['table'], $configService]);

            if (self::ENV_PROD !== $env) {
                $producerService = $container->getDefinition(sprintf('app.producer.%s', $synchronizer['table']));
                $producerService->addArgument($container->getDefinition('doctrine.orm.default_entity_manager'));
                $producerService->addArgument($container->getDefinition('old_sound_rabbit_mq.sync_queue_producer'));
                $producerService->addArgument($container->getDefinition('nelmio_alice.faker.generator'));
                $producerService->addArgument($container->getDefinition('debug.event_dispatcher'));
                $producerRegistry->addMethodCall('addProducer', [$synchronizer['table'], $producerService]);
            }
        }

        foreach ($analyzers as $analyzer) {
            $configService = $container->getDefinition(sprintf('app.analyzer.%s', $analyzer['table']));
            $configService->addArgument($container->getDefinition(ErpServiceClient::class));
            $analyzerRegistry->addMethodCall('addAnalyzer', [$analyzer['table'], $configService]);
        }
    }
}
