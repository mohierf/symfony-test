<?php

namespace App\DependencyInjection;

use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Definition;
use Symfony\Component\HttpKernel\DependencyInjection\Extension;

/**
 * Class TemplateDesignerExtension.
 */
class TemplateDesignerExtension extends Extension
{
    /**
     * {@inheritdoc}
     */
    public function load(array $configs, ContainerBuilder $container)
    {
        $configuration = new Configuration();
        $config = $this->processConfiguration($configuration, $configs);

        $this->loadSynchronizers($container, $config['synchronizers']);
        $this->loadProducers($container, $config['synchronizers']);
        $this->loadContractAnalyzers($container, $config['contract_analyzers']);
    }

    /**
     * @param ContainerBuilder $container
     * @param array            $synchronizers
     */
    protected function loadSynchronizers(ContainerBuilder $container, array $synchronizers)
    {
        foreach ($synchronizers as $synchronizer) {
            $configName = sprintf('app.synchronizer.%s', $synchronizer['table']);
            $configService = $container->setDefinition(
                $configName,
                new Definition($synchronizer['synchronizer'])
            );

            $syncedAttributes = [];
            $attributesMapping = [];
            foreach ($synchronizer['attributes'] as $attribute) {
                $rabbitField = $attribute['rabbitmq_field'];
                $syncedAttributes[] = $rabbitField;
                $attributesMapping[$rabbitField] = $attribute;
            }

            $configService->addMethodCall('setDatabaseName', [$synchronizer['database']]);
            $configService->addMethodCall('setTableName', [$synchronizer['table']]);
            $configService->addMethodCall('setSupportedEvents', [$synchronizer['events']]);
            $configService->addMethodCall('setSyncedAttributes', [$syncedAttributes]);
            $configService->addMethodCall('setIdentifiers', [$synchronizer['identifiers']]);
            $configService->addMethodCall('setAttributesMapping', [$attributesMapping]);
            $configService->addMethodCall('setModel', [$synchronizer['model']]);
        }

        $container->setParameter('template_designer.synchronizers', $synchronizers);
    }

    protected function loadProducers(ContainerBuilder $container, array $synchronizers)
    {
        foreach ($synchronizers as $synchronizer) {
            $configName = sprintf('app.producer.%s', $synchronizer['table']);
            $configService = $container->setDefinition(
                $configName,
                new Definition($synchronizer['producer'])
            );

            $syncedAttributes = array_column($synchronizer['attributes'], 'rabbitmq_field');
            $configService->addMethodCall('setDatabaseName', [$synchronizer['database']]);
            $configService->addMethodCall('setTableName', [$synchronizer['table']]);
            $configService->addMethodCall('setModel', [$synchronizer['model']]);
            $configService->addMethodCall('setSyncedAttributes', [$syncedAttributes]);
            $configService->addMethodCall('setIdentifiers', [$synchronizer['identifiers']]);
        }
    }

    /**
     * @param ContainerBuilder $container
     * @param array            $contractAnalyzers
     */
    protected function loadContractAnalyzers(ContainerBuilder $container, array $contractAnalyzers)
    {
        foreach ($contractAnalyzers as $analyzer) {
            $configName = sprintf('app.analyzer.%s', $analyzer['table']);
            $configService = $container->setDefinition(
                $configName,
                new Definition($analyzer['analyzer'])
            );

            $analyzedAttributes = [];
            foreach ($analyzer['attributes'] as $attribute) {
                $rabbitField = $attribute['rabbitmq_field'];
                $analyzedAttributes[] = $rabbitField;
            }

            $configService->addMethodCall('setDatabaseName', [$analyzer['database']]);
            $configService->addMethodCall('setTableName', [$analyzer['table']]);
            $configService->addMethodCall('setSupportedEvents', [$analyzer['events']]);
            $configService->addMethodCall('setIdentifier', [$analyzer['identifier']]);
            $configService->addMethodCall('setTypeOfAct', [$analyzer['type_of_act']]);
            $configService->addMethodCall('setAnalyzedAttributes', [$analyzedAttributes]);
        }

        $container->setParameter('template_designer.analyzers', $contractAnalyzers);
    }
}
