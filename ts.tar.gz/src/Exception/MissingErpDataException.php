<?php

namespace App\Exception;

use Exception;

/**
 * Class MissingErpDataException.
 */
class MissingErpDataException extends Exception
{
}
