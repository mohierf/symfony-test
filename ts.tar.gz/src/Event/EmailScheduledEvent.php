<?php

namespace App\Event;

use Symfony\Component\EventDispatcher\Event;

/**
 * Class EmailScheduledEvent.
 */
class EmailScheduledEvent extends Event
{
    const EMAIL_JOB_PAGINATED_STARTED = 'email_job_paginated_started';
    const EMAIL_JOB_PAGINATED_STEP = 'email_job_paginated_step';
    const EMAIL_JOB_PAGINATED_FINISHED = 'email_job_paginated_finished';
    const EMAIL_JOB_PAGINATED_ERROR = 'email_job_paginated_error';

    protected $data = [];

    public function __construct(array $data = [])
    {
        $this->data = $data;
    }

    /**
     * @return array
     */
    public function getData(): array
    {
        return $this->data;
    }
}
