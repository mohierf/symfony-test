<?php

namespace App\MessageBuilder;

use App\Entity\Email;
use App\Entity\EmailTest;
use App\Entity\TemplateInterface;
use App\Services\TemplateService;
use Sfk\Lib\ErpClient\Model\InsuranceContractRead;
use Sfk\Lib\ErpClient\Model\PrivilegeContractRead;
use Sfk\Lib\ErpClient\Model\WebsiteContractRead;
use Sfk\MailRouterMessages\Company;

/**
 * Class EmailMessageBuilder.
 */
class EmailMessageBuilder
{
    /**
     * @var TemplateService
     */
    protected $templateService;

    /**
     * EmailMessageBuilder constructor.
     *
     * @param TemplateService $templateService
     */
    public function __construct(TemplateService $templateService)
    {
        $this->templateService = $templateService;
    }

    /**
     * @param TemplateInterface $template
     * @param $contract
     * @param string $mailType
     *
     * @return array
     *
     * @throws \Twig\Error\LoaderError
     * @throws \Twig\Error\SyntaxError
     */
    public function buildData(TemplateInterface $template, $contract, string $mailType)
    {
        /** @var InsuranceContractRead|PrivilegeContractRead|WebsiteContractRead $contract */
        /** @var TemplateInterface|Email $template */
        $context = $this->templateService->getContext($template, $contract);
        $sender = [
            'name' => $template->getSender()->getName(),
            'email' => $template->getSender()->getEmail(),
        ];
        $data = [
            'version' => 1,
            'senderCompany' => Company::SFAM, // TODO : MAPPING $template->getCompany()->getCode();
            'email' => [
                'bcc' => [],
                'cc' => [],
                'replyTo' => $sender,
                'subject' => $this->templateService->renderSubject($template, $context),
                'htmlContent' => $this->templateService->renderContent($template, $context),
                'sender' => $sender,
            ],
        ];

        /** @var EmailTest $recipient */
        foreach ($template->getTestEmails() as $recipient) {
            // TODO : add real recipients
            $data['email']['to'][] = [
                'name' => null,
                'email' => $recipient->getEmail(),
            ];
        }

        $data['metadata'] = [
            'templateId' => (int) $template->getId(),
            'contractId' => (int) $contract->getId(),
            'type' => $mailType,
        ];

        $message = [
            'version' => 1,
            'creationTs' => time(),
            'publicationTs' => time(),
            'data' => $data,
        ];

        return $message;
    }
}
