<?php

namespace App\Entity;

use App\Entity\Traits\IdTrait;
use App\Entity\Traits\TimestampTrait;
use App\Entity\Traits\TypeOfActTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * ContractStatus.
 * Data is synced from BAPPLI (erp service or rabbitmq).
 *
 * @ORM\Table(name="contract_status")
 * @ORM\Entity(repositoryClass="App\Repository\ContractStatusRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class ContractStatus
{
    use IdTrait;
    use TimestampTrait;
    use TypeOfActTrait;

    /**
     * @var string
     *
     * @ORM\Column(name="status", type="string", length=255)
     */
    protected $status;

    /**
     * @var ArrayCollection|EmailContractStatus
     *
     * @ORM\OneToMany(targetEntity="App\Entity\EmailContractStatus", mappedBy="contractStatus")
     */
    protected $emailContractStatuses;

    /**
     * ContractStatus constructor.
     */
    public function __construct()
    {
        $this->emailContractStatuses = new ArrayCollection();
    }

    /**
     * @return string
     */
    public function getStatus(): ?string
    {
        return $this->status;
    }

    /**
     * @param string|null $status
     *
     * @return ContractStatus
     */
    public function setStatus(?string $status): self
    {
        $this->status = $status;

        return $this;
    }
}
