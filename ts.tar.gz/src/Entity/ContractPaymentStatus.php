<?php

namespace App\Entity;

use App\Entity\Traits\IdTrait;
use App\Entity\Traits\TimestampTrait;
use App\Entity\Traits\TypeOfActTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\ManyToMany;

/**
 * ContractPaymentStatus.
 * Data is synced from BAPPLI (erp service or rabbitmq).
 *
 * @ORM\Table(name="contract_payment_status")
 * @ORM\Entity(repositoryClass="App\Repository\ContractPaymentStatusRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class ContractPaymentStatus
{
    use IdTrait;
    use TimestampTrait;
    use TypeOfActTrait;

    /**
     * @var string
     *
     * @ORM\Column(name="status", type="string", length=255)
     */
    protected $status;

    /**
     * @var ArrayCollection
     * @ManyToMany(targetEntity="App\Entity\Email", mappedBy="paymentStatuses")
     */
    protected $emails;

    /**
     * @return string
     */
    public function getStatus(): ?string
    {
        return $this->status;
    }

    /**
     * @param string|null $status
     *
     * @return ContractPaymentStatus
     */
    public function setStatus(?string $status): self
    {
        $this->status = $status;

        return $this;
    }
}
