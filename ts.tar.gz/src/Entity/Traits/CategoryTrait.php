<?php

namespace App\Entity\Traits;

use App\Entity\Category;
use Doctrine\ORM\Mapping as ORM;

/**
 * Trait Category.
 */
trait CategoryTrait
{
    /**
     * @var Category
     * @ORM\ManyToOne(targetEntity="Category", cascade={"persist"})
     * @ORM\JoinColumn(referencedColumnName="id", nullable=true)
     */
    protected $category;

    /**
     * @return Category
     */
    public function getCategory(): ?Category
    {
        return $this->category;
    }

    /**
     * @param Category $category
     *
     * @return self
     */
    public function setCategory(?Category $category): self
    {
        $this->category = $category;

        return $this;
    }
}
