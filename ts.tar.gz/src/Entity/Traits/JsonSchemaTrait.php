<?php

namespace App\Entity\Traits;

use App\Entity\JsonSchema;

/**
 * Trait Company.
 */
trait JsonSchemaTrait
{
    /**
     * @var JsonSchema
     *
     * @ORM\ManyToOne(targetEntity="App\Entity\JsonSchema", cascade={"persist"})
     * @ORM\JoinColumn(name="json_schema_id", referencedColumnName="id")
     */
    protected $jsonSchema;

    /**
     * @return JsonSchema
     */
    public function getJsonSchema(): ?JsonSchema
    {
        return $this->jsonSchema;
    }

    /**
     * @param JsonSchema $jsonSchema
     *
     * @return JsonSchemaTrait
     */
    public function setJsonSchema(?JsonSchema $jsonSchema): self
    {
        $this->jsonSchema = $jsonSchema;

        return $this;
    }
}
