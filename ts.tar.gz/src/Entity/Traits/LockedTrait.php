<?php

namespace App\Entity\Traits;

use Doctrine\ORM\Mapping as ORM;

/**
 * Trait LockedTrait.
 */
trait LockedTrait
{
    /**
     * @var bool
     *
     * @ORM\Column(type="boolean")
     */
    protected $locked = false;

    /**
     * @return bool
     */
    public function isLocked(): ?bool
    {
        return $this->locked;
    }

    /**
     * @param bool $locked
     *
     * @return self
     */
    public function setLocked($locked): self
    {
        $this->locked = $locked;

        return $this;
    }
}
