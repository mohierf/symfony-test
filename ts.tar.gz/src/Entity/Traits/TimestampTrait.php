<?php

namespace App\Entity\Traits;

use Doctrine\ORM\Mapping as ORM;
use Sfk\StandardBundle\Entity\Traits\CreationTrait;
use Sfk\StandardBundle\Entity\Traits\LastUpdateTrait;

/**
 * Trait TimestampTrait.
 */
trait TimestampTrait
{
    use CreationTrait;
    use LastUpdateTrait;

    /**
     * @ORM\PreUpdate()
     * @ORM\PrePersist()
     */
    public function _setLastUpdateDate(): void
    {
        $this->lastUpdate = new \DateTime();
    }

    /**
     * @ORM\PrePersist()
     */
    public function _setCreationDate(): void
    {
        $this->creation = new \DateTime();
    }
}
