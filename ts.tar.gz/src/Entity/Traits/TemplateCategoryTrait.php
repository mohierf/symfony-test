<?php

namespace App\Entity\Traits;

use App\Entity\TemplateCategory;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * TemplateCategoryTrait.
 */
trait TemplateCategoryTrait
{
    /**
     * @var TemplateCategory
     *
     * @ORM\ManyToOne(targetEntity="TemplateCategory", cascade={"persist"})
     * @ORM\JoinColumn(referencedColumnName="id", nullable=true)
     *
     * @Groups({"template:read"})
     */
    protected $templateCategory;

    /**
     * @return TemplateCategory
     */
    public function getTemplateCategory(): ?TemplateCategory
    {
        return $this->templateCategory;
    }

    /**
     * @param TemplateCategory $templateCategory
     *
     * @return self
     */
    public function setTemplateCategory(?TemplateCategory $templateCategory): self
    {
        $this->templateCategory = $templateCategory;

        return $this;
    }
}
