<?php

namespace App\Entity\Traits;

use App\Entity\Country;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Trait Country.
 */
trait CountryTrait
{
    /**
     * @var Country
     *
     * @ORM\ManyToOne(targetEntity="Country", cascade={"persist"})
     * @ORM\JoinColumn(referencedColumnName="id", nullable=true)
     *
     * @Assert\NotBlank(groups={"template"})
     */
    protected $country;

    /**
     * @return Country
     */
    public function getCountry(): ?Country
    {
        return $this->country;
    }

    /**
     * @param Country $country
     *
     * @return self
     */
    public function setCountry(?Country $country): self
    {
        $this->country = $country;

        return $this;
    }
}
