<?php

namespace App\Entity\Traits;

/**
 * Trait ErpIdTrait.
 */
trait ErpIdTrait
{
    /**
     * Erp id.
     *
     * @var int
     *
     * @ORM\Column(name="erp_id", type="bigint", options={"unsigned"=true}, nullable = false)
     */
    private $erpId;

    /**
     * @return int
     */
    public function getErpId(): int
    {
        return $this->erpId;
    }

    /**
     * @param int $erpId
     *
     * @return ErpIdTrait
     */
    public function setErpId(int $erpId): self
    {
        $this->erpId = $erpId;

        return $this;
    }
}
