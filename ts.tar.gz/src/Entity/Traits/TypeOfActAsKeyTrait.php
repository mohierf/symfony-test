<?php

namespace App\Entity\Traits;

use App\Entity\TypeOfAct;
use Doctrine\ORM\Mapping as ORM;

/**
 * Trait TypeOfActAsKeyTrait.
 *
 * Use for synchronized tables that flatten multiple tables (retrieved from ERP) into one.
 */
trait TypeOfActAsKeyTrait
{
    use TypeOfActTrait;

    /**
     * @var TypeOfAct
     *
     * @ORM\ManyToOne(targetEntity="App\Entity\TypeOfAct")
     *
     * @ORM\JoinColumn(name="type_of_act_id", referencedColumnName="id", nullable=false)
     */
    protected $typeOfAct;
}
