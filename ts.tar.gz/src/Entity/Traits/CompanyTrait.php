<?php

namespace App\Entity\Traits;

use App\Entity\Company;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Trait Company.
 */
trait CompanyTrait
{
    /**
     * @var Company
     *
     * @ORM\ManyToOne(targetEntity="Company", cascade={"persist"})
     * @ORM\JoinColumn(referencedColumnName="id", nullable=true)
     *
     * @Groups({"company:read"})
     *
     * @Assert\NotBlank(groups={"template"})
     */
    protected $company;

    /**
     * @return Company
     */
    public function getCompany(): ?Company
    {
        return $this->company;
    }

    /**
     * @param Company $company
     *
     * @return static
     */
    public function setCompany(?Company $company): self
    {
        $this->company = $company;

        return $this;
    }
}
