<?php

namespace App\Entity\Traits;

use Doctrine\ORM\Mapping as ORM;

/**
 * Trait ActDateQueryTrait.
 */
trait ActDateQueryTrait
{
    /**
     * Begin Datetime.
     *
     * @var \DateTime
     *
     * @ORM\Column(name="beginDate", type="datetime", nullable=true)
     */
    protected $beginDate;

    /**
     * End Datetime.
     *
     * @var \DateTime
     *
     * @ORM\Column(name="endDate", type="datetime", nullable=true)
     */
    protected $endDate;

    /**
     * Duration min in month.
     *
     * @var int
     *
     * @ORM\Column(name="durationMin", type="integer", nullable=true)
     */
    protected $durationMin;

    /**
     * Duration max in month.
     *
     * @var int
     *
     * @ORM\Column(name="durationMax", type="integer", nullable=true)
     */
    protected $durationMax;

    /**
     * Max days after act.
     *
     * @var int
     *
     * @ORM\Column(name="maxDaysAfterAct", type="integer", nullable=true)
     */
    protected $maxDaysAfterAct;

    /**
     * Min days after act.
     *
     * @var int
     *
     * @ORM\Column(name="minDaysAfterAct", type="integer", nullable=true)
     */
    protected $minDaysAfterAct;

    /**
     * @return \DateTime
     */
    public function getBeginDate(): \DateTime
    {
        return $this->beginDate;
    }

    /**
     * @param \DateTime $beginDate
     *
     * @return self
     */
    public function setBeginDate(?\DateTime $beginDate): self
    {
        $this->beginDate = $beginDate;

        return $this;
    }

    /**
     * @return \DateTime
     */
    public function getEndDate(): \DateTime
    {
        return $this->endDate;
    }

    /**
     * @param \DateTime $endDate
     *
     * @return self
     */
    public function setEndDate(\DateTime $endDate): self
    {
        $this->endDate = $endDate;

        return $this;
    }

    /**
     * @return int
     */
    public function getDurationMin(): int
    {
        return $this->durationMin;
    }

    /**
     * @param int $durationMin
     *
     * @return self
     */
    public function setDurationMin(?int $durationMin): self
    {
        $this->durationMin = $durationMin;

        return $this;
    }

    /**
     * @return int
     */
    public function getDurationMax(): int
    {
        return $this->durationMax;
    }

    /**
     * @param int $durationMax
     *
     * @return self
     */
    public function setDurationMax(?int $durationMax): self
    {
        $this->durationMax = $durationMax;

        return $this;
    }

    /**
     * @return int
     */
    public function getMaxDaysAfterAct(): int
    {
        return $this->maxDaysAfterAct;
    }

    /**
     * @param int $maxDaysAfterAct
     *
     * @return self
     */
    public function setMaxDaysAfterAct(?int $maxDaysAfterAct): self
    {
        $this->maxDaysAfterAct = $maxDaysAfterAct;

        return $this;
    }

    /**
     * @return int
     */
    public function getMinDaysAfterAct(): int
    {
        return $this->minDaysAfterAct;
    }

    /**
     * @param int $minDaysAfterAct
     *
     * @return self
     */
    public function setMinDaysAfterAct(int $minDaysAfterAct): self
    {
        $this->minDaysAfterAct = $minDaysAfterAct;

        return $this;
    }
}
