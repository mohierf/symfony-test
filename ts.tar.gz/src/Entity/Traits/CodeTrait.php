<?php

namespace App\Entity\Traits;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Trait Code.
 */
trait CodeTrait
{
    /**
     * @var string
     *
     * @ORM\Column(name="code", type="string", length=255)
     *
     * @Groups({"code:read"})
     */
    protected $code;

    /**
     * @return string
     */
    public function getCode(): ?string
    {
        return $this->code;
    }

    /**
     * @param string $code
     *
     * @return static
     */
    public function setCode(?string $code): self
    {
        $this->code = $code;

        return $this;
    }
}
