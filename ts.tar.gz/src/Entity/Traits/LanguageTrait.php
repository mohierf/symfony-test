<?php

namespace App\Entity\Traits;

use App\Entity\Language;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Language trait.
 */
trait LanguageTrait
{
    /**
     * @var Language
     *
     * @ORM\ManyToOne(targetEntity="Language", cascade={"persist"})
     * @ORM\JoinColumn(referencedColumnName="id", nullable=true)
     *
     * @Groups({"language:read"})
     *
     * @Assert\NotBlank(groups={"template"})
     */
    protected $language;

    /**
     * @return Language
     */
    public function getLanguage(): ?Language
    {
        return $this->language;
    }

    /**
     * @param Language $language
     *
     * @return self
     */
    public function setLanguage(?Language $language): self
    {
        $this->language = $language;

        return $this;
    }
}
