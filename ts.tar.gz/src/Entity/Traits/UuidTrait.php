<?php

namespace App\Entity\Traits;

use ApiPlatform\Core\Annotation\ApiProperty;
use Doctrine\ORM\Mapping as ORM;
use Ramsey\Uuid\Uuid;
use Ramsey\Uuid\UuidInterface;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Trait UuidTrait.
 *
 * @ORM\HasLifecycleCallbacks()
 */
trait UuidTrait
{
    /**
     * Uuid.
     *
     * @var UuidInterface
     *
     * @ORM\Column(type="uuid", unique=true)
     *
     * @ApiProperty(identifier=true)
     * @Groups({"uuid:read"})
     */
    private $uuid;

    /**
     * @return UuidInterface
     */
    public function getUuid(): ?UuidInterface
    {
        return $this->uuid;
    }

    /**
     * @param $uuid
     *
     * @return UuidTrait
     */
    public function setUuid($uuid): self
    {
        $this->uuid = $uuid;

        return $this;
    }

    /**
     * @ORM\PrePersist()
     *
     * @return self
     *
     * @throws \Exception
     */
    public function generateUid(): self
    {
        if (!$this->uuid) {
            $this->uuid = Uuid::uuid4();
        }

        return $this;
    }
}
