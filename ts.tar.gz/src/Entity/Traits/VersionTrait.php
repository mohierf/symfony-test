<?php

namespace App\Entity\Traits;

use Doctrine\ORM\Mapping as ORM;

/**
 * Trait VersionTrait.
 */
trait VersionTrait
{
    /**
     * @var self
     *
     * @ORM\OneToOne(targetEntity="replaced_on_loadClassMetadata_child")
     * @ORM\JoinColumn(unique=true)
     */
    protected $child;

    /**
     * @var self
     *
     * @ORM\OneToOne(targetEntity="replaced_on_loadClassMetadata_parent")
     * @ORM\JoinColumn(onDelete="SET NULL", unique=true)
     */
    protected $parent;

    /**
     * @var int
     *
     * @ORM\Column(type="integer")
     */
    protected $version = 1;

    /**
     * @return int
     */
    public function getVersion(): ?int
    {
        return $this->version;
    }

    /**
     * @param int $version
     *
     * @return self
     */
    public function setVersion(int $version): self
    {
        $this->version = $version;

        return $this;
    }

    /**
     * @return self
     */
    public function getChild(): ?self
    {
        return $this->child;
    }

    /**
     * @param mixed $child
     *
     * @return self
     */
    public function setChild(?self $child): self
    {
        $this->child = $child;

        return $this;
    }

    /**
     * @return self
     */
    public function getParent(): ?self
    {
        return $this->parent;
    }

    /**
     * @param mixed $parent
     *
     * @return VersionTrait
     */
    public function setParent(?self $parent): self
    {
        $this->parent = $parent;

        return $this;
    }

    /**
     * Create a new version of the current object.
     *
     * @return self
     */
    public function createNewVersion(): self
    {
        $newVersion = clone $this;
        $newVersion->setParent($this);
        $this->setChild($newVersion);
        $newVersion->setVersion($this->getVersion() + 1);

        return $newVersion;
    }

    public function __clone()
    {
        throw new \Exception('You must define this method in your class');
    }
}
