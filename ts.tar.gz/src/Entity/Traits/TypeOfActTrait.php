<?php

namespace App\Entity\Traits;

use App\Entity\TypeOfAct;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Trait TypeOfActTrait.
 */
trait TypeOfActTrait
{
    /**
     * @var TypeOfAct
     *
     * @ORM\ManyToOne(targetEntity="App\Entity\TypeOfAct")
     *
     * @ORM\JoinColumn(name="type_of_act_id", referencedColumnName="id")
     *
     * @Assert\NotBlank(groups={"template"})
     */
    protected $typeOfAct;

    /**
     * @return TypeOfAct
     */
    public function getTypeOfAct(): ?TypeOfAct
    {
        return $this->typeOfAct;
    }

    /**
     * @param mixed $typeOfAct
     *
     * @return self
     */
    public function setTypeOfAct($typeOfAct): self
    {
        $this->typeOfAct = $typeOfAct;

        return $this;
    }
}
