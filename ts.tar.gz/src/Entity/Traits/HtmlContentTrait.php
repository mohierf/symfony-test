<?php

namespace App\Entity\Traits;

use App\Validator\Constraints as Assert;
use Doctrine\ORM\Mapping as ORM;

/**
 * Trait HtmlContentTrait.
 */
trait HtmlContentTrait
{
    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    protected $css;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    protected $cssMetadata;

    /**
     * @var string
     *
     * @Assert\isValidTwigContent(groups={"template"})
     * @ORM\Column(type="text", nullable=true)
     */
    protected $html;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    protected $htmlMetadata;

    /**
     * @var string
     *
     * @ORM\Column(type="text", nullable=true)
     */
    protected $assets;

    /**
     * @return string|null
     */
    public function getCss(): ?string
    {
        return $this->css;
    }

    /**
     * @param string|null $css
     *
     * @return self
     */
    public function setCss(?string $css): self
    {
        $this->css = $css;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getCssMetadata(): ?string
    {
        return $this->cssMetadata;
    }

    /**
     * @param string|null $cssMetadata
     *
     * @return self
     */
    public function setCssMetadata(?string $cssMetadata): self
    {
        $this->cssMetadata = $cssMetadata;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getHtml(): ?string
    {
        return $this->html;
    }

    /**
     * @param string|null $html
     *
     * @return self
     */
    public function setHtml(?string $html): self
    {
        $this->html = $html;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getHtmlMetadata(): ?string
    {
        return $this->htmlMetadata;
    }

    /**
     * @param string|null $htmlMetadata
     *
     * @return self
     */
    public function setHtmlMetadata(?string $htmlMetadata): self
    {
        $this->htmlMetadata = $htmlMetadata;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getAssets(): ?string
    {
        return $this->assets;
    }

    /**
     * @param mixed $assets
     *
     * @return self
     */
    public function setAssets(?string $assets): self
    {
        $this->assets = $assets;

        return $this;
    }
}
