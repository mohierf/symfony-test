<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiFilter;
use ApiPlatform\Core\Annotation\ApiProperty;
use ApiPlatform\Core\Annotation\ApiResource;
use ApiPlatform\Core\Bridge\Doctrine\Orm\Filter\BooleanFilter;
use ApiPlatform\Core\Bridge\Doctrine\Orm\Filter\SearchFilter;
use App\Entity\Traits\ActiveTrait;
use App\Entity\Traits\CompanyTrait;
use App\Entity\Traits\HtmlContentTrait;
use App\Entity\Traits\JsonSchemaTrait;
use App\Entity\Traits\LanguageTrait;
use App\Entity\Traits\LockedTrait;
use App\Entity\Traits\TemplateCategoryTrait;
use App\Entity\Traits\TimestampTrait;
use App\Entity\Traits\UuidTrait;
use App\Entity\Traits\VersionTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class Template.
 *
 * @ApiResource(
 *      itemOperations={
 *          "get",
 *          "PdfFromTemplate"={
 *              "route_name"="template_pdf",
 *              "swagger_context"={
 *                 "summary"="Render a template in PDF format",
 *                 "consumes"={"application/json"},
 *                 "produces"={"application/pdf"},
 *                 "parameters"={
 *                     {
 *                          "name"="uuid",
 *                          "description"="Template UUID",
 *                          "in"="path",
 *                          "required"=true,
 *                          "type"="string"
 *                     },
 *                     {
 *                          "name"="body",
 *                          "description"="Request body",
 *                          "in"="body",
 *                          "required"=true,
 *                          "type"="string"
 *                      }
 *                  },
 *                  "responses"={
 *                     "200"={
 *                       "description"="Template file in PDF format",
 *                       "schema"={"type"="string","format"="binary"},
 *                       "content"={
 *                         "application/octet-stream" = {
 *                           "schema"={"type"="string","format"="binary"}
 *                          }
 *                        }
 *                      },
 *                     "400"={"description"="Invalid schema. Missing or misspelled property in the JSON body."},
 *                     "404"={"description"="The ID provided does not match any existing template"},
 *                     "500"={"description"="Internal error"}
 *                 },
 *              }
 *          }
 *      },
 *      collectionOperations={"get"},
 *      attributes={
 *          "normalization_context"={
 *              "groups"={"template:read", "company:read", "language:read", "uuid:read", "code:read", "name:read"},
 *              "swagger_definition_name"="Read"
 *          },
 *          "filters"={"template.language_filter"}
 *     }
 * )
 *
 * @ApiFilter(SearchFilter::class, properties={"language.code": "exact", "company.code": "exact", "templateCategory.code": "exact"})
 * @ApiFilter(BooleanFilter::class, properties={"active"})
 *
 * @ORM\Entity(repositoryClass="App\Repository\TemplateRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class Template implements TemplateInterface, ObjectAgencyInterface
{
    use HtmlContentTrait;
    use VersionTrait;
    use ActiveTrait;
    use LockedTrait;
    use LanguageTrait;
    use TimestampTrait;
    use CompanyTrait;
    use UuidTrait;
    use JsonSchemaTrait;
    use TemplateCategoryTrait;

    use ORMBehaviors\Translatable\Translatable;

    /**
     * @Assert\Valid
     *
     * @Groups({"template:read"})
     */
    protected $translations;
    /**
     * @var TemplateAgency[]
     *
     * @ORM\OneToMany(targetEntity="App\Entity\TemplateAgency", mappedBy="template", cascade={"remove"})
     */
    protected $agencies;

    /**
     * Id (primary key).
     *
     * @var int
     *
     * @ORM\Id
     * @ORM\Column(name="id", type="integer", options={"unsigned"=true})
     * @ORM\GeneratedValue(strategy="AUTO")
     *
     * @ApiProperty(identifier=false)
     */
    private $id;

    public function __construct()
    {
        $this->agencies = new ArrayCollection();
    }

    /**
     * @return TemplateAgency[]|Collection
     */
    public function getAgencies(): Collection
    {
        return $this->agencies;
    }

    /**
     * @param array $agencies
     *
     * @return ObjectAgencyInterface
     */
    public function setAgencies(array $agencies): ObjectAgencyInterface
    {
        $this->agencies = $agencies;

        return $this;
    }

    /**
     * @param $method
     * @param $arguments
     *
     * @return mixed
     */
    public function __call($method, $arguments)
    {
        return PropertyAccess::createPropertyAccessor()->getValue($this->translate(), $method);
    }

    public function __clone()
    {
        $this->id = null;
    }

    /**
     * @return int
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getType(): string
    {
        return 'template';
    }
}
