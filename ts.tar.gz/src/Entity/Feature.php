<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Sfk\UserBundle\Entity\AbstractFeature;
use Sfk\UserBundle\Entity\FeatureInterface;

/**
 * Feature.
 *
 * @ORM\Table(name="feature")
 * @ORM\Entity()
 */
class Feature extends AbstractFeature implements FeatureInterface
{
    /**
     * @var ArrayCollection
     *
     * @ORM\ManyToMany(targetEntity="User", mappedBy="features")
     */
    private $users;

    /**
     * Add user to feature.
     *
     * @param User $user
     *
     * @return $this
     */
    public function addUser(User $user): self
    {
        $this->users[] = $user;

        return $this;
    }

    /**
     * Get users of feature.
     *
     * @return ArrayCollection
     */
    public function getUsers(): ArrayCollection
    {
        return $this->users;
    }

    /**
     * Remove user from feature.
     *
     * @param User $user
     *
     * @return $this
     */
    public function removeUser(User $user): self
    {
        $this->users->removeElement($user);

        return $this;
    }
}
