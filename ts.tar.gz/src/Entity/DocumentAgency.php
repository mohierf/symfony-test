<?php

namespace App\Entity;

use App\Entity\Traits\IdTrait;
use App\Entity\Traits\TimestampTrait;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity()
 * @ORM\Table(name="document_agency")
 * @ORM\HasLifecycleCallbacks()
 */
class DocumentAgency implements ObjectAgencyLinkInterface
{
    use IdTrait;
    use TimestampTrait;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=50)
     */
    private $type;

    /**
     * @var Agency
     *
     * @ORM\ManyToOne(targetEntity="Agency", inversedBy="agencyDocuments")
     * @ORM\JoinColumn(nullable=false)
     */
    private $agency;

    /**
     * @var Document
     *
     * @ORM\ManyToOne(targetEntity="Document", inversedBy="agencies")
     * @ORM\JoinColumn(nullable=false)
     */
    private $document;

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getType(): string
    {
        return $this->type;
    }

    /**
     * @param string $type
     *
     * @return self
     */
    public function setType(string $type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * @return Agency
     */
    public function getAgency(): Agency
    {
        return $this->agency;
    }

    /**
     * @param Agency $agency
     *
     * @return self
     */
    public function setAgency(Agency $agency)
    {
        $this->agency = $agency;

        return $this;
    }

    /**
     * @return Document
     */
    public function getDocument(): Document
    {
        return $this->document;
    }

    /**
     * @param Document $document
     *
     * @return DocumentAgency
     */
    public function setDocument(Document $document): DocumentAgency
    {
        $this->document = $document;

        return $this;
    }

    /**
     * @param ObjectAgencyInterface $object
     */
    public function setObject(ObjectAgencyInterface $object)
    {
        $this->setDocument($object);
    }

    /**
     * @return string
     */
    public static function getObjectRelationName(): string
    {
        return 'document';
    }
}
