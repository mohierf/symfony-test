<?php

namespace App\Entity;

use App\Entity\Traits\ErpIdTrait;
use App\Entity\Traits\IdTrait;
use App\Entity\Traits\NameTrait;
use App\Entity\Traits\TimestampTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * Data is synced from BAPPLI (erp service or rabbitmq).
 *
 * @ORM\Table(name="agency_family",
 *     uniqueConstraints={
 *          @ORM\UniqueConstraint(name="erp_identifier_idx", columns={"erp_id"})
 *     })
 * @ORM\Entity(repositoryClass="App\Repository\AgencyFamilyRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class AgencyFamily
{
    use IdTrait;
    use ErpIdTrait;
    use TimestampTrait;
    use NameTrait;

    /**
     * @var Agency[]
     *
     * @ORM\OneToMany(targetEntity="App\Entity\Agency", mappedBy="family")
     */
    protected $agencies;

    /**
     * @var CustomVariable[]
     *
     * @ORM\ManyToMany(targetEntity="App\Entity\CustomVariable", mappedBy="agencyFamilies")
     */
    protected $customVariables;

    /**
     * AgencyFamily constructor.
     */
    public function __construct()
    {
        $this->agencies = new ArrayCollection();
        $this->customVariables = new ArrayCollection();
        $this->creation = new \DateTime();
        $this->lastUpdate = new \DateTime();
    }

    /**
     * Get printable.
     *
     * @return string
     */
    public function __toString(): string
    {
        return $this->name;
    }

    /**
     * @return Agency[]
     */
    public function getAgencies(): array
    {
        return $this->agencies;
    }

    /**
     * @param Agency[] $agencies
     *
     * @return AgencyFamily
     */
    public function setAgencies(array $agencies): AgencyFamily
    {
        $this->agencies = $agencies;

        return $this;
    }

    /**
     * @return CustomVariable[]
     */
    public function getCustomVariables(): array
    {
        return $this->customVariables;
    }

    /**
     * @param CustomVariable[] $customVariables
     *
     * @return AgencyFamily
     */
    public function setCustomVariables(array $customVariables): AgencyFamily
    {
        $this->customVariables = $customVariables;

        return $this;
    }
}
