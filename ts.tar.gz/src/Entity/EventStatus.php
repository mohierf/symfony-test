<?php

namespace App\Entity;

use App\Entity\Traits\IdTrait;
use App\Entity\Traits\TimestampTrait;
use App\Entity\Traits\TypeOfActTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * EventStatus.
 * Data is synced from BAPPLI (erp service or rabbitmq).
 *
 * @ORM\Table(name="event_status")
 * @ORM\Entity(repositoryClass="App\Repository\EventStatusRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class EventStatus
{
    use IdTrait;
    use TimestampTrait;
    use TypeOfActTrait;

    /**
     * @var string
     *
     * @ORM\Column(name="status", type="string", length=255)
     */
    protected $status;

    /**
     * @var ArrayCollection|EmailContractEvent
     *
     * @ORM\OneToMany(targetEntity="App\Entity\EmailContractEvent", mappedBy="eventStatus")
     */
    protected $emailContractEvents;

    /**
     * ContractStatus constructor.
     */
    public function __construct()
    {
        $this->emailContractEvents = new ArrayCollection();
    }

    /**
     * @return string
     */
    public function getStatus(): ?string
    {
        return $this->status;
    }

    /**
     * @param string|null $status
     *
     * @return EventStatus
     */
    public function setStatus(?string $status): self
    {
        $this->status = $status;

        return $this;
    }
}
