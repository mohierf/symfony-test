<?php

namespace App\Entity;

use App\Entity\Traits\CompanyTrait;
use App\Entity\Traits\CountryTrait;
use App\Entity\Traits\HtmlContentTrait;
use App\Entity\Traits\IdTrait;
use App\Entity\Traits\LanguageTrait;
use App\Entity\Traits\TimestampTrait;
use App\Entity\Traits\TypeOfActTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class CustomVariable.
 *
 * @ORM\Entity(repositoryClass="App\Repository\CustomVariableRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class CustomVariable implements ObjectAgencyInterface
{
    use CompanyTrait;
    use CountryTrait;
    use HtmlContentTrait;
    use IdTrait;
    use LanguageTrait;
    use TimestampTrait;
    use TypeOfActTrait;

    use ORMBehaviors\Translatable\Translatable;

    public const PREFIX = 'cv';

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\AgencyFamily", inversedBy="customVariables")
     */
    protected $agencyFamilies;

    /**
     * @var CustomVariableAgency[]
     *
     * @ORM\OneToMany(targetEntity="CustomVariableAgency", mappedBy="customVariable", cascade={"remove"})
     */
    protected $agencies;

    /**
     * @Assert\Valid
     */
    protected $translations;
    /**
     * @var string[]
     */
    protected $embeddedContent;

    public function __construct()
    {
        $this->agencies = new ArrayCollection();
        $this->agencyFamilies = new ArrayCollection();
    }

    /**
     * @param $method
     * @param $arguments
     *
     * @return mixed
     */
    public function __call($method, $arguments)
    {
        return PropertyAccess::createPropertyAccessor()->getValue($this->translate(), $method);
    }

    /**
     * @return CustomVariableAgency[]|Collection
     */
    public function getAgencies(): Collection
    {
        return $this->agencies;
    }

    /**
     * @param array $agencies
     *
     * @return ObjectAgencyInterface
     */
    public function setAgencies(array $agencies): ObjectAgencyInterface
    {
        $this->agencies = $agencies;

        return $this;
    }

    /**
     * @return AgencyFamily[]|Collection
     */
    public function getAgencyFamilies(): Collection
    {
        return $this->agencyFamilies;
    }

    /**
     * @param array $agencyFamilies
     *
     * @return CustomVariable
     */
    public function setAgencyFamilies(array $agencyFamilies): CustomVariable
    {
        $this->agencyFamilies = $agencyFamilies;

        return $this;
    }

    /**
     * @return string
     */
    public function displayName(): string
    {
        return sprintf('%s_%s', $this->displayNamePrefix(), $this->displayNameSuffix());
    }

    /**
     * @return string
     */
    public function displayNamePrefix(): string
    {
        return sprintf('cv%s', $this->id);
    }

    /**
     * @return string
     */
    public function displayNameSuffix(): string
    {
        return preg_replace('/[^\pL\w]/u', '_', $this->__toString());
    }

    /**
     * @return string|null
     */
    public function __toString(): string
    {
        return $this->translate($this->getCurrentLocale())->getName() ?? '';
    }

    /**
     * @return string
     */
    public function getEmbeddedContent(): string
    {
        $cssClassName = $this->getStoreName();
        $pattern = '/([^{}])*{/';
        $replacement = sprintf('.%s $0', $cssClassName);
        $css = preg_replace($pattern, $replacement, $this->getCss());

        return sprintf('<style>%s</style><div class="%s">%s</div>', $css, $cssClassName, $this->getHtml());
    }

    /**
     * @return string|null
     */
    public function getStoreName(): ?string
    {
        return sprintf('%s%s', self::PREFIX, $this->getId());
    }
}
