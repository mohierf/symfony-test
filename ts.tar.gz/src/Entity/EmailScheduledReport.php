<?php

namespace App\Entity;

use App\Entity\Traits\IdTrait;
use App\Entity\Traits\TimestampTrait;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table(name="email_scheduled_report")
 * @ORM\Entity(repositoryClass="App\Repository\EmailScheduledReportRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class EmailScheduledReport
{
    use IdTrait;
    use TimestampTrait;

    const STATUS_PENDING = 'pending';
    const STATUS_RUNNING = 'running';
    const STATUS_SUCCESS = 'success';
    const STATUS_ERROR = 'error';

    /**
     * @var Email
     *
     * @ORM\ManyToOne(targetEntity="Email")
     * @ORM\JoinColumn(nullable=false)
     */
    private $email;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    protected $startedAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(type="datetime", nullable=true)
     */
    protected $finishedAt;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=255)
     */
    protected $status = self::STATUS_PENDING;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", options={"unsigned"=true}, nullable=true)
     */
    protected $totalPageTodo = 0;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", options={"unsigned"=true}, nullable=true)
     */
    protected $totalPageSuccess = 0;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", options={"unsigned"=true}, nullable=true)
     */
    protected $totalPageError = 0;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", options={"unsigned"=true}, nullable=true)
     */
    protected $totalItemsTodo = 0;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", options={"unsigned"=true}, nullable=true)
     */
    protected $totalItemsSuccess = 0;

    /**
     * @var int
     *
     * @ORM\Column(type="integer", options={"unsigned"=true}, nullable=true)
     */
    protected $totalItemsError = 0;

    /**
     * @return Email
     */
    public function getEmail(): Email
    {
        return $this->email;
    }

    /**
     * @param Email $email
     */
    public function setEmail(Email $email): void
    {
        $this->email = $email;
    }

    /**
     * @return \DateTime
     */
    public function getStartedAt(): \DateTime
    {
        return $this->startedAt;
    }

    /**
     * @param \DateTime $startedAt
     */
    public function setStartedAt(\DateTime $startedAt): void
    {
        $this->startedAt = $startedAt;
    }

    /**
     * @return \DateTime
     */
    public function getFinishedAt(): ?\DateTime
    {
        return $this->finishedAt;
    }

    /**
     * @param \DateTime $finishedAt
     */
    public function setFinishedAt(\DateTime $finishedAt): void
    {
        $this->finishedAt = $finishedAt;
    }

    /**
     * @return string
     */
    public function getStatus(): string
    {
        return $this->status;
    }

    /**
     * @param string $status
     */
    public function setStatus(string $status): void
    {
        $this->status = $status;
    }

    /**
     * @return int
     */
    public function getTotalPageTodo(): int
    {
        return $this->totalPageTodo;
    }

    /**
     * @param int $totalPageTodo
     */
    public function setTotalPageTodo(int $totalPageTodo): void
    {
        $this->totalPageTodo = $totalPageTodo;
    }

    /**
     * @return int
     */
    public function getTotalPageSuccess(): int
    {
        return $this->totalPageSuccess;
    }

    /**
     * @param int $totalPageSuccess
     */
    public function setTotalPageSuccess(int $totalPageSuccess): void
    {
        $this->totalPageSuccess = $totalPageSuccess;
    }

    /**
     * @return int
     */
    public function getTotalPageError(): int
    {
        return $this->totalPageError;
    }

    /**
     * @param int $totalPageError
     */
    public function setTotalPageError(int $totalPageError): void
    {
        $this->totalPageError = $totalPageError;
    }

    /**
     * @return int
     */
    public function getTotalItemsTodo(): int
    {
        return $this->totalItemsTodo;
    }

    /**
     * @param int $totalItemsTodo
     */
    public function setTotalItemsTodo(int $totalItemsTodo): void
    {
        $this->totalItemsTodo = $totalItemsTodo;
    }

    /**
     * @return int
     */
    public function getTotalItemsSuccess(): int
    {
        return $this->totalItemsSuccess;
    }

    /**
     * @param int $totalItemsSuccess
     */
    public function setTotalItemsSuccess(int $totalItemsSuccess): void
    {
        $this->totalItemsSuccess = $totalItemsSuccess;
    }

    /**
     * @return int
     */
    public function getTotalItemsError(): int
    {
        return $this->totalItemsError;
    }

    /**
     * @param int $totalItemsError
     */
    public function setTotalItemsError(int $totalItemsError): void
    {
        $this->totalItemsError = $totalItemsError;
    }
}
