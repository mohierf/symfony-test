<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Sfk\UserBundle\Entity\AbstractUser;
use Sfk\UserBundle\Entity\UserInterface;

/**
 * User.
 *
 * @ORM\Table(name="user")
 * @ORM\Entity()
 */
class User extends AbstractUser implements UserInterface
{
}
