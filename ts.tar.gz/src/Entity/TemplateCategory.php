<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Entity\Traits\CodeTrait;
use App\Entity\Traits\IdTrait;
use App\Entity\Traits\TimestampTrait;
use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * TemplateCategory.
 *
 * @ApiResource(
 *      itemOperations={"get"},
 *      collectionOperations={"get"},
 *      attributes={
 *          "normalization_context"={
 *              "groups"={"template-category:read","language:read", "uuid:read", "code:read", "name:read"},
 *              "swagger_definition_name"="Read"
 *          }
 *     }
 * )
 *
 * @ORM\Entity(repositoryClass="App\Repository\TemplateCategoryRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class TemplateCategory
{
    use IdTrait;
    use TimestampTrait;
    use CodeTrait;

    use ORMBehaviors\Translatable\Translatable;

    /**
     * @Assert\Valid
     *
     * @Groups({"template-category:read", "template:read"})
     */
    protected $translations;

    /**
     * @param $method
     * @param $arguments
     *
     * @return mixed
     */
    public function __call($method, $arguments)
    {
        return PropertyAccess::createPropertyAccessor()->getValue($this->translate(), $method);
    }

    /**
     * @return string
     */
    public function __toString(): string
    {
        return $this->translate('fr')->getName();
    }
}
