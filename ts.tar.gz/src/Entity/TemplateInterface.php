<?php

namespace App\Entity;

/**
 * Interface TemplateInterface.
 */
interface TemplateInterface
{
    public const TEMPLATE_TYPES = [
            self::DOCUMENT_TYPE,
            self::EMAIL_TYPE,
            self::TEMPLATE_TYPE,
        ];

    public const DOCUMENT_TYPE = 'document';
    public const EMAIL_TYPE = 'email';
    public const TEMPLATE_TYPE = 'template';

    /**
     * @return string
     */
    public function getCss(): ?string;

    /**
     * @return string
     */
    public function getHtml(): ?string;

    /**
     * @return string
     */
    public function getType(): string;
}
