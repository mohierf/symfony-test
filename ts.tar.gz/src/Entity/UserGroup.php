<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\PersistentCollection;
use Sfk\UserBundle\Entity\AbstractGroup;
use Sfk\UserBundle\Entity\GroupInterface;

/**
 * Group.
 *
 * @ORM\Table(name="user_group")
 * @ORM\Entity()
 */
class UserGroup extends AbstractGroup implements GroupInterface
{
    /**
     * @var PersistentCollection
     *
     * @ORM\ManyToMany(targetEntity="User", mappedBy="groups")
     */
    private $users;

    /**
     * Add user to group.
     *
     * @param User $user
     *
     * @return $this
     */
    public function addUser(User $user): self
    {
        $this->users[] = $user;

        return $this;
    }

    /**
     * Get users.
     *
     * @return PersistentCollection
     */
    public function getUsers(): PersistentCollection
    {
        return $this->users;
    }

    /**
     * Remove user from group.
     *
     * @param User $user
     *
     * @return $this
     */
    public function removeUser(User $user): self
    {
        $this->users->removeElement($user);

        return $this;
    }
}
