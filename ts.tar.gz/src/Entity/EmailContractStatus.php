<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class EmailContractStatus.
 *
 * @ORM\Entity
 * @ORM\Table(name="email_contract_status_link")
 */
class EmailContractStatus
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Email", inversedBy="contractStatuses")
     * @ORM\JoinColumn(name="email_id", referencedColumnName="id")
     */
    private $email;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\ContractStatus", inversedBy="emailContractStatuses")
     * @ORM\JoinColumn(name="status_id", referencedColumnName="id")
     */
    private $contractStatus;

    /**
     * Minimum time since status change date. Expressed in days.
     *
     * @var int
     *
     * @ORM\Column(name="min_delay", type="integer", nullable=true)
     * @Assert\GreaterThanOrEqual(0)
     * @Assert\Type("integer")
     */
    private $minDelaySinceStatusChange;

    /**
     * Maximum time since status change date. Expressed in days.
     *
     * @var int
     *
     * @ORM\Column(name="max_delay", type="integer", nullable=true)
     * @Assert\GreaterThanOrEqual(0)
     * @Assert\Type("integer")
     */
    private $maxDelaySinceStatusChange;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return int
     */
    public function getMinDelaySinceStatusChange(): ?int
    {
        return $this->minDelaySinceStatusChange;
    }

    /**
     * @param int $minDelaySinceStatusChange
     *
     * @return EmailContractStatus
     */
    public function setMinDelaySinceStatusChange(?int $minDelaySinceStatusChange): EmailContractStatus
    {
        $this->minDelaySinceStatusChange = $minDelaySinceStatusChange;

        return $this;
    }

    /**
     * @return int
     */
    public function getMaxDelaySinceStatusChange(): ?int
    {
        return $this->maxDelaySinceStatusChange;
    }

    /**
     * @param int $maxDelaySinceStatusChange
     *
     * @return EmailContractStatus
     */
    public function setMaxDelaySinceStatusChange(?int $maxDelaySinceStatusChange): EmailContractStatus
    {
        $this->maxDelaySinceStatusChange = $maxDelaySinceStatusChange;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $email
     *
     * @return EmailContractStatus
     */
    public function setEmail($email): EmailContractStatus
    {
        $this->email = $email;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getContractStatus()
    {
        return $this->contractStatus;
    }

    /**
     * @param mixed $contractStatus
     *
     * @return EmailContractStatus
     */
    public function setContractStatus($contractStatus): EmailContractStatus
    {
        $this->contractStatus = $contractStatus;

        return $this;
    }
}
