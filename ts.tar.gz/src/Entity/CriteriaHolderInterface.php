<?php

namespace App\Entity;

/**
 * Interface CriteriaHolderInterface.
 */
interface CriteriaHolderInterface
{
    public const CRITERIA = [
        'AGENCIES' => 'agencies',
        'COMPANY' => 'company',
        'DATE' => 'date',
        'CONTRACT_EVENTS' => 'contractEvents',
        'CONTRACT_STATUSES' => 'contractStatuses',
        'COUNTRY' => 'country',
        'LANGUAGE' => 'language',
        'PACKAGES' => 'packages',
        'PAYMENT_STATUSES' => 'paymentStatuses',
    ];

    /**
     * Get an array of criteria.
     *
     * @return mixed
     */
    public function getCriteriaList();
}
