<?php

namespace App\Entity;

use App\Entity\Traits\ErpIdTrait;
use App\Entity\Traits\IdTrait;
use App\Entity\Traits\NameTrait;
use App\Entity\Traits\TimestampTrait;
use App\Entity\Traits\TypeOfActTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * EventType.
 * Data is synced from BAPPLI (erp service or rabbitmq).
 *
 * @ORM\Table(
 *     name="event_type",
 *     uniqueConstraints={
 *          @ORM\UniqueConstraint(name="identifier_idx", columns={"erp_id", "type_of_act_id"})
 *     }
 * )
 * @ORM\Entity(repositoryClass="App\Repository\EventTypeRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class EventType
{
    use IdTrait;
    use NameTrait;
    use TypeOfActTrait;
    use TimestampTrait;
    use ErpIdTrait;

    /**
     * @var ArrayCollection|EmailContractEvent
     *
     * @ORM\OneToMany(targetEntity="App\Entity\EmailContractEvent", mappedBy="eventType")
     */
    protected $emailContractEvents;

    /**
     * ContractStatus constructor.
     */
    public function __construct()
    {
        $this->emailContractEvents = new ArrayCollection();
    }
}
