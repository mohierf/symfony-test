<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Entity\Traits\NameTrait;
use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * TemplateCategoryTranslation class.
 *
 * @ApiResource(
 *      itemOperations={"get"},
 *      collectionOperations={},
 *      attributes={
 *          "normalization_context"={
 *              "groups"={"template-category-translation:read", "name:read"},
 *              "swagger_definition_name"="Read"
 *          }
 *     }
 * )
 *
 * @ORM\Entity(repositoryClass="App\Repository\TemplateCategoryTranslationRepository")
 */
class TemplateCategoryTranslation
{
    use ORMBehaviors\Translatable\Translation;

    use NameTrait;

    /**
     * @var string
     *
     * @Groups({"template-category-translation:read", "template-category:read", "template:read"})
     */
    protected $locale;
}
