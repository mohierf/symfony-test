<?php

namespace App\Entity;

use App\Entity\Traits\NameTrait;
use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;

/**
 * Country translation class.
 *
 * @ORM\Entity(repositoryClass="App\Repository\CountryTranslationRepository")
 */
class CountryTranslation
{
    use ORMBehaviors\Translatable\Translation;

    use NameTrait;
}
