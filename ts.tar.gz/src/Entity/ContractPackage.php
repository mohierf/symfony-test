<?php

namespace App\Entity;

use App\Entity\Traits\ErpIdTrait;
use App\Entity\Traits\IdTrait;
use App\Entity\Traits\NameTrait;
use App\Entity\Traits\TimestampTrait;
use App\Entity\Traits\TypeOfActAsKeyTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * ContractPackage.
 * Data is synced from BAPPLI (erp service or rabbitmq).
 *
 * @ORM\Table(
 *     name="contract_package",
 *     uniqueConstraints={
 *          @ORM\UniqueConstraint(name="identifier_idx", columns={"erp_id", "type_of_act_id"})
 *     }
 * )
 * @ORM\Entity(repositoryClass="App\Repository\ContractPackageRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class ContractPackage
{
    use IdTrait;
    use NameTrait;
    use TypeOfActAsKeyTrait;
    use TimestampTrait;
    use ErpIdTrait;

    /**
     * @var ArrayCollection|Email[]
     *
     * @ORM\ManyToMany(targetEntity="App\Entity\Email", mappedBy="packages")
     */
    private $emails;

    public function __construct()
    {
        $this->emails = new ArrayCollection();
    }

    /**
     * @return ArrayCollection|Email[]
     */
    public function getEmails(): ArrayCollection
    {
        return $this->emails;
    }

    /**
     * @param ArrayCollection|Email[] $emails
     *
     * @return ContractPackage
     */
    public function setEmails(ArrayCollection $emails): ContractPackage
    {
        $this->emails = $emails;

        return $this;
    }
}
