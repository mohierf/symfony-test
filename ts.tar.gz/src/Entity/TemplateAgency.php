<?php

namespace App\Entity;

use App\Entity\Traits\IdTrait;
use App\Entity\Traits\timestampTrait;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\TemplateAgencyRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class TemplateAgency implements ObjectAgencyLinkInterface
{
    use IdTrait;
    use TimestampTrait;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=50)
     */
    private $type;

    /**
     * @var Agency
     *
     * @ORM\ManyToOne(targetEntity="Agency", inversedBy="agencyTemplates")
     * @ORM\JoinColumn(nullable=false)
     */
    private $agency;

    /**
     * @var Template
     *
     * @ORM\ManyToOne(targetEntity="Template", inversedBy="agencies")
     * @ORM\JoinColumn(nullable=false)
     */
    private $template;

    /**
     * @return string
     */
    public static function getObjectRelationName(): string
    {
        return 'template';
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getType(): string
    {
        return $this->type;
    }

    /**
     * @param string $type
     *
     * @return self
     */
    public function setType(string $type): self
    {
        $this->type = $type;

        return $this;
    }

    /**
     * @return Agency
     */
    public function getAgency(): Agency
    {
        return $this->agency;
    }

    /**
     * @param Agency $agency
     *
     * @return self
     */
    public function setAgency(Agency $agency)
    {
        $this->agency = $agency;

        return $this;
    }

    /**
     * @return Template
     */
    public function get(): Template
    {
        return $this->template;
    }

    /**
     * @param ObjectAgencyInterface $object
     */
    public function setObject(ObjectAgencyInterface $object)
    {
        $this->setTemplate($object);
    }

    /**
     * @param Template|ObjectAgencyInterface $template
     *
     * @return TemplateAgency
     */
    public function setTemplate(Template $template): TemplateAgency
    {
        $this->template = $template;

        return $this;
    }
}
