<?php

namespace App\Entity;

use App\Entity\Traits\NameTrait;
use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;

/**
 * DocumentTranslation class.
 *
 * @ORM\Entity(repositoryClass="App\Repository\DocumentTranslationRepository")
 */
class DocumentTranslation
{
    use ORMBehaviors\Translatable\Translation;

    use NameTrait;
}
