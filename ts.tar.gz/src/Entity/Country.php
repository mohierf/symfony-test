<?php

namespace App\Entity;

use App\Entity\Traits\CodeTrait;
use App\Entity\Traits\ErpIdTrait;
use App\Entity\Traits\IdTrait;
use App\Entity\Traits\TimestampTrait;
use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Country.
 * Data is synced from BAPPLI (erp service or rabbitmq).
 *
 * @ORM\Table(name="country",
 *     uniqueConstraints={
 *          @ORM\UniqueConstraint(name="erp_identifier_idx", columns={"erp_id"})
 *     }))
 * @ORM\Entity(repositoryClass="App\Repository\CountryRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class Country
{
    use IdTrait;
    use ErpIdTrait;
    use CodeTrait;
    use TimestampTrait;

    use ORMBehaviors\Translatable\Translatable;

    /**
     * @Assert\Valid
     */
    protected $translations;

    /**
     * @param $method
     * @param $arguments
     *
     * @return mixed
     */
    public function __call($method, $arguments)
    {
        return PropertyAccess::createPropertyAccessor()->getValue($this->translate(), $method);
    }

    /**
     * @return string
     */
    public function __toString(): string
    {
        return $this->translate('fr')->getName();
    }
}
