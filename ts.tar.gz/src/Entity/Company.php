<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Entity\Traits\CodeTrait;
use App\Entity\Traits\ErpIdTrait;
use App\Entity\Traits\IdTrait;
use App\Entity\Traits\NameTrait;
use App\Entity\Traits\TimestampTrait;
use Doctrine\ORM\Mapping as ORM;

/**
 * Company.
 * Data is synced from BAPPLI (erp service or rabbitmq).
 *
 * @ApiResource(
 *      itemOperations={"get"},
 *      collectionOperations={"get"},
 *      attributes={
 *          "normalization_context"={
 *              "groups"={"company:read", "code:read", "name:read"},
 *              "swagger_definition_name"="Read"
 *          }
 *     }
 * )
 *
 * @ORM\Table(name="company",
 *     uniqueConstraints={
 *          @ORM\UniqueConstraint(name="erp_identifier_idx", columns={"erp_id"})
 *     }))
 * @ORM\Entity(repositoryClass="App\Repository\CompanyRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class Company
{
    use IdTrait;
    use ErpIdTrait;
    use CodeTrait;
    use NameTrait;
    use TimestampTrait;

    /**
     * @return string
     */
    public function __toString(): string
    {
        return $this->name;
    }
}
