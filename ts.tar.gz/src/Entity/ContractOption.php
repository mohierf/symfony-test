<?php

namespace App\Entity;

use App\Entity\Traits\ErpIdTrait;
use App\Entity\Traits\IdTrait;
use App\Entity\Traits\NameTrait;
use App\Entity\Traits\TimestampTrait;
use App\Entity\Traits\TypeOfActAsKeyTrait;
use Doctrine\ORM\Mapping as ORM;

/**
 * ContractOption.
 * Data is synced from BAPPLI (erp service or rabbitmq).
 *
 * @ORM\Table(
 *     name="contract_option",
 *     uniqueConstraints={
 *          @ORM\UniqueConstraint(name="identifier_idx", columns={"erp_id", "type_of_act_id"})
 *     }
 * )
 * @ORM\Entity(repositoryClass="App\Repository\ContractOptionRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class ContractOption
{
    use IdTrait;
    use NameTrait;
    use TypeOfActAsKeyTrait;
    use TimestampTrait;
    use ErpIdTrait;
}
