<?php

namespace App\Entity;

use App\Entity\Traits\ErpIdTrait;
use App\Entity\Traits\IdTrait;
use App\Entity\Traits\NameTrait;
use App\Entity\Traits\TimestampTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * Data is synced from BAPPLI (erp service or rabbitmq).
 *
 * @ORM\Table(name="agency",
 *     uniqueConstraints={
 *          @ORM\UniqueConstraint(name="erp_identifier_idx", columns={"erp_id"})
 *     })
 * @ORM\Entity(repositoryClass="App\Repository\AgencyRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class Agency
{
    use IdTrait;
    use ErpIdTrait;
    use TimestampTrait;
    use NameTrait;

    /**
     * @var Agency
     *
     * @ORM\ManyToOne(targetEntity="Agency", cascade={"persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $groupAgency;

    /**
     * @var Agency
     *
     * @ORM\ManyToOne(targetEntity="Agency", cascade={"persist"})
     * @ORM\JoinColumn(nullable=true)
     */
    private $mainAgency;

    /**
     * @var DocumentAgency[]
     *
     * @ORM\OneToMany(targetEntity="DocumentAgency", mappedBy="agency")
     */
    protected $agencyDocuments;

    /**
     * @var EmailAgency[]
     *
     * @ORM\OneToMany(targetEntity="EmailAgency", mappedBy="agency")
     */
    protected $agencyEmails;

    /**
     * @var CustomVariableAgency[]
     *
     * @ORM\OneToMany(targetEntity="App\Entity\CustomVariableAgency", mappedBy="agency")
     */
    protected $agencyCustomVariables;

    /**
     * @var TemplateAgency[]
     *
     * @ORM\OneToMany(targetEntity="App\Entity\TemplateAgency", mappedBy="agency")
     */
    protected $agencyTemplates;

    /**
     * @var AgencyFamily
     *
     * @ORM\ManyToOne(targetEntity="App\Entity\AgencyFamily", inversedBy="agencies")
     * @ORM\JoinColumn(nullable=true)
     */
    private $family;

    /**
     * Agency constructor.
     */
    public function __construct()
    {
        $this->agencyDocuments = new ArrayCollection();
        $this->agencyEmails = new ArrayCollection();
        $this->agencyCustomVariables = new ArrayCollection();
        $this->agencyTemplates = new ArrayCollection();
        $this->creation = new \DateTime();
        $this->lastUpdate = new \DateTime();
    }

    /**
     * Get groupAgency.
     *
     * @return Agency|null
     */
    public function getGroupAgency(): ?Agency
    {
        return $this->groupAgency;
    }

    /**
     * Set groupAgency.
     *
     * @param Agency|null $groupAgency
     *
     * @return Agency
     */
    public function setGroupAgency(?Agency $groupAgency): Agency
    {
        $this->groupAgency = $groupAgency;

        return $this;
    }

    /**
     * Set mainAgency.
     *
     * @param Agency|null $mainAgency
     *
     * @return Agency
     */
    public function setMainAgency(?Agency $mainAgency): Agency
    {
        $this->mainAgency = $mainAgency;

        return $this;
    }

    /**
     * Get mainAgency.
     *
     * @return Agency
     */
    public function getMainAgency(): ?Agency
    {
        return $this->mainAgency;
    }

    /**
     * is main agency ?
     *
     * @return bool
     */
    public function isMainAgency(): bool
    {
        return $this->getMainAgency()->getId() === $this->getId();
    }

    /**
     * @param AgencyFamily $family
     *
     * @return Agency
     */
    public function setFamily(AgencyFamily $family): Agency
    {
        $this->family = $family;

        return $this;
    }

    /**
     * @return AgencyFamily
     */
    public function getFamily(): ?AgencyFamily
    {
        return $this->family;
    }

    /**
     * Get printable.
     *
     * @return string
     */
    public function __toString(): string
    {
        return $this->name;
    }
}
