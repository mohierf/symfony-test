<?php

namespace App\Entity;

use App\Entity\Traits\IdTrait;
use App\Entity\Traits\timestampTrait;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\EmailRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class EmailAgency implements ObjectAgencyLinkInterface
{
    use IdTrait;
    use TimestampTrait;

    /**
     * @var string
     *
     * @ORM\Column(type="string", length=50)
     */
    private $type;

    /**
     * @var Agency
     *
     * @ORM\ManyToOne(targetEntity="Agency", inversedBy="agencyEmails")
     * @ORM\JoinColumn(nullable=false)
     */
    private $agency;

    /**
     * @var Email
     *
     * @ORM\ManyToOne(targetEntity="Email", inversedBy="agencies")
     * @ORM\JoinColumn(nullable=false)
     */
    private $email;

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getType(): string
    {
        return $this->type;
    }

    /**
     * @param string $type
     *
     * @return self
     */
    public function setType(string $type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * @return Agency
     */
    public function getAgency(): Agency
    {
        return $this->agency;
    }

    /**
     * @param Agency $agency
     *
     * @return self
     */
    public function setAgency(Agency $agency)
    {
        $this->agency = $agency;

        return $this;
    }

    /**
     * @return Email
     */
    public function getEmail(): Email
    {
        return $this->email;
    }

    /**
     * @param Email|ObjectAgencyInterface $email
     *
     * @return EmailAgency
     */
    public function setEmail(Email $email): EmailAgency
    {
        $this->email = $email;

        return $this;
    }

    /**
     * @param ObjectAgencyInterface $object
     */
    public function setObject(ObjectAgencyInterface $object)
    {
        $this->setEmail($object);
    }

    /**
     * @return string
     */
    public static function getObjectRelationName(): string
    {
        return 'email';
    }
}
