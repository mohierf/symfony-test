<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Class EmailContractEvent.
 *
 * @ORM\Entity
 * @ORM\Table(name="email_contract_event_link")
 */
class EmailContractEvent
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\Email", inversedBy="contractEvents")
     * @ORM\JoinColumn(name="email_id", referencedColumnName="id")
     */
    private $email;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\EventType", inversedBy="emailContractEvents")
     * @ORM\JoinColumn(name="event_id", referencedColumnName="id")
     */
    private $eventType;

    /**
     * @ORM\ManyToOne(targetEntity="App\Entity\EventStatus", inversedBy="emailContractEvents")
     * @ORM\JoinColumn(name="status_id", referencedColumnName="id")
     */
    private $eventStatus;

    /**
     * Minimum time since event creation. Expressed in days.
     *
     * @var int
     *
     * @ORM\Column(name="min_delay", type="integer", nullable=true)
     * @Assert\GreaterThanOrEqual(0)
     * @Assert\Type("integer")
     */
    private $minDelaySinceEventCreation;

    /**
     * Maximum time since event creation. Expressed in days.
     *
     * @var int
     *
     * @ORM\Column(name="max_delay", type="integer", nullable=true)
     * @Assert\GreaterThanOrEqual(0)
     * @Assert\Type("integer")
     */
    private $maxDelaySinceEventCreation;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return int
     */
    public function getMinDelaySinceEventCreation(): ?int
    {
        return $this->minDelaySinceEventCreation;
    }

    /**
     * @param int $minDelaySinceEventCreation
     *
     * @return EmailContractEvent
     */
    public function setMinDelaySinceEventCreation(?int $minDelaySinceEventCreation): EmailContractEvent
    {
        $this->minDelaySinceEventCreation = $minDelaySinceEventCreation;

        return $this;
    }

    /**
     * @return int
     */
    public function getMaxDelaySinceEventCreation(): ?int
    {
        return $this->maxDelaySinceEventCreation;
    }

    /**
     * @param int $maxDelaySinceEventCreation
     *
     * @return EmailContractEvent
     */
    public function setMaxDelaySinceEventCreation(?int $maxDelaySinceEventCreation): EmailContractEvent
    {
        $this->maxDelaySinceEventCreation = $maxDelaySinceEventCreation;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getEmail(): ?Email
    {
        return $this->email;
    }

    /**
     * @param Email $email
     *
     * @return EmailContractEvent
     */
    public function setEmail(?Email $email): EmailContractEvent
    {
        $this->email = $email;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getEventType(): ?EventType
    {
        return $this->eventType;
    }

    /**
     * @param EventType $eventType
     *
     * @return EmailContractEvent
     */
    public function setEventType(?EventType $eventType): EmailContractEvent
    {
        $this->eventType = $eventType;

        return $this;
    }

    /**
     * @return mixed
     */
    public function getEventStatus(): ?EventStatus
    {
        return $this->eventStatus;
    }

    /**
     * @param EventStatus $eventStatus
     *
     * @return EmailContractEvent
     */
    public function setEventStatus(?EventStatus $eventStatus): EmailContractEvent
    {
        $this->eventStatus = $eventStatus;

        return $this;
    }
}
