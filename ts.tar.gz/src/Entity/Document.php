<?php

namespace App\Entity;

use App\Entity\Traits\ActiveTrait;
use App\Entity\Traits\CategoryTrait;
use App\Entity\Traits\CompanyTrait;
use App\Entity\Traits\CountryTrait;
use App\Entity\Traits\HtmlContentTrait;
use App\Entity\Traits\IdTrait;
use App\Entity\Traits\LanguageTrait;
use App\Entity\Traits\LockedTrait;
use App\Entity\Traits\TimestampTrait;
use App\Entity\Traits\TypeOfActTrait;
use App\Entity\Traits\UuidTrait;
use App\Entity\Traits\VersionTrait;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity(repositoryClass="App\Repository\DocumentRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class Document implements TemplateInterface, ObjectAgencyInterface, CriteriaHolderInterface
{
    use HtmlContentTrait;
    use VersionTrait;
    use ActiveTrait;
    use LockedTrait;
    use TimestampTrait;
    use TypeOfActTrait;
    use IdTrait;
    use CompanyTrait;
    use CategoryTrait;
    use LanguageTrait;
    use CountryTrait;
    use UuidTrait;

    use ORMBehaviors\Translatable\Translatable;

    /**
     * @var DocumentAgency[]
     *
     * @ORM\OneToMany(targetEntity="DocumentAgency", mappedBy="document", cascade={"remove"})
     */
    protected $agencies;

    /**
     * @var ArrayCollection|ContractPackage[]
     *
     * @ORM\ManyToMany(targetEntity="App\Entity\ContractPackage", inversedBy="emails", cascade={"persist","remove"})
     * @ORM\JoinTable(name="document_contract_package_link")
     */
    protected $packages;

    /**
     * @Assert\Valid
     */
    protected $translations;

    public function __construct()
    {
        $this->agencies = new ArrayCollection();
        $this->packages = new ArrayCollection();
    }

    /**
     * @param $method
     * @param $arguments
     *
     * @return mixed
     */
    public function __call($method, $arguments)
    {
        return PropertyAccess::createPropertyAccessor()->getValue($this->translate(), $method);
    }

    /**
     * @return DocumentAgency[]|Collection
     */
    public function getAgencies(): Collection
    {
        return $this->agencies;
    }

    /**
     * @param array $agencies
     *
     * @return ObjectAgencyInterface
     */
    public function setAgencies(array $agencies): ObjectAgencyInterface
    {
        $this->agencies = $agencies;

        return $this;
    }

    public function __clone()
    {
        $this->id = null;
    }

    /**
     * @return string|null
     */
    public function __toString(): string
    {
        return $this->translate($this->getCurrentLocale())->getName() ?? '';
    }

    /**
     * @return ContractPackage[]|ArrayCollection
     */
    public function getPackages()
    {
        return $this->packages;
    }

    /**
     * @param ContractPackage[]|ArrayCollection $packages
     *
     * @return Document
     */
    public function setPackages($packages): Document
    {
        $this->packages = $packages;

        return $this;
    }

    /**
     * @return string
     */
    public function getType(): string
    {
        return 'document';
    }

    /**
     * Get an array of criteria.
     *
     * @return mixed
     */
    public function getCriteriaList()
    {
        // TODO: Implement getCriteriaList() method.
    }
}
