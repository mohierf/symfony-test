<?php

namespace App\Entity;

use App\Entity\Traits\IdTrait;
use App\Entity\Traits\NameTrait;
use App\Entity\Traits\TimestampTrait;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\TypeOfActRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class TypeOfAct
{
    const INSURANCE = 'insurance';
    const WEBSITE = 'website';
    const PRIVILEGE = 'privilege';

    const TYPES_OF_ACT
        = [
            self::INSURANCE,
            self::WEBSITE,
            self::PRIVILEGE,
        ];

    use IdTrait;
    use NameTrait;
    use TimestampTrait;

    /**
     * @return string
     */
    public function __toString()
    {
        return $this->getName() ?? 'Type of act';
    }
}
