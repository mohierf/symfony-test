<?php

namespace App\Entity;

use App\Entity\Traits\NameTrait;
use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;

/**
 * Category translation class.
 *
 * @ORM\Entity(repositoryClass="App\Repository\CategoryTranslationRepository")
 */
class CategoryTranslation
{
    use ORMBehaviors\Translatable\Translation;

    use NameTrait;
}
