<?php

namespace App\Entity;

use App\Entity\Traits\NameTrait;
use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;

/**
 * Email translation class.
 *
 * @ORM\Entity(repositoryClass="App\Repository\CustomVariableTranslationRepository")
 */
class CustomVariableTranslation
{
    use ORMBehaviors\Translatable\Translation;

    use NameTrait;
}
