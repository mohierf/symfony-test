<?php

namespace App\Entity;

/**
 * Interface ObjectAgencyLinkInterface.
 */
interface ObjectAgencyLinkInterface
{
    /**
     * Used to manage MAIN agency relation.
     */
    const TYPE_MAIN_AGENCY = 'main_agency';

    /**
     * Used to manage GROUP agency relation.
     */
    const TYPE_GROUP_AGENCY = 'group_agency';

    /**
     * Used to manage SIMPLE agency relation.
     */
    const TYPE_AGENCY = 'agency';

    /**
     * Returns agency relation type.
     *
     * @return string
     */
    public function getType(): string;

    /**
     * @param string $type
     *
     * @return mixed
     */
    public function setType(string $type);

    /**
     * Returns agency.
     *
     * @return Agency
     */
    public function getAgency(): Agency;

    /**
     * @param Agency $agency
     *
     * @return mixed
     */
    public function setAgency(Agency $agency);

    /**
     * @param ObjectAgencyInterface $object
     *
     * @return mixed
     */
    public function setObject(ObjectAgencyInterface $object);

    /**
     * @return string
     */
    public static function getObjectRelationName(): string;
}
