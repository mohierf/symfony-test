<?php

namespace App\Entity;

use App\Entity\Traits\ActiveTrait;
use App\Entity\Traits\CategoryTrait;
use App\Entity\Traits\CompanyTrait;
use App\Entity\Traits\CountryTrait;
use App\Entity\Traits\HtmlContentTrait;
use App\Entity\Traits\IdTrait;
use App\Entity\Traits\LanguageTrait;
use App\Entity\Traits\LockedTrait;
use App\Entity\Traits\TimestampTrait;
use App\Entity\Traits\TypeOfActTrait;
use App\Entity\Traits\UuidTrait;
use App\Entity\Traits\VersionTrait;
use App\Validator\Constraints as CustomAssert;
use DateTime;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

/**
 * @ORM\Entity(repositoryClass="App\Repository\EmailRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class Email implements TemplateInterface, ObjectAgencyInterface, CriteriaHolderInterface
{
    use HtmlContentTrait;
    use VersionTrait;
    use ActiveTrait;
    use LockedTrait;
    use TimestampTrait;
    use TypeOfActTrait;
    use IdTrait;
    use CompanyTrait;
    use CategoryTrait;
    use LanguageTrait;
    use CountryTrait;
    use UuidTrait;

    use ORMBehaviors\Translatable\Translatable;

    /**
     * @var EmailAgency[]
     *
     * @ORM\OneToMany(targetEntity="EmailAgency", mappedBy="email", cascade={"remove"})
     */
    protected $agencies;

    /**
     * Subject of email.
     *
     * @var string
     *
     * @CustomAssert\isValidTwigContent(groups={"template"})
     * @ORM\Column(name="subject", type="string", length=255)
     * @Assert\NotBlank()
     */
    protected $subject;

    /**
     * @var bool
     *
     * @ORM\Column(type="boolean")
     */
    protected $manual = true;

    /**
     * @var bool
     *
     * @ORM\Column(type="boolean")
     */
    protected $automatic = false;

    /**
     * @var bool
     *
     * @ORM\Column(type="boolean")
     */
    protected $scheduled = false;

    /**
     * @Assert\Valid
     */
    protected $translations;

    /**
     * @var ArrayCollection
     *
     * @Assert\Valid
     *
     * @ORM\OneToMany(targetEntity="EmailAttachment", mappedBy="email", cascade={"persist","remove"}, orphanRemoval=true)
     */
    protected $attachments;

    /**
     * @var ArrayCollection
     *
     * @ORM\ManyToMany(targetEntity="App\Entity\EmailTest")
     * @ORM\JoinTable(name="email_test_link")
     */
    protected $testEmails;

    /**
     * @var EmailSender
     *
     * @ORM\ManyToOne(targetEntity="App\Entity\EmailSender")
     */
    protected $sender;

    /**
     * @var ArrayCollection|ContractPackage[]
     *
     * @ORM\ManyToMany(targetEntity="App\Entity\ContractPackage", inversedBy="emails", cascade={"persist","remove"})
     * @ORM\JoinTable(name="email_contract_package_link")
     */
    protected $packages;

    /**
     * @var ArrayCollection|ContractPaymentStatus[]
     *
     * @ORM\ManyToMany(targetEntity="App\Entity\ContractPaymentStatus", cascade={"persist","remove"}, inversedBy="emails")
     * @ORM\JoinTable(name="email_contract_payment_status_link")
     */
    protected $paymentStatuses;

    /**
     * @var ArrayCollection|EmailContractStatus[]
     * @Assert\Valid
     * @ORM\OneToMany(targetEntity="App\Entity\EmailContractStatus", mappedBy="email", fetch="EXTRA_LAZY", orphanRemoval=true, cascade={"persist"})
     */
    protected $contractStatuses;

    /**
     * @var ArrayCollection|EmailContractEvent[]
     * @Assert\Valid
     * @ORM\OneToMany(targetEntity="App\Entity\EmailContractEvent", mappedBy="email", fetch="EXTRA_LAZY", orphanRemoval=true, cascade={"persist"})
     */
    protected $contractEvents;

    /**
     * Begin sending period
     * Can be empty.
     *
     * @var DateTime
     *
     * @ORM\Column(name="begin_send_period", type="datetime", nullable=true)
     */
    protected $beginSendPeriod;

    /**
     * End sending period
     * Can be empty.
     *
     * @var DateTime
     *
     * @ORM\Column(name="end_send_period", type="datetime", nullable=true)
     */
    protected $endSendPeriod;

    /**
     * Use for scheduler email (in queue).
     *
     * @var int
     * @Assert\NotNull()
     * @Assert\Type(type="integer")
     * @Assert\Length(max = 2)
     * @ORM\Column(type = "integer", options = {"unsigned": true, "default": 0})
     */
    protected $priority = 0;

    /**
     * Use for scheduler email (in queue).
     *
     * @var int
     * @Assert\NotNull()
     * @Assert\Type(type="integer")
     * @Assert\Regex(pattern = "/^[0-9]\d*$/", message = "Please use only positive numbers.")
     * @Assert\Length(max = 1)
     * @ORM\Column(type = "integer", options = {"unsigned": true, "default": 0})
     */
    protected $maxRetry = 0;

    public function __construct()
    {
        $this->agencies = new ArrayCollection();
        $this->attachments = new ArrayCollection();
        $this->testEmails = new ArrayCollection();
        $this->packages = new ArrayCollection();
        $this->paymentStatuses = new ArrayCollection();
        $this->contractStatuses = new ArrayCollection();
        $this->contractEvents = new ArrayCollection();
    }

    /**
     * @param $method
     * @param $arguments
     *
     * @return mixed
     */
    public function __call($method, $arguments)
    {
        return PropertyAccess::createPropertyAccessor()->getValue($this->translate(), $method);
    }

    /**
     * @return EmailAgency[]|Collection
     */
    public function getAgencies(): Collection
    {
        return $this->agencies;
    }

    /**
     * @param array $agencies
     *
     * @return ObjectAgencyInterface
     */
    public function setAgencies(array $agencies): ObjectAgencyInterface
    {
        $this->agencies = $agencies;

        return $this;
    }

    /**
     * @return EmailSender
     */
    public function getSender(): ?EmailSender
    {
        return $this->sender;
    }

    /**
     * @param EmailSender $sender
     *
     * @return Email
     */
    public function setSender(EmailSender $sender): Email
    {
        $this->sender = $sender;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getSubject(): ?string
    {
        return $this->subject;
    }

    /**
     * @param string $subject
     *
     * @return Email
     */
    public function setSubject(?string $subject): Email
    {
        $this->subject = $subject;

        return $this;
    }

    /**
     * @param EmailAttachment $attachment
     *
     * @return $this
     */
    public function addAttachment(EmailAttachment $attachment): self
    {
        $attachment->setEmail($this);
        if (!$this->attachments->contains($attachment)) {
            $this->attachments->add($attachment);
        }

        return $this;
    }

    /**
     * @param EmailAttachment $attachment
     */
    public function removeAttachment(EmailAttachment $attachment)
    {
        $this->attachments->removeElement($attachment);
    }

    /**
     * Get attachments.
     *
     * @return Collection
     */
    public function getAttachments(): Collection
    {
        return $this->attachments;
    }

    /**
     * @return Collection
     */
    public function getTestEmails(): Collection
    {
        return $this->testEmails;
    }

    /**
     * @param ArrayCollection $testEmails
     *
     * @return Email
     */
    public function setTestEmails(ArrayCollection $testEmails): Email
    {
        $this->testEmails = $testEmails;

        return $this;
    }

    public function __clone()
    {
        $this->id = null;
    }

    /**
     * @return string|null
     */
    public function __toString(): string
    {
        return $this->translate($this->getCurrentLocale())->getName() ?? '';
    }

    /**
     * @return ContractPackage[]|ArrayCollection
     */
    public function getPackages()
    {
        return $this->packages;
    }

    /**
     * @param ContractPackage[]|ArrayCollection $packages
     *
     * @return Email
     */
    public function setPackages($packages): Email
    {
        $this->packages = $packages;

        return $this;
    }

    /**
     * @return ArrayCollection|EmailContractStatus[]
     */
    public function getContractStatuses()
    {
        return $this->contractStatuses;
    }

    /**
     * @param EmailContractStatus[]|ArrayCollection $contractStatuses
     */
    public function setContractStatuses($contractStatuses): void
    {
        $this->contractStatuses = $contractStatuses;
    }

    /**
     * @param EmailContractStatus $contractStatus
     */
    public function addContractStatus(EmailContractStatus $contractStatus)
    {
        if ($this->contractStatuses->contains($contractStatus)) {
            return;
        }
        $this->contractStatuses[] = $contractStatus;
        $contractStatus->setEmail($this);
    }

    /**
     * @param EmailContractStatus $contractStatus
     */
    public function removeContractStatus(EmailContractStatus $contractStatus)
    {
        if (!$this->contractStatuses->contains($contractStatus)) {
            return;
        }
        $this->contractStatuses->removeElement($contractStatus);
        // not needed for persistence, just keeping both sides in sync
        $contractStatus->setEmail(null);
    }

    /**
     * @return ArrayCollection|ContractPaymentStatus[]
     */
    public function getPaymentStatuses(): Collection
    {
        return $this->paymentStatuses;
    }

    /**
     * @param ContractPaymentStatus[]|ArrayCollection $paymentStatuses
     */
    public function setPaymentStatuses($paymentStatuses): void
    {
        $this->paymentStatuses = $paymentStatuses;
    }

    /**
     * @return bool
     */
    public function isManual(): bool
    {
        return $this->manual;
    }

    /**
     * @param bool $manual
     *
     * @return Email
     */
    public function setManual(bool $manual): self
    {
        $this->manual = $manual;

        return $this;
    }

    /**
     * @return bool
     */
    public function isAutomatic(): bool
    {
        return $this->automatic;
    }

    /**
     * @param bool $automatic
     *
     * @return Email
     */
    public function setAutomatic(bool $automatic): self
    {
        $this->automatic = $automatic;

        return $this;
    }

    /**
     * @return bool
     */
    public function isScheduled(): bool
    {
        return $this->scheduled;
    }

    /**
     * @param bool $scheduled
     *
     * @return Email
     */
    public function setScheduled(bool $scheduled): self
    {
        $this->scheduled = $scheduled;

        return $this;
    }

    /**
     * @return ArrayCollection|EmailContractEvent[]
     */
    public function getContractEvents()
    {
        return $this->contractEvents;
    }

    /**
     * @param EmailContractEvent[]|ArrayCollection $contractEvents
     */
    public function setContractEvents($contractEvents): void
    {
        $this->contractEvents = $contractEvents;
    }

    /**
     * @param EmailContractEvent $contractEvent
     */
    public function addContractEvent(EmailContractEvent $contractEvent)
    {
        if ($this->contractEvents->contains($contractEvent)) {
            return;
        }
        $this->contractEvents[] = $contractEvent;
        $contractEvent->setEmail($this);
    }

    /**
     * @param EmailContractEvent $contractEvent
     */
    public function removeContractEvent(EmailContractEvent $contractEvent)
    {
        if (!$this->contractEvents->contains($contractEvent)) {
            return;
        }
        $this->contractEvents->removeElement($contractEvent);
        // not needed for persistence, just keeping both sides in sync
        $contractEvent->setEmail(null);
    }

    /**
     * @return string
     */
    public function getType(): string
    {
        return 'email';
    }

    /**
     * @return array
     */
    public function getCriteriaList(): array
    {
        return [
            self::CRITERIA['AGENCIES'],
            self::CRITERIA['COMPANY'],
            self::CRITERIA['CONTRACT_EVENTS'],
            self::CRITERIA['CONTRACT_STATUSES'],
            self::CRITERIA['COUNTRY'],
            self::CRITERIA['LANGUAGE'],
            self::CRITERIA['PACKAGES'],
            self::CRITERIA['PAYMENT_STATUSES'],
        ];
    }

    /**
     * @return DateTime
     */
    public function getBeginSendPeriod(): ?DateTime
    {
        return $this->beginSendPeriod;
    }

    /**
     * @param DateTime|null $beginSendPeriod
     *
     * @return Email
     */
    public function setBeginSendPeriod(?DateTime $beginSendPeriod): Email
    {
        $this->beginSendPeriod = $beginSendPeriod;

        return $this;
    }

    /**
     * @return DateTime
     */
    public function getEndSendPeriod(): ?DateTime
    {
        return $this->endSendPeriod;
    }

    /**
     * @param DateTime|null $endSendPeriod
     *
     * @return Email
     */
    public function setEndSendPeriod(?DateTime $endSendPeriod): Email
    {
        $this->endSendPeriod = $endSendPeriod;

        return $this;
    }

    /**
     * @return int
     */
    public function getPriority(): int
    {
        return $this->priority;
    }

    /**
     * @param int $priority
     *
     * @return Email
     */
    public function setPriority(int $priority): Email
    {
        $this->priority = $priority;

        return $this;
    }

    /**
     * @return int
     */
    public function getMaxRetry(): int
    {
        return $this->maxRetry;
    }

    /**
     * @param int $maxRetry
     *
     * @return Email
     */
    public function setMaxRetry(int $maxRetry): Email
    {
        $this->maxRetry = $maxRetry;

        return $this;
    }

    /**
     * @param ExecutionContextInterface $context
     * @param                           $payload
     *
     * @Assert\Callback
     */
    public function validate(ExecutionContextInterface $context, $payload)
    {
        if ($this->isAutomatic() && $this->isScheduled()) {
            $context->buildViolation('email.automatic_or_scheduled')
                ->addViolation();
        }
    }
}
