<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Entity\Traits\CodeTrait;
use App\Entity\Traits\ErpIdTrait;
use App\Entity\Traits\IdTrait;
use App\Entity\Traits\TimestampTrait;
use Doctrine\ORM\Mapping as ORM;

/**
 * Class Language
 * Data is synced from BAPPLI (erp service or rabbitmq).
 *
 * @ApiResource(
 *      itemOperations={"get"},
 *      collectionOperations={"get"},
 *      attributes={
 *          "normalization_context"={
 *              "groups"={"language:read", "code:read"},
 *              "swagger_definition_name"="Read"
 *          }
 *     }
 * )
 *
 * @ORM\Table(name="language",
 *     uniqueConstraints={
 *          @ORM\UniqueConstraint(name="erp_identifier_idx", columns={"erp_id"})
 *     }))
 * @ORM\Entity(repositoryClass="App\Repository\LanguageRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class Language
{
    const LANGUAGE_FR = 'fr';
    const LANGUAGE_EN = 'en';
    const LANGUAGE_ES = 'es';
    const LANGUAGE_NL_BE = 'nl_be';

    use IdTrait;
    use ErpIdTrait;
    use CodeTrait;
    use TimestampTrait;

    /**
     * @return string
     */
    public function __toString(): string
    {
        return $this->code;
    }
}
