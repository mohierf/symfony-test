<?php

namespace App\Entity;

use App\Entity\Traits\CodeTrait;
use App\Entity\Traits\TimestampTrait;
use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;
use Symfony\Component\PropertyAccess\PropertyAccess;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Category.
 * Data is synced from BAPPLI (erp service or rabbitmq).
 *
 * @ORM\Table(name="category")
 * @ORM\Entity(repositoryClass="App\Repository\CategoryRepository")
 * @ORM\HasLifecycleCallbacks()
 */
class Category
{
    use CodeTrait;
    use TimestampTrait;

    use ORMBehaviors\Translatable\Translatable;

    /**
     * Id (Coming from BAPPLI).
     *
     * @var int
     *
     * @ORM\Id
     * @ORM\Column(name="id", type="bigint", options={"unsigned"=true})
     */
    private $id;

    /**
     * @Assert\Valid
     */
    protected $translations;

    /**
     * @param $method
     * @param $arguments
     *
     * @return mixed
     */
    public function __call($method, $arguments)
    {
        return PropertyAccess::createPropertyAccessor()->getValue($this->translate(), $method);
    }

    /**
     * @return string
     */
    public function __toString(): ?string
    {
        return $this->code.'-'.$this->translate($this->getCurrentLocale())->getName() ?? '';
    }

    /**
     * @param int $id
     *
     * @return Category
     */
    public function setId(int $id): Category
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->id;
    }
}
