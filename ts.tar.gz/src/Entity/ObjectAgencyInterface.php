<?php

namespace App\Entity;

/**
 * Interface ObjectAgencyInterface.
 */
interface ObjectAgencyInterface
{
    /**
     * @return mixed
     */
    public function getAgencies();

    /**
     * @param array $agencies
     *
     * @return self
     */
    public function setAgencies(array $agencies): self;
}
