<?php

namespace App\Validator\Constraints;

use Symfony\Component\Validator\Constraint;

/**
 * @Annotation
 */
class isValidTwigContent extends Constraint
{
    public $message = 'The template is not valid';
}
