<?php

namespace App\Validator\Constraints;

use App\Entity\Document;
use App\Entity\Email;
use App\Entity\Template;
use App\Services\CustomVariableService;
use App\Services\TemplateService;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;
use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Error\SyntaxError;

/**
 * Class TwigValidator.
 */
class isValidTwigContentValidator extends ConstraintValidator
{
    /**
     * @var Environment
     */
    private $twig;

    /**
     * @var TemplateService
     */
    private $templateService;

    /**
     * @var CustomVariableService
     */
    private $customVariableService;

    /**
     * isValidTwigContentValidator constructor.
     *
     * @param Environment           $twig
     * @param TemplateService       $templateService
     * @param CustomVariableService $customVariableService
     */
    public function __construct(Environment $twig, TemplateService $templateService, CustomVariableService $customVariableService)
    {
        $this->twig = $twig;
        $this->templateService = $templateService;
        $this->customVariableService = $customVariableService;
    }

    /**
     * Checks if the passed value is valid.
     *
     * @param mixed      $value      The value that should be validated
     * @param Constraint $constraint The constraint for the validation
     *
     * @throws \Throwable
     */
    public function validate($value, Constraint $constraint): void
    {
        if (!$constraint instanceof isValidTwigContent) {
            throw new UnexpectedTypeException($constraint, isValidTwigContent::class);
        }

        if (null === $value || '' === $value) {
            return;
        }

        if (!\is_string($value)) {
            throw new UnexpectedTypeException($value, 'string');
        }

        /** @var Email|Document|Template $object */
        $object = $this->context->getObject();
        $context = array_merge(
            array_flip($this->templateService->getPlaceholders($object)),
            $this->customVariableService->getCustomVariablesNamesIndexedByStoreName($object)
        );

        try {
            $template = $this->twig->createTemplate($value);

            try {
                $template->render($context);
            } catch (RuntimeError $e) {
                $this->context->buildViolation($constraint->message.'. '.$e->getRawMessage())->addViolation();
            }
        } catch (LoaderError $e) {
            $this->context->buildViolation($e->getMessage())->addViolation();
        } catch (SyntaxError $e) {
            $this->context->buildViolation($e->getRawMessage())->addViolation();
        }
    }
}
