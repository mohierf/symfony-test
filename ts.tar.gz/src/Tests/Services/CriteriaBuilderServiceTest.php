<?php

namespace App\Tests\Services;

use App\Entity\CriteriaHolderInterface;
use App\Entity\Email;
use App\Services\CriteriaBuilderService;
use App\Tests\AbstractTestCase;

/**
 * Class CriteriaBuilderServiceTest.
 */
class CriteriaBuilderServiceTest extends AbstractTestCase
{
    /**
     * @throws \Exception
     */
    public function testArrayOfRulesGeneration(): void
    {
        /** @var CriteriaHolderInterface $email */
        $email = $this->getManager()->getRepository(Email::class)->findOneBy(['uuid' => '02f70e94-4086-4442-83e0-6e4b93c3a972']);

        /**
         * Create expected criteria json string. Need to calculate date.
         *
         * For periods, it is necessary to calculate the limits according to the date of the day and replace them in the file 'expectedCriteria.json'.
         * In fixtures, the following limits are used:
         * min : 10 days
         * max : 20 days
         */
        $currentDate = new \DateTimeImmutable('today');
        $expectedDateMin = $currentDate->sub(new \DateInterval('P10D'))->format('Y-m-d H:i:s');
        $expectedDateMax = $currentDate->sub(new \DateInterval('P20D'))->format('Y-m-d H:i:s');
        $expectedCriteriaJson = str_replace(
            ['$expectedDateMin', '$expectedDateMax'],
            [$expectedDateMin, $expectedDateMax],
            $this->getTestExpectedFileContent('builderCriteria.json')
        );

        /**
         * Get actual criteria json string.
         *
         * @var CriteriaBuilderService
         */
        $criteriaBuilderService = $this->getService(CriteriaBuilderService::class);
        $actualCriteriaJson = json_encode($criteriaBuilderService->getRules($email));

        $this->assertJsonStringEqualsJsonString($expectedCriteriaJson, $actualCriteriaJson);
    }
}
