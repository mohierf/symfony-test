<?php

namespace App\Tests;

use Symfony\Component\HttpFoundation\Response;

class ApplicationAvailabilityFunctionalTest extends AbstractTestCase
{
    /**
     * Test a page using data from urlProvider method.
     *
     * @param $login
     * @param $url
     * @param string $method
     * @param int    $returnCode
     * @param array  $getVars
     * @param array  $postVars
     *
     * @throws \Exception
     *
     * @dataProvider urlProvider
     */
    public function testPage($login, $url, $method = 'GET', $returnCode = 200, $getVars = [], $postVars = [])
    {
        $this->openPage($login, $url, $method, $returnCode, $getVars, $postVars);
    }

    public function urlProvider()
    {
        return [
            [null, '/', 'GET', Response::HTTP_FOUND],
            [null, '/login', 'GET', Response::HTTP_OK],
            [null, '/login-check', 'GET', Response::HTTP_METHOD_NOT_ALLOWED],
            [null, '/login-check', 'POST', Response::HTTP_FOUND],
            [null, '/login-check', 'POST', Response::HTTP_FOUND, ['_username' => 'user_test@user.com', '_password' => 'user_test']],
            [null, '/logout', 'GET', Response::HTTP_FOUND],
            ['user_test@user.com', '/test', 'GET', Response::HTTP_NOT_FOUND],
//            [null, '/register', 'GET', Response::HTTP_OK],
            [null, '/password-recovery', 'GET', Response::HTTP_OK],
        ];
    }
}
