<?php

namespace App\Tests\Command;

use App\Command\EmailScheduledCommand;
use App\Command\EmailScheduledPaginatedCommand;
use App\Command\EmailScheduledPaginatorCommand;
use App\Entity\EmailScheduledReport;
use App\MessageBuilder\EmailMessageBuilder;
use App\Producer\EmailMessageProducer;
use App\Services\ErpServiceClient;
use App\Tests\AbstractTestCase;
use JMS\JobQueueBundle\Entity\Job;
use Sfk\MailRouterMessages\Company;
use Sfk\MailRouterMessages\Model\TemplateDesigner\EmailType;
use Symfony\Bundle\FrameworkBundle\Console\Application;
use Symfony\Component\Console\Tester\CommandTester;

/**
 * Class SchedulerEmailContractPaginatorCommandTest.
 */
class EmailScheduledCommandTest extends AbstractTestCase
{
    const ITEMS_PER_PAGE = 1000;

    protected function mockEmailMessageBuilder()
    {
        $emailMessageBuilder = $this->getMockBuilder(EmailMessageBuilder::class)
            ->disableOriginalConstructor()
            ->setMethods(['buildData'])
            ->getMock();

        $emailMessageBuilder
            ->expects($this->exactly(self::ITEMS_PER_PAGE + 1))
            ->method('buildData')
            ->willReturnCallback(function () {
                $sender = [
                    'name' => 'testname',
                    'email' => 'test@email.com',
                ];

                return [
                    'version' => 1,
                    'creationTs' => time(),
                    'publicationTs' => time(),
                    'data' => [
                        'version' => 1,
                        'senderCompany' => Company::SFAM, // TODO : MAPPING $template->getCompany()->getCode();
                        'email' => [
                            'to' => [[
                                'name' => null,
                                'email' => 'testto1@email.com',
                            ]],
                            'bcc' => [],
                            'cc' => [],
                            'replyTo' => $sender,
                            'subject' => 'Test subject',
                            'htmlContent' => 'Test html content',
                            'sender' => $sender,
                        ],
                        'metadata' => [
                            'templateId' => 123456,
                            'contractId' => 654321,
                            'type' => EmailType::AUTOMATIC,
                        ],
                    ],
                ];
            });

        static::$kernel->getContainer()->set(EmailMessageBuilder::class, $emailMessageBuilder);
    }

    protected function mockErpServiceClient()
    {
        $erpServiceClient = $this->getMockBuilder(ErpServiceClient::class)
            ->disableOriginalConstructor()
            ->setMethods(['getContractCountForTemplate', 'getContractsForTemplateDesigner'])
            ->getMock();

        $erpServiceClient
            ->expects($this->once())
            ->method('getContractCountForTemplate')
            ->willReturnCallback(function () {
                return self::ITEMS_PER_PAGE + 1;
            });

        $erpServiceClient
            ->expects($this->exactly(2))
            ->method('getContractsForTemplateDesigner')
            ->willReturnCallback(function ($template, $page, $limit, $rules) {
                $count = 1 === $page ? self::ITEMS_PER_PAGE : (2 === $page ? 1 : 0);

                return array_fill(0, $count, ['from_test' => 'from_test']);
            });

        static::$kernel->getContainer()->set(ErpServiceClient::class, $erpServiceClient);
    }

    protected function runPaginatedJob($application, int $page)
    {
        $command = $application->find(EmailScheduledPaginatedCommand::getDefaultName());
        $commandTester = new CommandTester($command);
        $commandTester->execute([
                'command' => EmailScheduledPaginatedCommand::getDefaultName(),
            ] + [
                '--template' => 13,
                '--report' => 1,
                '--page' => $page,
                '--limit' => self::ITEMS_PER_PAGE,
                '--rules' => 'eyJ0YWJsZSI6Imluc3VyYW5jZSIsInNlYXJjaCI6eyJhbmQiOnsidmFsdWUiOlt7InRhYmxlIjoiY29tcGFueSIsInNlYXJjaCI6eyJlcSI6eyJjb2x1bW4iOiJpZCIsInR5cGUiOiJpbnRlZ2VyIiwidmFsdWUiOjQxMjMzfX19LHsidGFibGUiOiJjbGllbnRDb3VudHJ5Iiwic2VhcmNoIjp7ImVxIjp7ImNvbHVtbiI6ImlkIiwidHlwZSI6ImludGVnZXIiLCJ2YWx1ZSI6NzMzfX19LHsidGFibGUiOiJhZ2VuY3lMYW5ndWFnZSIsInNlYXJjaCI6eyJlcSI6eyJjb2x1bW4iOiJpZCIsInR5cGUiOiJpbnRlZ2VyIiwidmFsdWUiOjEwMjg0fX19XX19fQ==',
            ]);
    }

    public function testEmailScheduledCommand()
    {
        $this->mockErpServiceClient();
        $this->mockEmailMessageBuilder();
        $emailMessageProducer = static::$kernel->getContainer()->get(EmailMessageProducer::class);

        $application = new Application(static::$kernel);
        $command = $application->find(EmailScheduledCommand::getDefaultName());
        $commandTester = new CommandTester($command);
        $commandTester->execute([
            'command' => EmailScheduledCommand::getDefaultName(),
        ]);

        //
        // Run scheduled email command and Test count of paginator Jobs
        //
        $jobs = $this->getManager()->getRepository(Job::class)->findBy(['queue' => 'paginator']);
        $this->assertCount(13, $jobs);

        //
        // Run one Paginator Job and test Paginated jobs
        //
        $command = $application->find(EmailScheduledPaginatorCommand::getDefaultName());
        $commandTester = new CommandTester($command);
        $commandTester->execute([
            'command' => EmailScheduledPaginatorCommand::getDefaultName(),
            '--template' => 13,
        ]);

        $jobs = $this->getManager()->getRepository(Job::class)->findBy(['queue' => 'paginated']);
        $this->assertCount(2, $jobs);
        $this->assertEquals(120, $jobs[0]->getMaxRuntime());
        $this->assertEquals(Job::STATE_PENDING, $jobs[0]->getState());
        $this->assertEquals('app:scheduler:email-paginated', $jobs[0]->getCommand());
        $this->assertArraySubset([
            '--template=13',
            '--report=1',
            '--page=1',
            '--limit='.self::ITEMS_PER_PAGE,
        ], $jobs[0]->getArgs());

        //
        // Run paginated jobs, then EmailScheduledReport and RabbitMQ producer
        //
        $this->runPaginatedJob($application, 1);
        $report = $this->getManager()->getRepository(EmailScheduledReport::class)->find(1);
        $this->getManager()->refresh($report);
        $this->assertNotNull($report);
        $this->assertEquals(2, $report->getTotalPageTodo());
        $this->assertEquals(1, $report->getTotalPageSuccess());
        $this->assertEquals(0, $report->getTotalPageError());
        $this->assertEquals(0, $report->getTotalItemsError());
        $this->assertEquals(1000, $report->getTotalItemsSuccess());
        $this->assertEquals(EmailScheduledReport::STATUS_RUNNING, $report->getStatus());
        $this->assertNull($report->getFinishedAt());
        $this->assertCount(1000, $emailMessageProducer->getMessages());

        $this->runPaginatedJob($application, 2);
        $report = $this->getManager()->getRepository(EmailScheduledReport::class)->find(1);
        $this->getManager()->refresh($report);
        $this->assertNotNull($report);
        $this->assertEquals(2, $report->getTotalPageTodo());
        $this->assertEquals(2, $report->getTotalPageSuccess());
        $this->assertEquals(0, $report->getTotalPageError());
        $this->assertEquals(0, $report->getTotalItemsError());
        $this->assertEquals(1001, $report->getTotalItemsSuccess());
        $this->assertEquals(EmailScheduledReport::STATUS_SUCCESS, $report->getStatus());
        $this->assertNotNull($report->getFinishedAt());

        $this->assertCount(1001, $emailMessageProducer->getMessages());
    }
}
