<?php

namespace App\Tests;

use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Bundle\FrameworkBundle\Client;
use Symfony\Bundle\FrameworkBundle\Console\Application;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;
use Symfony\Component\BrowserKit\Cookie;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\StringInput;
use Symfony\Component\Console\Tester\CommandTester;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken;

abstract class AbstractTestCase extends WebTestCase
{
    const MAIN_FIREWALL = 'main';

    /**
     * @var RegistryInterface
     */
    private $doctrine;

    /**
     * @var EntityManagerInterface
     */
    private $entityManager;

    /**
     * @var Application
     */
    private static $application;

    /**
     * Get doctrine.
     *
     * @return RegistryInterface
     */
    protected function getDoctrine()
    {
        return $this->doctrine;
    }

    /**
     * Get entity manager.
     *
     * @return \Doctrine\ORM\EntityManager|EntityManagerInterface
     */
    protected function getManager()
    {
        return $this->entityManager;
    }

    /**
     * {@inheritdoc}
     *
     * @throws \Doctrine\DBAL\DBALException
     */
    protected function setUp()
    {
        static::bootKernel();
        $this->doctrine = static::$container->get('doctrine');
        $this->entityManager = $this->doctrine->getManager();
        $this->entityManager->getConnection()->exec('SET FOREIGN_KEY_CHECKS = 0;');
    }

    protected function getTestExpectedFileContent($fileName)
    {
        $path = sprintf(
            '%s/Resources/fixtures/test/expected/%s',
            self::getApplication()->getKernel()->getRootDir(),
            $fileName
        );

        return file_get_contents($path);
    }

    /**
     * @param $name
     *
     * @return object
     */
    protected function getService($name)
    {
        return static::$container->get($name);
    }

    /**
     * {@inheritdoc}
     */
    protected function tearDown()
    {
    }

    /**
     * @param string       $command
     * @param array        $paramOptions
     * @param Command|null $commandClass
     *
     * @return CommandTester
     */
    public function runCommandTester(string $command, array $paramOptions = [], Command $commandClass = null)
    {
        if (null === $commandClass) {
            $kernel = static::createKernel();
            $application = new Application($kernel);
            $finalCommand = $application->find($command);
            $commandTester = new CommandTester($finalCommand);
        } else {
            $finalCommand = $commandClass;
            $commandTester = new CommandTester($commandClass);
        }
        $commandTester->execute(array_merge(['command' => $finalCommand->getName()], $paramOptions));

        return $commandTester;
    }

    /**
     * @param $command
     *
     * @return int
     *
     * @throws \Exception
     */
    protected static function runCommand($command)
    {
        $command = sprintf('%s', $command);

        return self::getApplication()->run(new StringInput($command));
    }

    /**
     * Get application.
     *
     * @return Application
     */
    protected static function getApplication()
    {
        if (null === self::$application) {
            $client = static::createClient();
            self::$application = new Application($client->getKernel());
            self::$application->setAutoExit(false);
        }

        return self::$application;
    }

    /**
     * Check if an array of strings are in given content.
     *
     * @param string $content
     * @param array  $strings
     */
    protected function assertContainsStrings(string $content, array $strings = [])
    {
        foreach ($strings as $string) {
            $this->assertContains($string, $content);
        }
    }

    /**
     * Test a page with a specific login.
     *
     * @param string $login
     * @param string $url
     * @param string $method
     * @param int    $returnCode
     * @param array  $getVars
     * @param array  $postVars
     *
     * @throws \Exception on bad argument
     *
     * @return Client
     */
    protected function openPage($login, $url, $method = 'GET', $returnCode = 200, $getVars = [], $postVars = [])
    {
        if (!is_null($login)) {
            $client = $this->login($login);
        } else {
            $client = static::createClient();
        }
        switch ($method) {
            case 'GET':
                $client->request('GET', $url, $getVars);
                break;
            case 'POST':
                $client->request('POST', $url, array_merge($getVars, $postVars));
                break;
            default:
                throw new \Exception(sprintf('Invalid method for test request: %s', $method));
        }

        if ($client->getResponse()->getStatusCode() !== $returnCode) {
            var_dump($client->getResponse()->getContent());
        }

        $this->assertEquals($returnCode, $client->getResponse()->getStatusCode());

        return $client;
    }

    /**
     * Simulate login from a user.
     *
     * @param $username
     *
     * @return Client
     *
     * @throws \Doctrine\ORM\ORMException
     */
    protected function logIn($username)
    {
        $client = static::createClient();
        $session = $client->getContainer()->get('session');

        /* @var $user \App\Entity\User */
        $user = $this->entityManager
            ->getRepository(User::class)
            ->findOneByUsername($username);

        if (null === $user) {
            throw new NotFoundHttpException(sprintf('User not found: %s', $username));
        }

        $token = new UsernamePasswordToken($user, null, self::MAIN_FIREWALL, $user->getRoles());
        $session->set('_security_'.self::MAIN_FIREWALL, serialize($token));
        $session->save();

        $cookie = new Cookie($session->getName(), $session->getId());
        $client->getCookieJar()->set($cookie);

        return $client;
    }

    /**
     * @throws \Exception
     */
    public static function setUpBeforeClass()
    {
//        self::runCommand('doctrine:database:drop --force --if-exists');
//        self::runCommand('doctrine:database:create --if-not-exists');
//        self::runCommand('doctrine:schema:update --force');
//        static::$container->get('doctrine')->getConnection()->exec('SET FOREIGN_KEY_CHECKS = 0;');
//        self::runCommand('hautelook:fixtures:load -n');
    }

    /**
     * @throws \Exception
     */
    public static function tearDownAfterClass()
    {
//        self::runCommand('doctrine:database:drop --force');
    }
}
