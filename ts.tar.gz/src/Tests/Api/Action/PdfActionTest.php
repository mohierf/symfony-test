<?php

declare(strict_types=1);

namespace App\Tests\Api\Action;

use App\Api\Action\PdfFromTemplateAction;
use App\Entity\Template;
use App\Repository\TemplateRepository;
use App\Services\JsonSchemaService;
use App\Services\PdfGeneratorService;
use App\Tests\AbstractTestCase;
use GuzzleHttp\Psr7\Response;
use JsonSchema\Exception\InvalidSchemaException;
use PHPUnit\Framework\MockObject\MockObject;
use Sfk\Lib\ErpClient\ApiException;
use Symfony\Component\HttpFoundation\Request;
use Twig\Error\LoaderError;
use Twig\Error\SyntaxError;

/**
 * Class HubsideInvoicePdfActionTest.
 */
class PdfActionTest extends AbstractTestCase
{
    private const SCHEMA_NAME = 'HubsideInvoice';
    private const VALID_UUID = '4cfc94de-1917-45b6-9614-86c620649eee';
    private const JSON_PAYLOAD_FILENAME = 'hubsideInvoicePayload.json';

    /**
     * @throws ApiException
     * @throws LoaderError
     * @throws SyntaxError
     */
    public function testPostWithValidJsonData()
    {
        // Mock PdfGeneratorService because we don't want him to call, via HtmlToPdfService, the external ERP service
        /** @var PdfGeneratorService|MockObject $pdfGeneratorService */
        $pdfGeneratorService = $this->getMockBuilder(PdfGeneratorService::class)
            ->disableOriginalConstructor()
            ->setMethods(['generate'])
            ->getMock();

        $pdfGeneratorService
            ->method('generate')
            ->willReturn(
                new Response(
                    200,
                    [
                        'Content-Type' => 'application/pdf',
                        'Content-Disposition' => 'attachment; 4cfc94de-1917-45b6-9614-86c620649eee-20190308-143358.pdf',
                    ]
                )
            );

        $url = sprintf('/api/template/%s/pdf', self::VALID_UUID);
        $validJson = $this->getTestExpectedFileContent(self::JSON_PAYLOAD_FILENAME);
        $template = $this->getManager()->getRepository(Template::class)->findOneBy(['uuid' => self::VALID_UUID]);
        $request = Request::create($url, 'POST', [], [], [], [], $validJson);

        /** @var Response $response */
        $response = (new PdfFromTemplateAction())($template, $request, $pdfGeneratorService);

        $this->assertEquals(200, $response->getStatusCode());
    }

    public function testValidJsonDataReturnTrue()
    {
        $jsonSchemaService = self::$container->get(JsonSchemaService::class);
        $templateRepository = self::$container->get(TemplateRepository::class);
        /** @var Template $template */
        $template = $templateRepository->findOneBy(['uuid' => self::VALID_UUID]);
        $jsonSchema = $template->getJsonSchema();
        $validJson = $this->getTestExpectedFileContent(self::JSON_PAYLOAD_FILENAME);
        $this->assertTrue($jsonSchemaService->validate($validJson, $jsonSchema));
    }

    public function testInvalidJsonDataThrowInvalidSchemaException()
    {
        $jsonSchemaService = self::$container->get(JsonSchemaService::class);
        $templateRepository = self::$container->get(TemplateRepository::class);
        /** @var Template $template */
        $template = $templateRepository->findOneBy(['uuid' => self::VALID_UUID]);
        $jsonSchema = $template->getJsonSchema();
        $invalidJson = '{"item": "invalid"}';
        $this->expectException(InvalidSchemaException::class);
        $jsonSchemaService->validate($invalidJson, $jsonSchema);
    }
}
