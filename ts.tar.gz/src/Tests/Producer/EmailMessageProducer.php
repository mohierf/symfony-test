<?php

namespace App\Tests\Producer;

use App\Producer\EmailMessageProducerInterface;

/**
 * Class EmailMessageProducer.
 */
class EmailMessageProducer implements EmailMessageProducerInterface
{
    /**
     * @var array
     */
    protected $messages = [];

    /**
     * @param string $message
     * @param string $routingKey
     * @param array  $additionalProperties
     *
     * @return mixed|void
     *
     * @throws \Exception
     */
    public function publish(string $message, $routingKey = '', array $additionalProperties = [])
    {
        $this->messages[] = $message;
    }

    /**
     * @return array
     */
    public function getMessages(): array
    {
        return $this->messages;
    }
}
