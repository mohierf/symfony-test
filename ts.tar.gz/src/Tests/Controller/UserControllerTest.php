<?php

namespace App\Tests\Controller;

use App\Tests\AbstractTestCase;
use Symfony\Component\HttpFoundation\Response;

class UserControllerTest extends AbstractTestCase
{
    /**
     * @throws \Doctrine\ORM\ORMException
     */
    public function testUserList()
    {
        $client = $this->logIn('user_test@user.com');
        $client->request('GET', '/admin/user/list');
        $this->assertEquals(Response::HTTP_FORBIDDEN, $client->getResponse()->getStatusCode());

        $client = $this->logIn('admin_test@admin.com');
        $client->request('GET', '/admin/user/list');
        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());

        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Login',
            'prénom',
            'Liste des utilisateurs',
        ]);
    }

    /**
     * @throws \Doctrine\ORM\ORMException
     */
    public function testGroupList()
    {
        $client = $this->logIn('user_test@user.com');
        $client->request('GET', '/admin/group/list');
        $this->assertEquals(Response::HTTP_FORBIDDEN, $client->getResponse()->getStatusCode());

        $client = $this->logIn('admin_test@admin.com');
        $client->request('GET', '/admin/group/list');
        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());

        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Groupe',
            'Utilisateurs',
            'Liste des groupes',
        ]);
    }
}
