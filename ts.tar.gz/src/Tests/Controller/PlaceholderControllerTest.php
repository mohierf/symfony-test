<?php

namespace App\Tests\Controller;

use App\Tests\AbstractTestCase;
use Symfony\Component\HttpFoundation\Response;

class PlaceholderControllerTest extends AbstractTestCase
{
    public function testAll()
    {
        $client = $this->logIn('user_test@user.com');

        // Test list
        $client->request('GET', '/placeholder/');
        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());

        $client->request('GET', '/placeholder/');
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'placeholder.list',
        ]);
    }
}
