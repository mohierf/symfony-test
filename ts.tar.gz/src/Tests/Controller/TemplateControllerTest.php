<?php

namespace App\Tests\Controller;

use App\Tests\AbstractTestCase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Class InvoiceControllerTest.
 */
class TemplateControllerTest extends AbstractTestCase
{
    public function testAll(): void
    {
        $client = $this->logIn('user_test@user.com');
        $client->followRedirects(true);

        // Test list
        $client->request('GET', '/template/');
        $this->assertEquals(Response::HTTP_FORBIDDEN, $client->getResponse()->getStatusCode());

        $client = $this->logIn('admin_test@admin.com');
        $client->followRedirects(true);

        // Test list
        $crawler = $client->request('GET', '/template/');
        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());
        $this->assertContainsStrings(
            $client->getResponse()->getContent(),
            [
                'template.list',
                'Template 1',
                'Template 2',
                'Nouveau',
            ]
        );

        // Test Create
        $crawler = $client->request('GET', '/template/new');
        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());
        $this->assertContainsStrings(
            $client->getResponse()->getContent(),
            [
                'template.new',
                'Verrouillé',
                'Actif',
                'Enregistrer',
                'Retour à la liste',
            ]
        );

        $form = $crawler->selectButton('Enregistrer')->form();
        $form->setValues(
            [
                'template[template][translations][fr][name]' => 'Template test',
                'template[company]' => 1,
                'template[language]' => 1,
            ]
        );
        $client->submit($form);
        $crawler = $client->getCrawler();
        $this->assertContainsStrings(
            $client->getResponse()->getContent(),
            [
                'Retour à la liste',
                'Template test',
                'Supprimer',
            ]
        );
        $link = $crawler->selectLink('Retour à la liste')->eq(0)->link();
        $crawler = $client->click($link);

        $link = $crawler->selectLink('Template test')->eq(0)->link();
        $client->click($link);
        $this->assertContainsStrings(
            $client->getResponse()->getContent(),
            [
//            'agency 1000 (agency)',
//            'agency 10000 (agency)',
//            'agency 10001 (agency)',
//            'agency 10002 (agency)',
//            'agency 10003 (agency)',
//            'agency 10004 (agency)',
//            'agency 10005 (agency)',
//            'agency 103 (main_agency)',
//            'agency 104 (main_agency)',
//            'agency 10 (group_agency)',
//            'agency 15 (group_agency)',
//            'test2@sfam.eu',
            ]
        );

        // Test Delete
        $crawler = $client->request('GET', '/template/');

        $link = $crawler->filter('a[title="Modifier"]')->eq(1)->link();
        $crawler = $client->click($link);
        $this->assertContainsStrings(
            $client->getResponse()->getContent(),
            [
                'template.edit',
                'Template 2',
                'Supprimer',
            ]
        );

        $deleteForm = $crawler->selectButton('Supprimer')->form();
        $client->submit($deleteForm);

        $this->assertContainsStrings(
            $client->getResponse()->getContent(),
            [
                'template.list',
                'Template 1',
            ]
        );
        $this->assertNotContains('Template 2', $client->getResponse()->getContent());
    }
}
