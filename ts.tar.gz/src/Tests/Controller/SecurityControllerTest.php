<?php

namespace App\Tests\Controller;

use App\Entity\User;
use App\Tests\AbstractTestCase;
use Symfony\Component\HttpFoundation\Response;

class SecurityControllerTest extends AbstractTestCase
{
    /**
     * {@inheritdoc}
     */
    protected function tearDown()
    {
        $entityManager = $this->getManager();
        $users = $entityManager->getRepository(User::class)->findByUsername('jean.dupond@test.com');
        if (!empty($users)) {
            foreach ($users as $user) {
                $entityManager->remove($user);
            }
            $entityManager->flush();
        }
    }

    public function testLogin()
    {
        $client = static::createClient();
        $client->followRedirects(true);

        /*
         * Access to login page with / url:
         *   => redirection to /login
         */
        $client->request('GET', '/');
        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());
        $this->assertContains('Connexion', $client->getResponse()->getContent());

        /**
         * Login with a bad user:
         *  => access to login page at /login
         *    -> submit form with invalid credentials
         *    -> show an error message after redirection from /login_check to /login.
         */
        $crawler = $client->request('GET', '/login');
        $this->assertEquals(200, $client->getResponse()->getStatusCode());
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Connexion',
//            'Inscription',
            'Récupération du mot de passe',
        ]);

        $formLogin = $crawler->selectButton('Connexion')->form();
        $formLogin['_username']->setValue('invalid');
        $formLogin['_password']->setValue('test');
        $client->submit($formLogin);

        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());
        $this->assertContains('Identifiants invalides.', $client->getResponse()->getContent());
    }

    // REGISTRATION DISABLED
//    public function testRegister()
//    {
//        $client = static::createClient();
//        $entityManager = $this->getManager();
//
//        /**
//         * Register a new user:
//         *   Form POST OK
//         *   Redirection to page with mail message
//         *   User created in database.
//         */
//        $crawler = $client->request('GET', '/register');
//        $this->assertEquals(200, $client->getResponse()->getStatusCode());
//        $this->assertContainsStrings($client->getResponse()->getContent(), [
//            'Inscription',
//            'S&#039;inscrire',
//            'Connexion',
//        ]);
//
//        $formRegister = $crawler->selectButton('S\'inscrire')->form();
//        $formRegisterData = $formRegister->get('register');
//        $formRegisterData['firstName']->setValue('jean');
//        $formRegisterData['lastName']->setValue('dupond');
//        $formRegisterData['username']->setValue('jean.dupond@test.com');
//
//        $client->submit($formRegister);
//        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());
//        $this->assertContains('Un e-mail a été envoyé à l&#039;adresse jean.dupond@test.com', $client->getResponse()->getContent());
//
//        $users = $entityManager->getRepository(User::class)->findByUsername('jean.dupond@test.com');
//        $this->assertCount(1, $users);
//        $this->assertEquals('jean.dupond@test.com', $users[0]->getUsername());
//
//        /**
//         * Register an existing user:
//         *   Form POST OK
//         *   Redirection on the same page with error message
//         *   User NOT created in database.
//         */
//        $crawler = $client->request('GET', '/register');
//        $formRegister = $crawler->selectButton('S\'inscrire')->form();
//        $formRegisterData = $formRegister->get('register');
//        $formRegisterData['firstName']->setValue('jean');
//        $formRegisterData['lastName']->setValue('dupond');
//        $formRegisterData['username']->setValue('jean.dupond@test.com');
//
//        $client->submit($formRegister);
//        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());
//        $this->assertContainsStrings($client->getResponse()->getContent(), [
//            'Inscription',
//            'S&#039;inscrire',
//            'Connexion',
//            'Cette valeur est déjà utilisée.',
//        ]);
//
//        $users = $entityManager->getRepository(User::class)->findByUsername('jean.dupond@test.com');
//        $this->assertCount(1, $users);
//    }
}
