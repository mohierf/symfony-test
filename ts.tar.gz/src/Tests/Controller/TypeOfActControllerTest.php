<?php

namespace App\Tests\Controller;

use App\Tests\AbstractTestCase;
use Symfony\Component\HttpFoundation\Response;

class TypeOfActControllerTest extends AbstractTestCase
{
    public function testAll()
    {
        $client = $this->logIn('user_test@user.com');
        $client->followRedirects(true);

        // Test list
        $client->request('GET', '/type-of-act/');
        $this->assertEquals(Response::HTTP_FORBIDDEN, $client->getResponse()->getStatusCode());

        $client = $this->logIn('admin_test@admin.com');

        // Test list
        $crawler = $client->request('GET', '/type-of-act/');
        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'insurance',
            'website',
            'privilege',
            'Show',
            'Modifier',
            'Nouveau',
        ]);

        // Test Show
        $link = $crawler->selectLink('Show')->eq(0)->link();
        $client->click($link);
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Id',
            'Name',
            'insurance',
            'Delete',
        ]);

        // Test Create
        $crawler = $client->request('GET', '/type-of-act/');
        $link = $crawler->selectLink('Nouveau')->eq(0)->link();
        $crawler = $client->click($link);
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'type_of_act.new',
            'Retour à la liste',
            'Name',
            'Save',
        ]);
        $form = $crawler->selectButton('Save')->form();
        $form->setValues([
            'type_of_act[name]' => 'Test type of act',
        ]);
        $client->submit($form);
        $client->followRedirect();
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'TypeOfAct index',
            'Test type of act',
        ]);

        // Test Delete
        $crawler = $client->request('GET', '/type-of-act/');
        $link = $crawler->selectLink('Show')->eq(3)->link();
        $crawler = $client->click($link);
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Id',
            'Name',
            'Test type of act',
            'Delete',
        ]);

        $deleteForm = $crawler->selectButton('Delete')->form();
        $client->submit($deleteForm);
        $client->followRedirect();
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'TypeOfAct index',
            'insurance',
            'privilege',
            'website',
        ]);
        $this->assertNotContains('Test type of act', $client->getResponse()->getContent());
    }
}
