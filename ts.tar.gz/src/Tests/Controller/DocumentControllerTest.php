<?php

namespace App\Tests\Controller;

use App\Tests\AbstractTestCase;
use Symfony\Component\HttpFoundation\Response;

class DocumentControllerTest extends AbstractTestCase
{
    public function testAll()
    {
        $client = $this->logIn('user_test@user.com');
        $client->followRedirects(true);

        // Test list
        $client->request('GET', '/document/');
        $this->assertEquals(Response::HTTP_FORBIDDEN, $client->getResponse()->getStatusCode());

        $client = $this->logIn('admin_test@admin.com');

        // Test list
        $crawler = $client->request('GET', '/document/');
        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Liste des documents',
            'Document 1',
            'Document 5',
            'Nouveau',
        ]);

        // Test Create
        $link = $crawler->selectLink('Nouveau')->eq(0)->link();
        $crawler = $client->click($link);
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'document.new',
            'Agences',
            'Têtes de groupe',
            'Groupes',
            'Verrouillé',
            'Actif',
            'Enregistrer',
            'Retour à la liste',
        ]);

        $form = $crawler->selectButton('Enregistrer')->form();
        $form->setValues([
            'document[template][translations][fr][name]' => 'Document test',
            'document[agencyFields][agencies]' => [13, 19, 20, 18],
            'document[agencyFields][mainAgencies]' => [7, 8, 9, 10, 11, 12],
            'document[agencyFields][groupAgencies]' => [1, 2, 6],
        ]);
        $client->submit($form);
        $client->followRedirect();
        $crawler = $client->getCrawler();
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Retour à la liste',
            'Document test',
            'Supprimer',
        ]);

        $link = $crawler->selectLink('Retour à la liste')->eq(0)->link();
        $crawler = $client->click($link);

        $link = $crawler->selectLink('Document test')->eq(0)->link();
        $client->click($link);
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'agency 1000 (agency)',
            'agency 10000 (agency)',
            'agency 10001 (agency)',
            'agency 1005 (agency)',
            'agency 100 (main_agency)',
            'agency 101 (main_agency)',
            'agency 102 (main_agency)',
            'agency 103 (main_agency)',
            'agency 104 (main_agency)',
            'agency 105 (main_agency)',
            'agency 10 (group_agency)',
            'agency 11 (group_agency)',
            'agency 15 (group_agency)',
        ]);

        // Test Delete
        $crawler = $client->request('GET', '/document/');
        $link = $crawler->filter('a[title="Modifier"]')->eq(2)->link();
        $crawler = $client->click($link);
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Editer le document',
            'Document 2',
            'Supprimer',
        ]);

        $deleteForm = $crawler->selectButton('Supprimer')->form();
        $client->submit($deleteForm);
        $client->followRedirect();
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Liste des documents',
            'Document 1',
        ]);
        $this->assertNotContains('Document 2', $client->getResponse()->getContent());
    }
}
