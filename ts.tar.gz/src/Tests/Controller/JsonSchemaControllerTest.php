<?php

namespace App\Tests\Controller;

use App\Tests\AbstractTestCase;
use Symfony\Component\HttpFoundation\Response;

class JsonSchemaControllerTest extends AbstractTestCase
{
    public function testAll()
    {
        $client = $this->logIn('user_test@user.com');
        $client->followRedirects(true);

        // Test list
        $client->request('GET', '/schemas/');
        $this->assertEquals(Response::HTTP_FORBIDDEN, $client->getResponse()->getStatusCode());

        $client = $this->logIn('admin_test@admin.com');
        $client->followRedirects(true);

        // Test list
        $crawler = $client->request('GET', '/schemas/');
        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Liste des schémas',
            'HubsideInvoice',
            'PaymentSchedule',
            'Nouveau',
        ]);

        // Test Create
        $crawler = $client->request('GET', '/schemas/');
        $link = $crawler->selectLink('Nouveau')->eq(0)->link();
        $crawler = $client->click($link);
        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Créer un nouveau schéma',
            'Paramétrage',
            'Nom',
            'Contenu',
            'Enregistrer',
            'Retour à la liste',
        ]);

        // Fill and submit the form
        $form = $crawler->selectButton('Enregistrer')->form();
        $form->setValues([
            'json_schema[name]' => 'A new json schema',
            'json_schema[content]' => '{
  "array": [
    1,
    2,
    3
  ],
  "boolean": true,
  "color": "#82b92c",
  "null": null,
  "number": 123,
  "object": {
    "a": "b",
    "c": "d",
    "e": "f"
  },
  "string": "Hello World"
}',
        ]);
        $client->submit($form);

        // Back to the list
        $crawler = $client->getCrawler();
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Liste des schémas',
            'HubsideInvoice',
            'PaymentSchedule',
            'A new json schema',
            'Nouveau',
        ]);

        // View the new item
        $link = $crawler->filter('a[href="/schemas/3"]')->link();
        $client->click($link);
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Voir le schéma',
            '<th>Id</th>',
            '<td>3</td>',
            '<th>Nom</th>',
            '<td>A new json schema</td>',
            'Retour à la liste',
            'Supprimer',
        ]);

        // Edit the new item
        $crawler = $client->request('GET', '/schemas/');
        $link = $crawler->filter('a[href="/schemas/3/edit"]')->link();
        $client->click($link);
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Editer le schéma',
            '<div id="json_schema"><div class="form-group">',
            'id="json_schema_name"',
            'id="json_schema_content"',
            '&quot;Hello World&quot;',
            'Retour à la liste',
            'Supprimer',
        ]);

        // Test Delete
        $crawler = $client->request('GET', '/schemas/');
        $link = $crawler->filter('a[href="/schemas/3/edit"]')->link();
        $crawler = $client->click($link);
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Editer le schéma',
            'Supprimer',
        ]);

        $deleteForm = $crawler->selectButton('Supprimer')->form();
        $client->submit($deleteForm);

        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Liste des schémas',
            'HubsideInvoice',
            'PaymentSchedule',
            'Nouveau',
        ]);
        $this->assertNotContains('A new json schema', $client->getResponse()->getContent());
    }
}
