<?php

namespace App\Tests\Controller;

use App\Tests\AbstractTestCase;
use Symfony\Component\HttpFoundation\Response;

class EmailControllerTest extends AbstractTestCase
{
    public function testAll()
    {
        $client = $this->logIn('user_test@user.com');
        $client->followRedirects(true);

        // Test list
        $client->request('GET', '/email/');
        $this->assertEquals(Response::HTTP_FORBIDDEN, $client->getResponse()->getStatusCode());

        $client = $this->logIn('admin_test@admin.com');
        $client->followRedirects(true);

        // Test list
        $crawler = $client->request('GET', '/email/');
        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Liste des emails',
            'Email 1',
            'Email 2',
            'Email 4',
            'Nouveau',
        ]);

        // Test Create
        $crawler = $client->request('GET', '/email/new/1');
        $this->assertEquals(Response::HTTP_OK, $client->getResponse()->getStatusCode());
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Assurance',
            'email.new',
            'Agences',
            'Têtes de groupe',
            'Groupes',
            'Verrouillé',
            'Actif',
            'Enregistrer',
            'Retour à la liste',
        ]);

        $form = $crawler->selectButton('Enregistrer')->form();
        $form->setValues([
            'email[sender]' => 1,
            'email[subject]' => 'Test subject',
            'email[testEmails]' => [2],
            'email[template][translations][fr][name]' => 'Email test',
            'email[company]' => 1,
            'email[language]' => 1,
            'email[country]' => 1,
            'email[agencyFields][agencies]' => [13, 19, 20, 21, 22, 23, 24],
            'email[agencyFields][mainAgencies]' => [10, 11],
            'email[agencyFields][groupAgencies]' => [1, 6],
        ]);
        $client->submit($form);
        $crawler = $client->getCrawler();
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Retour à la liste',
            'Email test',
            'Service client test assurance',
            'Test subject',
            'Supprimer',
        ]);
        $link = $crawler->selectLink('Retour à la liste')->eq(0)->link();
        $crawler = $client->click($link);

        $link = $crawler->selectLink('Email test')->eq(0)->link();
        $client->click($link);
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'agency 1000 (agency)',
            'agency 10000 (agency)',
            'agency 10001 (agency)',
            'agency 10002 (agency)',
            'agency 10003 (agency)',
            'agency 10004 (agency)',
            'agency 10005 (agency)',
            'agency 103 (main_agency)',
            'agency 104 (main_agency)',
            'agency 10 (group_agency)',
            'agency 15 (group_agency)',
            'test2@sfam.eu',
        ]);

        // Test Delete
        $crawler = $client->request('GET', '/email/');

        $link = $crawler->filter('a[title="Modifier"]')->eq(1)->link();
        $crawler = $client->click($link);
        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Editer l&#039;email',
            'Email 2',
            'Supprimer',
        ]);

        $deleteForm = $crawler->selectButton('Supprimer')->form();
        $client->submit($deleteForm);

        $this->assertContainsStrings($client->getResponse()->getContent(), [
            'Liste des emails',
            'Email 1',
        ]);
        $this->assertNotContains('Email 2', $client->getResponse()->getContent());
    }
}
