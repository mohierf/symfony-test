<?php

namespace App\Tests\Repository;

use App\Entity\Email;
use App\Entity\TypeOfAct;
use App\Exception\MissingErpDataException;
use App\Tests\AbstractTestCase;
use DateTime;
use Exception;
use Sfk\Lib\ErpClient\Model\AddressClientRead;
use Sfk\Lib\ErpClient\Model\AddressRead;
use Sfk\Lib\ErpClient\Model\AgencyRead;
use Sfk\Lib\ErpClient\Model\CityRead;
use Sfk\Lib\ErpClient\Model\ClientRead;
use Sfk\Lib\ErpClient\Model\CompanyRead;
use Sfk\Lib\ErpClient\Model\CountryRead;
use Sfk\Lib\ErpClient\Model\InsuranceContractPackageRead;
use Sfk\Lib\ErpClient\Model\InsuranceContractRead;
use Sfk\Lib\ErpClient\Model\InsuranceEventRead;
use Sfk\Lib\ErpClient\Model\InsuranceEventTypeRead;
use Sfk\Lib\ErpClient\Model\LanguageRead;
use TypeError;

/**
 * Class EmailRepositoryTest.
 */
class EmailRepositoryTest extends AbstractTestCase
{
    private const ANY_STRING = 'wxyz';

    private const BASE_TEMPLATE = '582d2772-3c3d-42a5-b35f-d7e83eeece67';
    private const TEMPLATE_WITHOUT_PAYMENT_STATUS = 'e77eeaf6-bdb8-429f-ad31-bd5d04ab1e3d';
    private const TEMPLATE_WITHOUT_STATUS = '08436926-5abb-4ad3-a80b-8e748e7dd70c';
    private const TEMPLATE_WITH_AGENCY = 'e8a12eec-2189-41de-a419-6c5283776c1e';
    private const TEMPLATE_WITH_MAIN_AGENCY = '63e20bbb-fb74-44ba-8618-eec58ede5561';
    private const TEMPLATE_WITH_GROUP_AGENCY = 'f5f80747-f52c-45fb-b652-ddfe70c6020f';
    private const TEMPLATE_WITHOUT_AGENCIES = '992de3b3-26d2-4107-9e23-da80746034f8';
    private const TEMPLATE_WITH_EVENT = 'a46a99c0-e2fc-4207-829c-1563ee1fba5b';
    private const TEMPLATE_WITH_PERIOD = '7a4aadd2-1aa6-4e2c-8d31-7509e59dc2b5';
    private const TEMPLATE_WITH_SENDING_PERIOD_TO_COME = 'ffe45fa9-6a85-4bcc-92a0-c69ac82fb4e4';
    private const TEMPLATE_WITH_EXPIRED_SENDING_PERIOD = '4696deb7-a523-427f-83ca-89f6aa14cb88';
    private const CONTRACT
        = [
            'AGENCY_ID' => '16',
            'MAIN_AGENCY_ID' => '17',
            'GROUP_AGENCY_ID' => '18',
            'COMPANY_ID' => '10000',
            'PACKAGE_ID' => '10003',
            'AGENCY_LANGUAGE_ID' => '10000',
            'CLIENT_COUNTRY_ID' => '100',
            'CLIENT_ADDRESS_TYPE' => 'client',
            'CONTRACT_PAYMENT_STATUS' => 'valid',
            'CONTRACT_STATUS' => 'valid',
            'EVENT_TYPE_ID' => '10',
            'EVENT_STATUS' => 'pending',
        ];

    /**
     * @var InsuranceContractRead
     */
    private $contract;

    /**
     * @var string
     */
    private $typeOfAct = TypeOfAct::INSURANCE;

    /**
     * @var string
     */
    private $category = 'SIGN';

    public function setUp()
    {
        parent::setUp();
        $this->initTestContract();
    }

    public function initTestContract(): void
    {
        $agency = (new AgencyRead())
            ->setId(self::CONTRACT['AGENCY_ID'])
            ->setLanguage((new LanguageRead())->setId(self::CONTRACT['AGENCY_LANGUAGE_ID']));

        $company = (new CompanyRead())->setId(self::CONTRACT['COMPANY_ID']);
        $package = (new InsuranceContractPackageRead())->setId(self::CONTRACT['PACKAGE_ID']);
        $address = (new AddressRead())->setCity((new CityRead())->setCountry((new CountryRead())->setId(self::CONTRACT['CLIENT_COUNTRY_ID'])));
        $clientAddress = (new AddressClientRead())->setAddress($address);
        $clientAddress->setType(self::CONTRACT['CLIENT_ADDRESS_TYPE']);

        $contract = new InsuranceContractRead();
        $contract->setAgency($agency);
        $contract->setCompany($company);
        $contract->setPackage($package);
        $contract->setStatus(self::CONTRACT['CONTRACT_STATUS']);
        $contract->setPaymentStatus(self::CONTRACT['CONTRACT_PAYMENT_STATUS']);
        $contract->setClient((new ClientRead())->setAddresses([$clientAddress]));

        $contract->setEvents([]);

        $this->contract = $contract;
    }

    /**
     * @throws Exception
     */
    public function testSampleContractMatchesSampleAutomaticTemplate(): void
    {
        $this->assertContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
        $this->assertContains(self::TEMPLATE_WITHOUT_STATUS, $this->getMatchingTemplatesUuids());
        $this->assertContains(self::TEMPLATE_WITHOUT_PAYMENT_STATUS, $this->getMatchingTemplatesUuids());
    }

    /**
     * @return array
     *
     * @throws Exception
     */
    public function getMatchingTemplatesUuids(): array
    {
        $templates = $this->getManager()->getRepository(Email::class)->findMatchingTemplates($this->contract, $this->typeOfAct, $this->category);

        return array_map(
            static function ($e) {
                /* @var Email $e */
                return $e->getUuid()->toString();
            },
            $templates
        );
    }

    /**
     * STATUS.
     */

    /**
     * @throws Exception
     */
    public function testBadStatusDoesNotMatchTemplateWithStatus(): void
    {
        $this->contract->setStatus(self::ANY_STRING);
        $this->assertNotContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testAnyStatusMatchesTemplateWithoutStatus(): void
    {
        $this->contract->setStatus(self::ANY_STRING);
        $this->assertContains(self::TEMPLATE_WITHOUT_STATUS, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testNullStatusDoesNotMatchTemplateWithStatus(): void
    {
        $this->contract->setStatus(null);
        $this->assertNotContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testNullPaymentStatusMatchesTemplateWithoutStatus(): void
    {
        $this->contract->setStatus(null);
        $this->assertContains(self::TEMPLATE_WITHOUT_STATUS, $this->getMatchingTemplatesUuids());
    }

    /**
     * PAYMENT STATUS.
     */

    /**
     * @throws Exception
     */
    public function testBadPaymentStatusDoesNotMatchTemplateWithPaymentStatus(): void
    {
        $this->contract->setPaymentStatus(self::ANY_STRING);
        $this->assertNotContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testAnyPaymentStatusMatchesTemplateWithoutPaymentStatus(): void
    {
        $this->contract->setPaymentStatus(self::ANY_STRING);
        $this->assertContains(self::TEMPLATE_WITHOUT_PAYMENT_STATUS, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testNullPaymentStatusDoesNotMatchTemplateWithPaymentStatus(): void
    {
        $this->contract->setPaymentStatus(null);
        $this->assertNotContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testNullPaymentStatusMatchesTemplateWithoutPaymentStatus(): void
    {
        $this->contract->setPaymentStatus(null);
        $this->assertContains(self::TEMPLATE_WITHOUT_PAYMENT_STATUS, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testPackageIdDoesNotMatch(): void
    {
        $badPackage = (new InsuranceContractPackageRead())->setId(self::ANY_STRING);
        $this->contract->setPackage($badPackage);
        $this->assertNotContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testLanguageDoesNotMatch(): void
    {
        $agencyWithBadLanguage = (new AgencyRead())->setLanguage((new LanguageRead())->setId(self::ANY_STRING));
        $this->contract->setAgency($agencyWithBadLanguage);
        $this->assertNotContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testCompanyDoesNotMatch(): void
    {
        $badCompany = (new CompanyRead())->setId(self::ANY_STRING);
        $this->contract->setCompany($badCompany);
        $this->assertNotContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testAgencyDoesNotMatch(): void
    {
        $badAgency = (new AgencyRead())
            ->setId(self::ANY_STRING)
            ->setLanguage((new LanguageRead())->setId(self::CONTRACT['AGENCY_LANGUAGE_ID']));
        $this->contract->setAgency($badAgency);
        $this->assertNotContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testCountryDoesNotMatch(): void
    {
        foreach ($this->contract->getClient()->getAddresses('client') as $clientAddress) {
            if ('client' === $clientAddress->getType()) {
                $country = $clientAddress->getAddress()->getCity()->getCountry();
                $country->setId(self::ANY_STRING);
            }
        }
        $this->assertNotContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testCategoryCodeDoesNotMatch(): void
    {
        $this->category = self::ANY_STRING;
        $this->assertNotContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testNullCategoryCodeDoesNotMatch(): void
    {
        $this->category = null;
        $this->assertNotContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testAnyAgencyMatchesTemplateWithoutAgencies(): void
    {
        $badAgency = (new AgencyRead())
            ->setId(self::ANY_STRING)
            ->setLanguage((new LanguageRead())->setId(self::CONTRACT['AGENCY_LANGUAGE_ID']));
        $this->contract->setAgency($badAgency);
        $this->assertContains(self::TEMPLATE_WITHOUT_AGENCIES, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testAgencyMatchesTemplateWithAgency(): void
    {
        $this->assertContains(self::TEMPLATE_WITH_AGENCY, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testBadAgencyDoesNotMatchTemplateWithOnlyOneAgency(): void
    {
        $badAgency = (new AgencyRead())
            ->setId(self::ANY_STRING)
            ->setLanguage((new LanguageRead())->setId(self::CONTRACT['AGENCY_LANGUAGE_ID']));
        $this->contract->setAgency($badAgency);

        $this->assertNotContains(self::TEMPLATE_WITH_AGENCY, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testMainAgencyMatchesTemplateWithMainAgency(): void
    {
        $mainAgency = (new AgencyRead())
            ->setId(self::CONTRACT['MAIN_AGENCY_ID']);
        $this->contract->getAgency()->setMainAgency($mainAgency);
        $this->assertContains(self::TEMPLATE_WITH_MAIN_AGENCY, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testGroupAgencyMatchesTemplateWithGroupAgency(): void
    {
        $groupAgency = (new AgencyRead())
            ->setId(self::CONTRACT['GROUP_AGENCY_ID']);
        $this->contract->getAgency()->setGroupAgency($groupAgency);
        $this->assertContains(self::TEMPLATE_WITH_GROUP_AGENCY, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testEventMatchesTemplateWithoutEvent(): void
    {
        $event = (new InsuranceEventRead())
            ->setStatus(self::CONTRACT['EVENT_STATUS'])
            ->setType((new InsuranceEventTypeRead())->setId(self::CONTRACT['EVENT_TYPE_ID']))
            ->setContract($this->contract)
            ->setCreation(new DateTime());
        $this->contract->setEvents([$event]);

        $this->assertContains(self::BASE_TEMPLATE, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testEventMatchesTemplateWithEvent(): void
    {
        $event = (new InsuranceEventRead())
            ->setStatus(self::CONTRACT['EVENT_STATUS'])
            ->setType((new InsuranceEventTypeRead())->setId(self::CONTRACT['EVENT_TYPE_ID']))
            ->setContract($this->contract)
            ->setCreation(new DateTime());
        $this->contract->setEvents([$event]);

        $this->assertContains(self::TEMPLATE_WITH_EVENT, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testBadStatusEventDoesNotMatch(): void
    {
        $event = (new InsuranceEventRead())
            ->setStatus(self::ANY_STRING)
            ->setType((new InsuranceEventTypeRead())->setId(self::CONTRACT['EVENT_TYPE_ID']))
            ->setContract($this->contract)
            ->setCreation(new DateTime());
        $this->contract->setEvents([$event]);

        $this->assertNotContains(self::TEMPLATE_WITH_EVENT, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testBadTypeEventDoesNotMatch(): void
    {
        $event = (new InsuranceEventRead())
            ->setStatus(self::CONTRACT['EVENT_STATUS'])
            ->setType((new InsuranceEventTypeRead())->setId(self::ANY_STRING))
            ->setContract($this->contract)
            ->setCreation(new DateTime());
        $this->contract->setEvents([$event]);

        $this->assertNotContains(self::TEMPLATE_WITH_EVENT, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testPeriodMatchesTemplateWithPeriod(): void
    {
        $this->assertContains(self::TEMPLATE_WITH_PERIOD, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testSendingPeriodToCome(): void
    {
        $this->assertNotContains(self::TEMPLATE_WITH_SENDING_PERIOD_TO_COME, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testExpiredSendingPeriod(): void
    {
        $this->assertNotContains(self::TEMPLATE_WITH_EXPIRED_SENDING_PERIOD, $this->getMatchingTemplatesUuids());
    }

    /**
     * @throws Exception
     */
    public function testMissingCityThrowAMissingErpDataException(): void
    {
        $this->expectException(MissingErpDataException::class);
        $address = (new AddressRead())->setCity(null);
        $clientAddress = (new AddressClientRead())->setAddress($address);
        $clientAddress->setType(self::CONTRACT['CLIENT_ADDRESS_TYPE']);
        $this->contract->setClient((new ClientRead())->setAddresses([$clientAddress]));
        $this->getMatchingTemplatesUuids();
    }

    /**
     * @throws Exception
     */
    public function testMissingCountryThrowAMissingErpDataException(): void
    {
        $this->expectException(MissingErpDataException::class);
        $address = (new AddressRead())->setCity((new CityRead())->setCountry(null));
        $clientAddress = (new AddressClientRead())->setAddress($address);
        $clientAddress->setType(self::CONTRACT['CLIENT_ADDRESS_TYPE']);
        $this->contract->setClient((new ClientRead())->setAddresses([$clientAddress]));
        $this->getMatchingTemplatesUuids();
    }

    /**
     * @throws Exception
     */
    public function testMissingCompanyThrowAMissingErpDataException(): void
    {
        $this->expectException(MissingErpDataException::class);
        $this->contract->setCompany(null);
        $this->getMatchingTemplatesUuids();
    }

    /**
     * @throws Exception
     */
    public function testMissingPackageThrowAMissingErpDataException(): void
    {
        $this->expectException(MissingErpDataException::class);
        $this->contract->setPackage(null);
        $this->getMatchingTemplatesUuids();
    }

    /**
     * @throws Exception
     */
    public function testBadTypeOfActThrowAMissingErpDataException(): void
    {
        $this->expectException(MissingErpDataException::class);
        $this->typeOfAct = self::ANY_STRING;
        $this->getMatchingTemplatesUuids();
    }

    /**
     * @throws Exception
     */
    public function testNullTypeOfActThrowAMissingErpDataException(): void
    {
        $this->expectException(TypeError::class);
        $this->typeOfAct = null;
        $this->getMatchingTemplatesUuids();
    }

    /**
     * @throws Exception
     */
    public function testMissingAgencyThrowAMissingErpDataException(): void
    {
        $this->expectException(MissingErpDataException::class);
        $this->contract->setAgency(null);
        $this->getMatchingTemplatesUuids();
    }

    /**
     * @throws Exception
     */
    public function testMissingAgencyLanguageThrowAMissingErpDataException(): void
    {
        $this->expectException(MissingErpDataException::class);
        $this->contract->getAgency()->setLanguage(null);
        $this->getMatchingTemplatesUuids();
    }
}
