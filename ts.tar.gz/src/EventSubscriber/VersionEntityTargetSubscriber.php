<?php

namespace App\EventSubscriber;

use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\LoadClassMetadataEventArgs;
use Doctrine\ORM\Events;

/**
 * Class VersionEntityTargetSubscriber.
 */
class VersionEntityTargetSubscriber implements EventSubscriber
{
    /**
     * @return array
     */
    public function getSubscribedEvents()
    {
        return [
            Events::loadClassMetadata,
        ];
    }

    /**
     * @param LoadClassMetadataEventArgs $args
     */
    public function loadClassMetadata(LoadClassMetadataEventArgs $args)
    {
        $classMetadata = $args->getClassMetadata();

        if (!$classMetadata->isRootEntity()) {
            return;
        }

        $assocMappings = $classMetadata->associationMappings;
        if (isset($assocMappings['child'])) {
            $assocMappings['child']['targetEntity'] = $classMetadata->getName();
            $assocMappings['child']['sourceEntity'] = $classMetadata->getName();
        }

        if (isset($assocMappings['parent'])) {
            $assocMappings['parent']['targetEntity'] = $classMetadata->getName();
            $assocMappings['parent']['sourceEntity'] = $classMetadata->getName();
        }
        $classMetadata->associationMappings = $assocMappings;
    }
}
