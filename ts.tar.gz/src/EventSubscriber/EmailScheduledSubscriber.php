<?php

namespace App\EventSubscriber;

use App\Entity\EmailScheduledReport;
use App\Event\EmailScheduledEvent;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\QueryBuilder;
use Psr\Log\LoggerInterface;
use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Class EmailScheduledSubscriber.
 */
class EmailScheduledSubscriber implements EventSubscriberInterface
{
    /**
     * @var RegistryInterface
     */
    protected $registry;

    /**
     * @var EntityRepository
     */
    protected $emailReportRepository;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * EmailScheduledSubscriber constructor.
     *
     * @param RegistryInterface $registry
     * @param LoggerInterface   $logger
     */
    public function __construct(RegistryInterface $registry, LoggerInterface $logger)
    {
        $this->registry = $registry;
        $this->logger = $logger;
    }

    public static function getSubscribedEvents()
    {
        return [
            EmailScheduledEvent::EMAIL_JOB_PAGINATED_STARTED => 'onEmailJobPaginatedStarted',
            EmailScheduledEvent::EMAIL_JOB_PAGINATED_STEP => 'onEmailJobPaginatedStep',
            EmailScheduledEvent::EMAIL_JOB_PAGINATED_FINISHED => 'onEmailJobPaginatedFinished',
            EmailScheduledEvent::EMAIL_JOB_PAGINATED_ERROR => 'onEmailJobPaginatedError',
        ];
    }

    /**
     * @return \Doctrine\ORM\QueryBuilder
     */
    private function getQueryBuilder()
    {
        return $this->registry->getEntityManager()->createQueryBuilder();
    }

    /**
     * @param QueryBuilder $qb
     * @param int          $reportId
     */
    private function addCommonDQL(QueryBuilder $qb, int $reportId)
    {
        $qb->set('esr.lastUpdate', ':last_update')->setParameter('last_update', new \DateTime());
        $qb->andWhere('esr.id = :id')->setParameter('id', $reportId);
    }

    /**
     * @param int       $reportId
     * @param int       $itemsSuccess
     * @param int       $itemsError
     * @param bool|null $pageSuccess
     */
    protected function updateReport(int $reportId, int $itemsSuccess, int $itemsError, bool $pageSuccess = null)
    {
        $qb = $this->getQueryBuilder();
        $qb->update(EmailScheduledReport::class, 'esr');
        $qb->set('esr.totalItemsSuccess', 'esr.totalItemsSuccess + :current_items_success')
            ->setParameter('current_items_success', $itemsSuccess);
        $qb->set('esr.totalItemsError', 'esr.totalItemsError + :current_items_error')
            ->setParameter('current_items_error', $itemsError);
        $this->addCommonDQL($qb, $reportId);
        $qb->getQuery()->execute();

        // We set "error" status ASAP even before the end of the process.
        if ($itemsError > 0) {
            $qb = $this->getQueryBuilder();
            $qb->update(EmailScheduledReport::class, 'esr');
            $qb->set('esr.status', ':error_status')
                ->setParameter('error_status', EmailScheduledReport::STATUS_ERROR);
            $this->addCommonDQL($qb, $reportId);
            $qb->getQuery()->execute();
        }

        if (null !== $pageSuccess) {
            $qb = $this->getQueryBuilder();
            $qb->update(EmailScheduledReport::class, 'esr');
            if ($pageSuccess) {
                $qb->set('esr.totalPageSuccess', 'esr.totalPageSuccess + :current_page_success')
                    ->setParameter('current_page_success', 1);
            } else {
                $qb->set('esr.totalPageError', 'esr.totalPageError + :current_page_error')
                    ->setParameter('current_page_error', 1);
                $qb->set('esr.status', ':error_status')
                    ->setParameter('error_status', EmailScheduledReport::STATUS_ERROR);
            }
            $this->addCommonDQL($qb, $reportId);
            $qb->getQuery()->execute();
        }
    }

    /**
     * @param EmailScheduledEvent $event
     */
    public function onEmailJobPaginatedStarted(EmailScheduledEvent $event)
    {
        // TODO link job to template and report.

        /** @var EmailScheduledReport $report */
        $report = $event->getData()['report'];
        $qb = $this->getQueryBuilder();
        $qb->update(EmailScheduledReport::class, 'esr');
        $qb->set('esr.status', ':running_status')
            ->setParameter('running_status', EmailScheduledReport::STATUS_RUNNING);
        $qb->andWhere('esr.status != :error_status')
            ->setParameter('error_status', EmailScheduledReport::STATUS_ERROR);
        $qb->set('esr.startedAt', ':started_at')
            ->setParameter('started_at', new \DateTime());
        $qb->andWhere('esr.startedAt IS NULL');
        $this->addCommonDQL($qb, $report->getId());
        $qb->getQuery()->execute();
    }

    /**
     * @param EmailScheduledEvent $event
     */
    public function onEmailJobPaginatedStep(EmailScheduledEvent $event)
    {
        /** @var EmailScheduledReport $report */
        $data = $event->getData();
        $report = $data['report'];
        $this->updateReport($report->getId(), $data['success_count'], $data['error_count']);
    }

    /**
     * @param EmailScheduledEvent $event
     */
    public function onEmailJobPaginatedFinished(EmailScheduledEvent $event)
    {
        /** @var EmailScheduledReport $report */
        $data = $event->getData();
        $report = $data['report'];
        $this->updateReport($report->getId(), $data['success_count'], $data['error_count'], 0 === $data['error_count'] && !$data['page_failed']);

        // When a page if finished, if it's the last one
        // We need to define SUCCESS status if everything ok (todo = success)
        $qb = $this->getQueryBuilder();
        $qb->update(EmailScheduledReport::class, 'esr');
        $qb->set('esr.status', ':success_status')
            ->setParameter('success_status', EmailScheduledReport::STATUS_SUCCESS);
        $qb->andWhere('esr.status != :error_status')
            ->setParameter('error_status', EmailScheduledReport::STATUS_ERROR);
        $qb->andWhere('esr.totalItemsTodo = esr.totalItemsSuccess');
        $this->addCommonDQL($qb, $report->getId());
        $qb->getQuery()->execute();

        //.... and define "finished" datetime too (todo = success + error).
        $qb = $this->getQueryBuilder();
        $qb->update(EmailScheduledReport::class, 'esr');
        $qb->andWhere('esr.totalItemsTodo = esr.totalItemsSuccess + esr.totalItemsError');
        $qb->set('esr.finishedAt', ':finished_at')
            ->setParameter('finished_at', new \DateTime());
        $this->addCommonDQL($qb, $report->getId());
        $qb->getQuery()->execute();
    }

    /**
     * @param EmailScheduledEvent $event
     */
    public function onEmailJobPaginatedError(EmailScheduledEvent $event)
    {
        /** @var EmailScheduledReport $report */
        $data = $event->getData();
        $report = $data['report'];
        $this->updateReport($report->getId(), $data['success_count'], $data['error_count'], false);
    }
}
