<?php

namespace App\Analyzer;

/**
 * Class AnalyzerRegistry.
 */
class AnalyzerRegistry
{
    /**
     * @var array
     */
    protected $analyzers = [];

    /**
     * @param string $table
     * @param        $object
     */
    public function addAnalyzer(string $table, $object): void
    {
        $this->analyzers[$table] = $object;
    }

    /**
     * @return array
     */
    public function getAnalyzers(): array
    {
        return $this->analyzers;
    }

    /**
     * @param string $table
     *
     * @return mixed
     */
    public function getAnalyzer(string $table)
    {
        if (!isset($this->analyzers[$table])) {
            throw new \InvalidArgumentException(sprintf('No analyzer found for table "%s"', $table));
        }

        return $this->analyzers[$table];
    }
}
