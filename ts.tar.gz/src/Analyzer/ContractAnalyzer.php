<?php

namespace App\Analyzer;

use App\Entity\TypeOfAct;
use App\Services\ErpServiceClient;
use InvalidArgumentException;
use Sfk\Lib\ErpClient\ApiException;
use Sfk\Lib\ErpClient\Model\InsuranceContractRead;
use Sfk\Lib\ErpClient\Model\PrivilegeContractRead;
use Sfk\Lib\ErpClient\Model\WebsiteContractRead;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ContractAnalyzer.
 */
class ContractAnalyzer implements AnalyzerInterface
{
    /**
     * When data has been inserted into database.
     */
    public const EVENT_INSERT = 'insert';

    /**
     * When data has been updated into database.
     */
    public const EVENT_UPDATE = 'update';

    /**
     * When data has been deleted from database.
     */
    public const EVENT_DELETE = 'delete';

    /**
     * @var array
     */
    public static $events
        = [
            self::EVENT_INSERT,
            self::EVENT_UPDATE,
            self::EVENT_DELETE,
        ];

    /**
     * @var string
     */
    protected $databaseName;

    /**
     * @var string
     */
    protected $tableName;

    /**
     * @var array
     */
    protected $supportedEvents = [];

    /**
     * @var string
     */
    protected $identifier = '';

    /**
     * @var string
     */
    protected $typeOfAct;

    /**
     * @var array
     */
    protected $analyzedAttributes = [];

    /**
     * @var ErpServiceClient
     */
    private $erpServiceClient;

    /**
     * ContractAnalyzer constructor.
     *
     * @param ErpServiceClient $erpServiceClient
     */
    public function __construct(ErpServiceClient $erpServiceClient)
    {
        $this->erpServiceClient = $erpServiceClient;
    }

    /**
     * {@inheritdoc}
     */
    public function setSupportedEvents(array $events)
    {
        foreach ($events as $event) {
            if (!in_array($event, self::$events, true)) {
                throw new InvalidArgumentException(
                    sprintf('Invalid configured event "%s". Allowed are "%s"', $event, implode(', ', self::$events))
                );
            }
        }
        $this->supportedEvents = $events;

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setAnalyzedAttributes(array $attributes)
    {
        $this->analyzedAttributes = $attributes;

        return $this;
    }

    /**
     * @param string $type
     * @param array  $data
     * @param array  $oldData
     *
     * @return array
     */
    public function getUsefulData(string $type, array $data, array $oldData)
    {
        $usefulData = [];

        if (self::EVENT_UPDATE === $type) {
            if (!empty(array_intersect_key($oldData, array_flip($this->analyzedAttributes)))) {
                $usefulData = array_intersect_key($data, array_flip($this->analyzedAttributes));
            }
        } else {
            $usefulData = array_intersect_key($data, array_flip($this->analyzedAttributes));
        }

        return $usefulData;
    }

    /**
     * Get contract and see if it meets the criteria of one or more templates.
     *
     * @param array $options
     *
     * @return InsuranceContractRead|PrivilegeContractRead|WebsiteContractRead
     *
     * @throws ApiException
     * @throws \Throwable
     */
    public function analyze(array $options = [])
    {
        $resolver = new OptionsResolver();
        $resolver->setRequired(['contract_id', 'type']);
        $options = $resolver->resolve($options);

        return $this->retrieveErpContract((int) $options['contract_id']);
    }

    /**
     * @param int $idContract
     *
     * @return InsuranceContractRead|PrivilegeContractRead|WebsiteContractRead|null
     *
     * @throws ApiException
     */
    protected function retrieveErpContract(int $idContract)
    {
        try {
            $erpClient = $this->erpServiceClient->getErpClient();
            switch ($this->typeOfAct) {
                case TypeOfAct::INSURANCE:
                    $contract = $erpClient->getInsuranceContractApi()->getInsuranceContractItem(['id' => $idContract]);
                    break;
                case TypeOfAct::PRIVILEGE:
                    $contract = $erpClient->getPrivilegeContractApi()->getPrivilegeContractItem(['id' => $idContract]);
                    break;
                case TypeOfAct::WEBSITE:
                    $contract = $erpClient->getWebsiteContractApi()->getWebsiteContractItem(['id' => $idContract]);
                    break;
                default:
                    $contract = null;
                    break;
            }
        } catch (ApiException $e) {
            throw new ApiException(sprintf('Error when retrieving the %s contract from ERP. ID contract : %s', $this->getTypeOfAct(), $idContract));
        }

        return $contract;
    }

    /**
     * {@inheritdoc}
     */
    public function getTypeOfAct()
    {
        return $this->typeOfAct;
    }

    /**
     * {@inheritdoc}
     */
    public function setTypeOfAct(string $typeOfAct)
    {
        $this->typeOfAct = $typeOfAct;

        return $this;
    }

    /**
     * @return string
     */
    public function getIdentifier()
    {
        return $this->identifier;
    }

    /**
     * @param string $identifier
     *
     * @return ContractAnalyzer
     */
    public function setIdentifier(string $identifier)
    {
        $this->identifier = $identifier;

        return $this;
    }

    /**
     * @param string $databaseName
     *
     * @return ContractAnalyzer
     */
    public function setDatabaseName(string $databaseName)
    {
        $this->databaseName = $databaseName;

        return $this;
    }

    /**
     * @param string $tableName
     *
     * @return ContractAnalyzer
     */
    public function setTableName(string $tableName)
    {
        $this->tableName = $tableName;

        return $this;
    }
}
