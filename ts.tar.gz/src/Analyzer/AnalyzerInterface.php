<?php

namespace App\Analyzer;

/**
 * Interface AnalyzerInterface.
 */
interface AnalyzerInterface
{
    /**
     * @param string $databaseName
     *
     * @return self
     */
    public function setDatabaseName(string $databaseName);

    /**
     * @param string $tableName
     *
     * @return self
     */
    public function setTableName(string $tableName);

    /**
     * @param array $events
     *
     * @return self
     */
    public function setSupportedEvents(array $events);

    /**
     * @param string $identifier
     *
     * @return self
     */
    public function setIdentifier(string $identifier);

    /**
     * @param string $type
     * @param array  $message
     * @param array  $oldMessage
     *
     * @return mixed
     */
    public function getUsefulData(string $type, array $message, array $oldMessage);

    /**
     * Analyze data.
     *
     * @param array $options
     *
     * @return mixed
     */
    public function analyze(array $options = []);
}
