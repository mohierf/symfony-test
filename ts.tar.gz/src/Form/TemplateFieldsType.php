<?php

namespace App\Form;

use A2lix\TranslationFormBundle\Form\Type\TranslationsType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class TemplateFieldsType.
 */
class TemplateFieldsType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('translations', TranslationsType::class, [
//                'label' => 'trans.field.name',
                'label' => false,
                'fields' => [
                    'name' => [
                        'label' => false,
                        'locale_options' => [
                            'label' => false,
                        ],
                    ],
                ],
           ])
            ->add('lockable', LockableFieldsType::class, [
                'label' => false,
            ])
            ->add('activable', ActivableFieldsType::class, [
                'label' => false,
            ])
        ;
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'inherit_data' => true,
            'label' => false,
        ]);
    }
}
