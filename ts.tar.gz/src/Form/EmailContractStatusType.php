<?php

namespace App\Form;

use App\Entity\ContractStatus;
use App\Entity\EmailContractStatus;
use App\Entity\TypeOfAct;
use Doctrine\ORM\EntityRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class ContractStatusesType.
 */
class EmailContractStatusType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        /** @var TypeOfAct $typeOfAct */
        $typeOfAct = $options['typeOfAct'] ?? null;

        $builder
            ->add(
                'contractStatus',
                EntityType::class,
                [
                    'class' => ContractStatus::class,
                    'label' => false,
                    'choice_label' => 'status',
                    'query_builder' => function (EntityRepository $er) use ($typeOfAct) {
                        $qb = $er->createQueryBuilder('cs');
                        $qb->orderBy('cs.status');
                        if ($typeOfAct) {
                            $qb->andWhere('cs.typeOfAct = :typeOfAct')->setParameter('typeOfAct', $typeOfAct->getId());
                        }

                        return $qb;
                    },
                ]
            )
            ->add(
                'minDelaySinceStatusChange',
                IntegerType::class,
                [
                    'label' => false,
                    'attr' => [
                        'min' => 0,
                    ],
                ]
            )
            ->add(
                'maxDelaySinceStatusChange',
                IntegerType::class,
                [
                    'label' => false,
                    'attr' => [
                        'min' => 0,
                    ],
                ]
            );
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults(
            [
                'data_class' => EmailContractStatus::class,
                'attr' => [
                    'novalidate' => 'novalidate',
                ],
            ]
        );

        $resolver->setRequired(['typeOfAct']);
    }
}
