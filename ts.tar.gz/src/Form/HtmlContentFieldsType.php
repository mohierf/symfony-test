<?php

namespace App\Form;

use App\Services\CustomVariableService;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class HtmlContentFieldsType.
 */
class HtmlContentFieldsType extends AbstractType
{
    /**
     * @var CustomVariableService
     */
    private $customVariableService;

    /**
     * HtmlContentFieldsType constructor.
     *
     * @param CustomVariableService $customVariableService
     */
    public function __construct(CustomVariableService $customVariableService)
    {
        $this->customVariableService = $customVariableService;
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('html', HiddenType::class)
            ->add('htmlMetadata', HiddenType::class)
            ->add('css', HiddenType::class)
            ->add('cssMetadata', HiddenType::class)
            ->add('assets', HiddenType::class);

        $customVariableService = $this->customVariableService;

        $builder->addEventListener(
            FormEvents::PRE_SUBMIT,
            static function (FormEvent $event) use ($customVariableService) {
                $data = $event->getData();
                $data['html'] = $customVariableService->transformCustomVariableDisplayNameToStoreName($data['html']);
                $data['htmlMetadata'] = $customVariableService->transformCustomVariableDisplayNameToStoreName($data['htmlMetadata']);
                $event->setData($data);
            }
        );
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'inherit_data' => true,
                'label' => false,
            ]
        );
    }
}
