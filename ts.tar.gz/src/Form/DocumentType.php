<?php

namespace App\Form;

use A2lix\TranslationFormBundle\Form\Type\TranslatedEntityType;
use App\Entity\Category;
use App\Entity\Company;
use App\Entity\Country;
use App\Entity\Document;
use App\Entity\DocumentAgency;
use App\Entity\Language;
use App\Entity\TypeOfAct;
use App\Repository\CategoryRepository;
use App\Repository\CountryRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class DocumentType.
 */
class DocumentType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('template', TemplateFieldsType::class, [
                'data' => $builder->getData(),
            ])
            ->add('htmlContentFields', HtmlContentFieldsType::class)
            ->add('agencyFields', AgencyFieldsType::class, [
                'object_id' => $options['object_id'],
                'agency_link_class' => DocumentAgency::class,
            ])
            ->add('typeOfAct', EntityType::class, [
                'class' => TypeOfAct::class,
                'choice_label' => 'name',
            ])
            ->add('company', EntityType::class, [
                'class' => Company::class,
                'choice_label' => 'name',
            ])
            ->add('category', TranslatedEntityType::class, [
                'class' => Category::class,
                'translation_property' => 'name',
                'query_builder' => function (CategoryRepository $er) {
                    return $er->createQueryBuilder('e')
                        ->select('e, t')
                        ->join('e.translations', 't')
                        ->orderBy('t.name', 'ASC');
                },
            ])
            ->add('language', EntityType::class, [
                'class' => Language::class,
                'choice_label' => 'code',
            ])
            ->add('country', TranslatedEntityType::class, [
                'class' => Country::class,
                'translation_property' => 'name',
                'query_builder' => function (CountryRepository $er) {
                    return $er->createQueryBuilder('e')
                        ->select('e, t')
                        ->join('e.translations', 't')
                        ->orderBy('t.name', 'ASC');
                },
            ])
        ;

        if ($builder->getData() && $builder->getData()->isLocked()) {
            $builder->setDisabled(true);
        }
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Document::class,
            'object_id' => null,
            'attr' => [
                'id' => 'template-form',
            ],
        ]);
    }
}
