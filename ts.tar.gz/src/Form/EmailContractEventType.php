<?php

namespace App\Form;

use App\Entity\EmailContractEvent;
use App\Entity\EventStatus;
use App\Entity\EventType;
use App\Entity\TypeOfAct;
use Doctrine\ORM\EntityRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class EmailContractEventType.
 */
class EmailContractEventType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        /** @var TypeOfAct $typeOfAct */
        $typeOfAct = $options['typeOfAct'] ?? null;

        $builder
            ->add(
                'eventType',
                EntityType::class,
                [
                    'class' => EventType::class,
                    'label' => false,
                    'choice_label' => 'name',
                    'query_builder' => function (EntityRepository $er) use ($typeOfAct) {
                        $qb = $er->createQueryBuilder('et');
                        $qb->orderBy('et.name');
                        if ($typeOfAct) {
                            $qb->andWhere('et.typeOfAct = :typeOfAct')->setParameter('typeOfAct', $typeOfAct->getId());
                        }

                        return $qb;
                    },
                    'attr' => [
                        'class' => 'js-select2',
                    ],
                ]
            )
            ->add(
                'eventStatus',
                EntityType::class,
                [
                    'class' => EventStatus::class,
                    'label' => false,
                    'choice_label' => 'status',
                    'query_builder' => function (EntityRepository $er) use ($typeOfAct) {
                        $qb = $er->createQueryBuilder('es');
                        $qb->orderBy('es.status');
                        if ($typeOfAct) {
                            $qb->andWhere('es.typeOfAct = :typeOfAct')->setParameter('typeOfAct', $typeOfAct->getId());
                        }

                        return $qb;
                    },
                ]
            )
            ->add(
                'minDelaySinceEventCreation',
                IntegerType::class,
                [
                    'label' => false,
                    'attr' => [
                        'min' => 0,
                    ],
                ]
            )
            ->add(
                'maxDelaySinceEventCreation',
                IntegerType::class,
                [
                    'label' => false,
                    'attr' => [
                        'min' => 0,
                    ],
                ]
            );
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults(
            [
                'data_class' => EmailContractEvent::class,
                'attr' => [
                    'novalidate' => 'novalidate',
                ],
            ]
        );

        $resolver->setRequired(['typeOfAct']);
    }
}
