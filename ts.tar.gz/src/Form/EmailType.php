<?php

namespace App\Form;

use A2lix\TranslationFormBundle\Form\Type\TranslatedEntityType;
use App\Entity\Category;
use App\Entity\Company;
use App\Entity\ContractPackage;
use App\Entity\ContractPaymentStatus;
use App\Entity\Country;
use App\Entity\Email;
use App\Entity\EmailAgency;
use App\Entity\EmailSender;
use App\Entity\EmailTest;
use App\Entity\Language;
use App\Entity\TypeOfAct;
use App\Repository\CategoryRepository;
use App\Repository\CompanyRepository;
use App\Repository\CountryRepository;
use App\Repository\LanguageRepository;
use Doctrine\ORM\EntityRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Translation\TranslatorInterface;

/**
 * Class EmailType.
 */
class EmailType extends AbstractType
{
    /**
     * @var TranslatorInterface
     */
    private $translator;

    /**
     * EmailType constructor.
     *
     * @param TranslatorInterface $translator
     */
    public function __construct(TranslatorInterface $translator)
    {
        $this->translator = $translator;
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        /** @var TypeOfAct $typeOfAct */
        $typeOfAct = $builder->getData()->getTypeOfAct();

        $builder
            ->add(
                'template',
                TemplateFieldsType::class,
                [
                    'data' => $builder->getData(),
                    'label' => false,
                ]
            )
            ->add('subject', TextType::class, [
                'label' => 'trans.field.subject',
            ])
            ->add(
                'sender',
                EntityType::class,
                [
                    'class' => EmailSender::class,
                    'choice_label' => 'fullname',
                    'label' => 'trans.field.sender',
                    'query_builder' => static function (EntityRepository $er) use ($typeOfAct) {
                        $qb = $er->createQueryBuilder('es');
                        $qb->orderBy('es.email', 'ASC');
                        if ($typeOfAct) {
                            $qb->andWhere('IDENTITY(es.typeOfAct) = :type_of_act_id')
                                ->setParameter('type_of_act_id', $typeOfAct->getId());
                        }

                        return $qb;
                    },
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.sender'),
                    ],
                ]
            )
            ->add(
                'testEmails',
                EntityType::class,
                [
                    'class' => EmailTest::class,
                    'multiple' => true,
                    'required' => false,
                    'label' => 'trans.field.email_test',
                    'choice_label' => 'email',
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.email_test'),
                    ],
                ]
            )
            ->add('htmlContentFields', HtmlContentFieldsType::class)
            ->add(
                'agencyFields',
                AgencyFieldsType::class,
                [
                    'object_id' => $options['object_id'],
                    'agency_link_class' => EmailAgency::class,
                ]
            )
            ->add(
                'company',
                EntityType::class,
                [
                    'class' => Company::class,
                    'choice_label' => 'name',
                    'label' => 'trans.field.company',
                    'query_builder' => static function (CompanyRepository $er) {
                        return $er->createQueryBuilder('e')->orderBy('e.name', 'ASC');
                    },
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.company'),
                    ],
                    'required' => false,
                ]
            )
            ->add(
                'category',
                TranslatedEntityType::class,
                [
                    'class' => Category::class,
                    'choice_label' => 'code',
                    'translation_property' => 'name',
                    'label' => 'trans.field.category',
                    'query_builder' => static function (CategoryRepository $er) {
                        return $er->createQueryBuilder('e')
                            ->select('e, t')
                            ->join('e.translations', 't')
                            ->orderBy('t.name', 'ASC');
                    },
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.category'),
                    ],
                    'required' => false,
                ]
            )
            ->add(
                'language',
                EntityType::class,
                [
                    'class' => Language::class,
                    'choice_label' => 'code',
                    'label' => 'trans.field.language',
                    'query_builder' => static function (LanguageRepository $er) {
                        return $er->createQueryBuilder('e')->orderBy('e.code', 'ASC');
                    },
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.language'),
                    ],
                    'required' => false,
                ]
            )
            ->add(
                'country',
                TranslatedEntityType::class,
                [
                    'class' => Country::class,
                    'translation_property' => 'name',
                    'label' => 'trans.field.country',
                    'query_builder' => static function (CountryRepository $er) {
                        return $er->createQueryBuilder('e')
                            ->select('e, t')
                            ->join('e.translations', 't')
                            ->orderBy('t.name', 'ASC');
                    },
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.country'),
                    ],
                    'required' => false,
                ]
            )
            ->add(
                'attachments',
                CollectionType::class,
                [
                    'entry_type' => EmailAttachmentType::class,
                    'by_reference' => false,
                    'allow_add' => true,
                    'allow_delete' => true,
                    'prototype' => true,
                    'label' => false,
                ]
            )
            ->add(
                'packages',
                EntityType::class,
                [
                    'class' => ContractPackage::class,
                    'choice_label' => 'name',
                    'multiple' => true,
                    'required' => false,
                    'label' => 'trans.field.package',
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.package'),
                    ],
                    'query_builder' => static function (EntityRepository $er) use ($typeOfAct) {
                        $qb = $er->createQueryBuilder('p');
                        $qb->orderBy('p.name', 'ASC');
                        if ($typeOfAct) {
                            $qb->andWhere('IDENTITY(p.typeOfAct) = :type_of_act_id')
                                ->setParameter('type_of_act_id', $typeOfAct->getId());
                        }

                        return $qb;
                    },
                ]
            )
            ->add('contractStatuses', CollectionType::class, array(
                'entry_type' => EmailContractStatusType::class,
                'by_reference' => false,
                'allow_add' => true,
                'allow_delete' => true,
                'label' => false,
                'entry_options' => array(
                    'label' => false,
                    'typeOfAct' => $typeOfAct,
                ),
            ))
            ->add('contractEvents', CollectionType::class, array(
                'entry_type' => EmailContractEventType::class,
                'by_reference' => false,
                'allow_add' => true,
                'allow_delete' => true,
                'label' => false,
                'entry_options' => array(
                    'label' => false,
                    'typeOfAct' => $typeOfAct,
                ),
            ))
            ->add(
                'paymentStatuses',
                EntityType::class,
                [
                    'class' => ContractPaymentStatus::class,
                    'choice_label' => 'status',
                    'multiple' => true,
                    'required' => false,
                    'label' => 'trans.field.paymentStatus',
                    'placeholder' => 'trans.choose.paymentStatus',
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.paymentStatus'),
                    ],
                    'query_builder' => static function (EntityRepository $er) use ($typeOfAct) {
                        $qb = $er->createQueryBuilder('ps');
                        $qb->orderBy('ps.status', 'ASC');
                        if ($typeOfAct) {
                            $qb->andWhere('IDENTITY(ps.typeOfAct) = :type_of_act_id')
                                ->setParameter('type_of_act_id', $typeOfAct->getId());
                        }

                        return $qb;
                    },
                ]
            )
            ->add('manual', CheckboxType::class, [
                'label' => 'trans.field.manual',
            ])
            ->add('automatic', CheckboxType::class, [
                'label' => 'trans.field.automatic',
            ])
            ->add('scheduled', CheckboxType::class, [
                'label' => 'trans.field.scheduled',
            ])
            ->add('beginSendPeriod', DateType::class, [
                'widget' => 'single_text',
                'attr' => [
                    'class' => 'js-datepicker',
                ],
            ])
            ->add('endSendPeriod', DateType::class, [
                'widget' => 'single_text',
                'attr' => [
                    'class' => 'js-datepicker',
                ],
            ])
            ->add('priority', IntegerType::class, ['empty_data' => 0])
            ->add('maxRetry', IntegerType::class, ['empty_data' => 0]);

        if ($builder->getData() && $builder->getData()->isLocked()) {
            $builder->setDisabled(true);
        }
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'data_class' => Email::class,
                'validation_groups' => ['Default', 'template'],
                'object_id' => null,
                'attr' => [
                    'id' => 'template-form',
                    'novalidate' => 'novalidate',
                ],
            ]
        );
    }
}
