<?php

namespace App\Form;

use App\Entity\EmailSender;
use App\Entity\TypeOfAct;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class EmailSenderType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name')
            ->add('email')
            ->add('typeOfAct', EntityType::class, [
                'class' => TypeOfAct::class,
                'choice_label' => 'name',
                'attr' => [
                    'class' => 'js-select2',
                ],
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => EmailSender::class,
            'attr' => [
                'novalidate' => 'novalidate',
            ],
        ]);
    }
}
