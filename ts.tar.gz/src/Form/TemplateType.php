<?php

namespace App\Form;

use App\Entity\Company;
use App\Entity\JsonSchema;
use App\Entity\Language;
use App\Entity\Template;
use App\Entity\TemplateAgency;
use App\Entity\TemplateCategory;
use App\Repository\TemplateCategoryRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Translation\TranslatorInterface;

/**
 * Class TemplateType.
 */
class TemplateType extends AbstractType
{
    /**
     * @var TranslatorInterface
     */
    private $translator;

    /**
     * TemplateType constructor.
     *
     * @param TranslatorInterface $translator
     */
    public function __construct(TranslatorInterface $translator)
    {
        $this->translator = $translator;
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add(
                'template',
                TemplateFieldsType::class,
                [
                    'data' => $builder->getData(),
                    'label' => false,
                ]
            )
            ->add(
                'htmlContentFields',
                HtmlContentFieldsType::class
            )
            ->add(
                'company',
                EntityType::class,
                [
                    'class' => Company::class,
                    'choice_label' => 'name',
                    'label' => 'trans.field.company',
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.company'),
                    ],
                ]
            )
            ->add(
                'language',
                EntityType::class,
                [
                    'class' => Language::class,
                    'choice_label' => 'code',
                    'label' => 'trans.field.language',
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.language'),
                    ],
                ]
            )->add(
                'jsonSchema',
                EntityType::class,
                [
                    'class' => JsonSchema::class,
                    'choice_label' => 'name',
                    'label' => 'trans.field.json_schema',
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.json_schema'),
                    ],
                ]
            )
            ->add(
                'templateCategory',
                EntityType::class,
                [
                    'class' => TemplateCategory::class,
                    'label' => 'trans.field.template_category',
                    'query_builder' => static function (TemplateCategoryRepository $er) {
                        return $er->createQueryBuilder('e')
                            ->select('e, t')
                            ->join('e.translations', 't')
                            ->orderBy('t.name', 'ASC');
                    },
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.template_category'),
                    ],
                ]
            )
            ->add(
                'agencyFields',
                AgencyFieldsType::class,
                [
                    'object_id' => $options['object_id'],
                    'agency_link_class' => TemplateAgency::class,
                ]
            );

        if ($builder->getData() && $builder->getData()->isLocked()) {
            $builder->setDisabled(true);
        }
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults(
            [
                'data_class' => Template::class,
                'object_id' => null,
                'attr' => [
                    'id' => 'template-form',
                    'novalidate' => 'novalidate',
                ],
            ]
        );
    }
}
