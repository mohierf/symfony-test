<?php

namespace App\Form;

use App\Entity\EmailAttachment;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Translation\TranslatorInterface;
use Vich\UploaderBundle\Form\Type\VichFileType;

class EmailAttachmentType extends AbstractType
{
    /**
     * @var TranslatorInterface
     */
    private $translator;

    /**
     * EmailType constructor.
     *
     * @param TranslatorInterface $translator
     */
    public function __construct(TranslatorInterface $translator)
    {
        $this->translator = $translator;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('file', VichFileType::class, [
                    'required' => false,
                    'label' => false,
                    'delete_label' => $this->translator->trans('form.file.delete'),
                    'download_label' => true,
                    'allow_delete' => true,
                    'download_uri' => true,
                ]
            )
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => EmailAttachment::class,
            'attr' => [
                'novalidate' => 'novalidate',
            ],
        ]);
    }
}
