<?php

namespace App\Form;

use A2lix\TranslationFormBundle\Form\Type\TranslatedEntityType;
use A2lix\TranslationFormBundle\Form\Type\TranslationsType;
use App\Entity\AgencyFamily;
use App\Entity\Company;
use App\Entity\Country;
use App\Entity\CustomVariable;
use App\Entity\CustomVariableAgency;
use App\Entity\Language;
use App\Entity\TypeOfAct;
use App\Repository\CompanyRepository;
use App\Repository\CountryRepository;
use App\Repository\LanguageRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Translation\TranslatorInterface;

/**
 * Class CustomVariableType.
 */
class CustomVariableType extends AbstractType
{
    /**
     * @var TranslatorInterface
     */
    private $translator;

    /**
     * CustomVariableType constructor.
     *
     * @param TranslatorInterface $translator
     */
    public function __construct(TranslatorInterface $translator)
    {
        $this->translator = $translator;
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add(
                'translations',
                TranslationsType::class,
                [
                    'label' => false,
                    'fields' => [
                        'name' => [
                            'label' => false,
                            'locale_options' => [
                                'label' => false,
                            ],
                        ],
                    ],
                ]
            )
            ->add(
                'agencyFields',
                AgencyFieldsType::class,
                [
                    'object_id' => $options['object_id'],
                    'agency_link_class' => CustomVariableAgency::class,
                ]
            )
            ->add(
                'company',
                EntityType::class,
                [
                    'class' => Company::class,
                    'choice_label' => 'name',
                    'label' => 'trans.field.company',
                    'query_builder' => static function (CompanyRepository $er) {
                        return $er->createQueryBuilder('e')->orderBy('e.name', 'ASC');
                    },
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.company'),
                    ],
                    'required' => false,
                ]
            )
            ->add(
                'language',
                EntityType::class,
                [
                    'class' => Language::class,
                    'choice_label' => 'code',
                    'label' => 'trans.field.language',
                    'query_builder' => static function (LanguageRepository $er) {
                        return $er->createQueryBuilder('e')->orderBy('e.code', 'ASC');
                    },
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.language'),
                    ],
                    'required' => false,
                ]
            )
            ->add(
                'country',
                TranslatedEntityType::class,
                [
                    'class' => Country::class,
                    'translation_property' => 'name',
                    'label' => 'trans.field.country',
                    'query_builder' => static function (CountryRepository $er) {
                        return $er->createQueryBuilder('e')
                            ->select('e, t')
                            ->join('e.translations', 't')
                            ->orderBy('t.name', 'ASC');
                    },
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.country'),
                    ],
                    'required' => false,
                ]
            )
            ->add(
                'typeOfAct',
                EntityType::class,
                [
                    'class' => TypeOfAct::class,
                    'label' => 'trans.field.type_of_act',
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.type_of_act'),
                    ],
                    'required' => false,
                ]
            )
            ->add('htmlContentFields', HtmlContentFieldsType::class)
            ->add(
                'agencyFamilies',
                EntityType::class,
                [
                    'class' => AgencyFamily::class,
                    'multiple' => true,
                    'label' => 'trans.field.agency_family',
                    'attr' => [
                        'class' => 'js-select2',
                        'data-placeholder' => $this->translator->trans('trans.choose.agency_family'),
                    ],
                    'required' => false,
                ]
            );
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(
            [
                'data_class' => CustomVariable::class,
                'object_id' => null,
                'attr' => [
                    'id' => 'custom-variable-form',
                    'novalidate' => 'novalidate',
                ],
            ]
        );
    }
}
