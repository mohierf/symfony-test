<?php

namespace App\Form;

use App\Entity\Agency;
use App\Entity\ObjectAgencyLinkInterface;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\EntityRepository;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Translation\TranslatorInterface;

/**
 * Class AgencyFieldsType.
 */
class AgencyFieldsType extends AbstractType
{
    /**
     * @var EntityManagerInterface
     */
    protected $em;

    /**
     * @var TranslatorInterface
     */
    private $translator;

    /**
     * AgencyFieldsType constructor.
     *
     * @param EntityManagerInterface $em
     * @param TranslatorInterface    $translator
     */
    public function __construct(EntityManagerInterface $em, TranslatorInterface $translator)
    {
        $this->em = $em;
        $this->translator = $translator;
    }

    /**
     * @param $object
     * @param string $objectAgencyClass
     * @param $type
     * @param $agencies
     * @param array $objectAgenciesByType
     */
    protected function manageObjectAgencies($object, string $objectAgencyClass, $type, $agencies, array &$objectAgenciesByType)
    {
        /** @var Agency $agency */
        foreach ($agencies as $agency) {
            $agencyObject = $objectAgenciesByType[$type][$agency->getId()] ?? null;
            if (null !== $agencyObject) {
                unset($objectAgenciesByType[$type][$agency->getId()]);
            } else {
                /** @var ObjectAgencyLinkInterface $agencyObject */
                $agencyObject = new $objectAgencyClass();
                $agencyObject->setAgency($agency);
                $agencyObject->setObject($object);
                $agencyObject->setType($type);
                $this->em->persist($agencyObject);
            }
        }
    }

    /**
     * @param array $oldObjectAgencies
     */
    protected function removeOldObjectAgencies(array $oldObjectAgencies)
    {
        foreach ($oldObjectAgencies as $oldObjectAgency) {
            foreach ($oldObjectAgency as $toDelete) {
                $this->em->remove($toDelete);
            }
        }
    }

    /**
     * @param int    $objectId
     * @param string $objectAgencyLinkClass
     *
     * @return mixed
     */
    protected function getObjectAgencies(int $objectId, string $objectAgencyLinkClass)
    {
        return $this->em->createQueryBuilder()
            ->select('o')
            ->from($objectAgencyLinkClass, 'o')
            ->andWhere('IDENTITY(o.'.$objectAgencyLinkClass::getObjectRelationName().') = :object_id')->setParameter('object_id', $objectId)
            ->getQuery()
            ->getResult()
        ;
    }

    /**
     * @param int    $objectId
     * @param string $objectAgencyLinkClass
     *
     * @return array
     */
    protected function getObjectAgenciesByType(int $objectId, string $objectAgencyLinkClass)
    {
        $agenciesByType = [];
        $objectAgencies = $this->getObjectAgencies($objectId, $objectAgencyLinkClass);
        foreach ($objectAgencies as $objectAgency) {
            /* @var ObjectAgencyLinkInterface $objectAgency */
            $agenciesByType[$objectAgency->getType()][] = $objectAgency->getAgency();
        }

        return $agenciesByType;
    }

    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $objectAgencyLinkClass = $options['agency_link_class'];

        $agenciesByType = $options['object_id']
            ? $this->getObjectAgenciesByType($options['object_id'], $objectAgencyLinkClass)
            : [];

        $builder
            ->add('agencies', EntityType::class, [
                'class' => Agency::class,
                'multiple' => true,
                'required' => false,
                'label' => 'trans.field.agencies',
                'attr' => [
                    'class' => 'js-select2',
                    'data-placeholder' => $this->translator->trans('trans.choose.agencies'),
                ],
                'query_builder' => function (EntityRepository $em) {
                    return $em->createQueryBuilder('a1')
                        ->addOrderBy('a1.name', 'asc')
                        ->leftJoin(Agency::class, 'a2', 'WITH', 'a1.id = a2.mainAgency')
                        ->leftJoin(Agency::class, 'a3', 'WITH', 'a1.id = a3.groupAgency')
                        ->andWhere('a1.id = a2.id OR a2.id IS NULL')
                        ->andWhere('a3.id IS NULL')
                        ->groupBy('a1.id')
                        ;
                },
                'data' => $agenciesByType[ObjectAgencyLinkInterface::TYPE_AGENCY] ?? [],
            ])
            ->add('mainAgencies', EntityType::class, [
                'class' => Agency::class,
                'multiple' => true,
                'required' => false,
                'label' => 'trans.field.main_agencies',
                'attr' => [
                    'class' => 'js-select2',
                    'data-placeholder' => $this->translator->trans('trans.choose.main_agencies'),
                ],
                'query_builder' => function (EntityRepository $em) {
                    return $em->createQueryBuilder('a1')
                        ->innerJoin(Agency::class, 'a2', 'WITH', 'a1.id = a2.mainAgency')
                        ->addOrderBy('a1.name', 'asc')
                        ->andWhere('a1.id != a2.id')
                        ->groupBy('a1.id')
                    ;
                },
                'data' => $agenciesByType[ObjectAgencyLinkInterface::TYPE_MAIN_AGENCY] ?? [],
            ])
            ->add('groupAgencies', EntityType::class, [
                'class' => Agency::class,
                'multiple' => true,
                'required' => false,
                'label' => 'trans.field.group_agencies',
                'attr' => [
                    'class' => 'js-select2',
                    'data-placeholder' => $this->translator->trans('trans.choose.group_agencies'),
                ],
                'query_builder' => function (EntityRepository $em) {
                    return $em->createQueryBuilder('a1')
                        ->innerJoin(Agency::class, 'a2', 'WITH', 'a1.id = a2.groupAgency')
                        ->addOrderBy('a1.name', 'asc')
                        ->groupBy('a1.id')
                        ;
                },
                'data' => $agenciesByType[ObjectAgencyLinkInterface::TYPE_GROUP_AGENCY] ?? [],
            ])
        ;

        // We store relations between templates and agencies in a single table with a type.
        // BUT we want a "select field" for each type of relation (group, main,...)
        $builder->addEventListener(FormEvents::POST_SUBMIT, function (FormEvent $event) use ($objectAgencyLinkClass) {
            $form = $event->getForm();
            $data = $form->getData();
            $object = $form->getParent()->getData();

            // If we are editing an existing object we want to remove old agencies if needed.
            $objectAgenciesByType = [];
            if (null !== $object->getId()) {
                $previousObjectAgencies = $this->getObjectAgencies($object->getId(), $objectAgencyLinkClass);
                foreach ($previousObjectAgencies as $previousObjectAgency) {
                    /* @var ObjectAgencyLinkInterface $previousObjectAgency */
                    $objectAgenciesByType[$previousObjectAgency->getType()][$previousObjectAgency->getAgency()->getId()] = $previousObjectAgency;
                }
            }

            $this->manageObjectAgencies(
                $object,
                $objectAgencyLinkClass,
                ObjectAgencyLinkInterface::TYPE_AGENCY,
                $data['agencies'],
                $objectAgenciesByType
            );
            $this->manageObjectAgencies(
                $object,
                $objectAgencyLinkClass,
                ObjectAgencyLinkInterface::TYPE_MAIN_AGENCY,
                $data['mainAgencies'],
                $objectAgenciesByType
            );
            $this->manageObjectAgencies(
                $object,
                $objectAgencyLinkClass,
                ObjectAgencyLinkInterface::TYPE_GROUP_AGENCY,
                $data['groupAgencies'],
                $objectAgenciesByType
            );

            $this->removeOldObjectAgencies($objectAgenciesByType);
        });
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'object_id' => null,
            'label' => false,
            'mapped' => false,
        ]);

        $resolver->setRequired([
            'agency_link_class',
        ]);
    }
}
