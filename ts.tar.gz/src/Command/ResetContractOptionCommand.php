<?php

namespace App\Command;

use App\Command\Traits\ByTypeOfActTrait;
use App\Services\ContractOptionService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class ResetContractOptionCommand.
 */
class ResetContractOptionCommand extends GetErpBaseCommand
{
    use ByTypeOfActTrait;

    protected static $defaultName = 'app:reset:contract-option';

    /**
     * @var ContractOptionService
     */
    private $contractOptionService;

    /**
     * ResetContractOptionCommand constructor.
     *
     * @param EntityManagerInterface $entityManager
     * @param ContractOptionService  $contractOptionService
     */
    public function __construct(EntityManagerInterface $entityManager, ContractOptionService $contractOptionService)
    {
        parent::__construct($entityManager);
        $this->contractOptionService = $contractOptionService;
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     *
     * @throws \Exception
     */
    protected function init(InputInterface $input, OutputInterface $output)
    {
        $this->manageContractTypeArgument($input);
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     */
    protected function details(InputInterface $input, OutputInterface $output)
    {
        $this->printContractTypeArgument($output);
    }

    /**
     * {@inheritdoc}
     */
    protected function configure(): void
    {
        parent::configure();
        $this->setDescription('Reset contract options by type of act');
        $this->configureContractTypeArgument($this);
    }

    /**
     * @return \Closure
     *
     * @throws \Exception
     */
    protected function getBulkCallback(): callable
    {
        $erpClient = $this->getErpClient();
        $contractTypeName = $this->contractType->getName();
        $methodApi = sprintf('get%sOptionApi', ucfirst($contractTypeName));
        $methodCollection = sprintf('get%sOptionCollection', ucfirst($contractTypeName));

        if (!method_exists($erpClient, $methodApi)) {
            throw new \Exception(sprintf('Method "%s" not found in object "%s". Please, check Contract type.', $methodApi, get_class($erpClient)));
        }
        $api = $erpClient->$methodApi();

        if (!method_exists($api, $methodCollection)) {
            throw new \Exception(sprintf('Method "%s" not found in object "%s". Please, check Contract type.', $methodCollection, get_class($api)));
        }

        return function ($page, $itemPerPage, $force) use ($api, $methodCollection) {
            $params = [
                'page' => $page,
                'items_per_page' => $itemPerPage,
            ];

            $contractOptions = $api->$methodCollection($params);
            $currentCount = count($contractOptions);

            if ($force) {
                $this->contractOptionService->resetContractOptionsFromErpService(
                    $this->contractType,
                    $contractOptions
                );
            }

            return [$currentCount];
        };
    }
}
