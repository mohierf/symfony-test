<?php

namespace App\Command;

use App\Producer\MessageProducedEvent;
use App\Producer\ProducerRegistry;
use App\Synchronizer\BaseSynchronizer;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;

/**
 * Class ProduceMessageCommand.
 */
class ProduceMessageCommand extends Command
{
    protected static $defaultName = 'app:message:produce';

    /**
     * @var ProducerRegistry
     */
    private $producerRegistry;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var EventDispatcherInterface
     */
    private $eventDispatcher;

    /**
     * ProduceMessageCommand constructor.
     *
     * @param LoggerInterface          $logger
     * @param ProducerRegistry         $producerRegistry
     * @param EventDispatcherInterface $eventDispatcher
     */
    public function __construct(LoggerInterface $logger, ProducerRegistry $producerRegistry, EventDispatcherInterface $eventDispatcher)
    {
        parent::__construct();
        $this->logger = $logger;
        $this->producerRegistry = $producerRegistry;
        $this->eventDispatcher = $eventDispatcher;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        parent::configure();
        $this
            ->setDescription('Produce a message for the given table')
            ->addArgument(
                'table',
                InputArgument::REQUIRED,
                'Generate fake event for this table'
            )
            ->addOption(
                'values',
                null,
                InputOption::VALUE_NONE,
                'Give your own attribute values for message'
            )
            ->addOption(
                'count',
                null,
                InputOption::VALUE_REQUIRED,
                'How many message to produce',
                1
            );
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->eventDispatcher->addListener(
            MessageProducedEvent::POST_PRODUCTION,
            function (MessageProducedEvent $event) use ($output) {
                $this->logger->info('Message produced', ['message' => json_encode($event->getMessage())]);
            }
        );

        $io = new SymfonyStyle($input, $output);
        $tables = array_keys($this->producerRegistry->getProducers());
        $table = $input->getArgument('table');

        if (!in_array($table, $tables)) {
            throw new \Exception(sprintf(
                'Invalid table producer "%s". Allowed are: %s',
                $table,
                join(', ', $tables)
            ));
        }

        $producer = $this->producerRegistry->getProducer($table);

        $valuesFromInput = $input->getOption('values');
        $count = $input->getOption('count');

        $data = [];
        while ($count >= 1) {
            $data[$count] = [];
            if ($valuesFromInput) {
                $askedData = ['type' => '', 'data' => []];
                $io->note('Please give attribute data');
                $askedData['type'] = $io->choice('Event type ?', BaseSynchronizer::$events);
                foreach ($producer->getMandatoryData() as $field) {
                    $answer = $io->ask('Value for field '.$field.' ?');
                    // A way to determine if the field is an integer..... :)
                    if (false !== strpos($field, 'id')) {
                        $answer = (int) $answer;
                    }
                    $askedData['data'][$field] = $answer;
                }
                $data[$count] = $askedData;
            }
            --$count;
        }

        $return = 0;
        foreach ($data as $datum) {
            try {
                $producer->produce($datum);
            } catch (\Exception $exeception) {
                $this->logger->error('Producer error', [
                    'exception' => $exeception,
                ]);
                $return = -1;
            }
        }

        return $return;
    }
}
