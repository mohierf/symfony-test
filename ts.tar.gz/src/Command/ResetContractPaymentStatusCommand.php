<?php

namespace App\Command;

use App\Command\Traits\ByTypeOfActTrait;
use App\Services\ContractPaymentStatusService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class ResetContractStatusCommand.
 */
class ResetContractPaymentStatusCommand extends GetErpBaseCommand
{
    use ByTypeOfActTrait;

    protected static $defaultName = 'app:reset:contract-payment-status';

    /**
     * @var ContractPaymentStatusService
     */
    private $contractPaymentStatusService;

    /**
     * ResetContractPaymentStatusCommand constructor.
     *
     * @param EntityManagerInterface       $entityManager
     * @param ContractPaymentStatusService $contractPaymentStatusService
     */
    public function __construct(EntityManagerInterface $entityManager, ContractPaymentStatusService $contractPaymentStatusService)
    {
        parent::__construct($entityManager);
        $this->contractPaymentStatusService = $contractPaymentStatusService;
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     *
     * @throws \Exception
     */
    protected function init(InputInterface $input, OutputInterface $output)
    {
        $this->manageContractTypeArgument($input);
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     */
    protected function details(InputInterface $input, OutputInterface $output)
    {
        $this->printContractTypeArgument($output);
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        parent::configure();
        $this->setDescription('Reset contract payment statuses by type of act');
        $this->configureContractTypeArgument($this);
    }

    /**
     * @return \Closure
     *
     * @throws \Exception
     */
    protected function getBulkCallback()
    {
        $erpClient = $this->getErpClient();
        $contractTypeName = $this->contractType->getName();
        $methodApi = sprintf('get%sContractPaymentStatusApi', ucfirst($contractTypeName));
        $methodCollection = sprintf('get%sContractPaymentStatusCollection', ucfirst($contractTypeName));

        if (!method_exists($erpClient, $methodApi)) {
            throw new \Exception(sprintf('Method "%s" not found in object "%s". Please, check Contract type.', $methodApi, get_class($erpClient)));
        }
        $api = $erpClient->$methodApi();

        if (!method_exists($api, $methodCollection)) {
            throw new \Exception(sprintf('Method "%s" not found in object "%s". Please, check Contract type.', $methodCollection, get_class($api)));
        }

        return function ($page, $itemPerPage, $force) use ($api, $methodCollection) {
            $params = [
                'page' => $page,
                'items_per_page' => $itemPerPage,
            ];

            $statuses = $api->$methodCollection($params);
            $currentCount = count($statuses);

            if ($force) {
                $this->contractPaymentStatusService->resetContractStatusesFromErpService(
                    $this->contractType,
                    $statuses
                );
            }

            return [$currentCount];
        };
    }
}
