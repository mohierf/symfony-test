<?php

namespace App\Command;

use App\Command\Traits\ByTypeOfActTrait;
use App\Services\ContractStatusService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class ResetContractStatusCommand.
 */
class ResetContractStatusCommand extends GetErpBaseCommand
{
    use ByTypeOfActTrait;

    protected static $defaultName = 'app:reset:contract-status';

    /**
     * @var ContractStatusService
     */
    private $contractStatusService;

    /**
     * ResetContractStatusCommand constructor.
     *
     * @param EntityManagerInterface $entityManager
     * @param ContractStatusService  $contractStatusService
     */
    public function __construct(EntityManagerInterface $entityManager, ContractStatusService $contractStatusService)
    {
        parent::__construct($entityManager);
        $this->contractStatusService = $contractStatusService;
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     *
     * @throws \Exception
     */
    protected function init(InputInterface $input, OutputInterface $output)
    {
        $this->manageContractTypeArgument($input);
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     */
    protected function details(InputInterface $input, OutputInterface $output)
    {
        $this->printContractTypeArgument($output);
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        parent::configure();
        $this->setDescription('Reset contract statuses by type of act');
        $this->configureContractTypeArgument($this);
    }

    /**
     * @return \Closure
     *
     * @throws \Exception
     */
    protected function getBulkCallback()
    {
        $erpClient = $this->getErpClient();
        $contractTypeName = $this->contractType->getName();
        $methodApi = sprintf('get%sContractStatusApi', ucfirst($contractTypeName));
        $methodCollection = sprintf('get%sContractStatusCollection', ucfirst($contractTypeName));

        if (!method_exists($erpClient, $methodApi)) {
            throw new \Exception(sprintf('Method "%s" not found in object "%s". Please, check Contract type.', $methodApi, get_class($erpClient)));
        }
        $api = $erpClient->$methodApi();

        if (!method_exists($api, $methodCollection)) {
            throw new \Exception(sprintf('Method "%s" not found in object "%s". Please, check Contract type.', $methodCollection, get_class($api)));
        }

        return function ($page, $itemPerPage, $force) use ($api, $methodCollection) {
            $params = [
                'page' => $page,
                'items_per_page' => $itemPerPage,
            ];

            $contractStatuses = $api->$methodCollection($params);
            $currentCount = count($contractStatuses);

            if ($force) {
                $this->contractStatusService->resetContractStatusesFromErpService(
                    $this->contractType,
                    $contractStatuses
                );
            }

            return [$currentCount];
        };
    }
}
