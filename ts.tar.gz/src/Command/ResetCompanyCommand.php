<?php

namespace App\Command;

use App\Services\CompanyService;
use Doctrine\ORM\EntityManagerInterface;
use Sfk\Lib\ErpClient\Api\CompanyApi;

/**
 * Class ResetCompanyCommand.
 */
class ResetCompanyCommand extends GetErpBaseCommand
{
    protected static $defaultName = 'app:reset:company';

    /**
     * @var CompanyService
     */
    private $companyService;

    /**
     * @var CompanyApi
     */
    private $companyApi;

    /**
     * ResetCompanyCommand constructor.
     *
     * @param EntityManagerInterface $entityManager
     * @param CompanyService         $companyService
     */
    public function __construct(EntityManagerInterface $entityManager, CompanyService $companyService)
    {
        parent::__construct($entityManager);
        $this->companyService = $companyService;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        parent::configure();
        $this
            ->setDescription('Reset companies')
        ;
    }

    /**
     * @return CompanyApi
     */
    protected function getCompanyApi()
    {
        if (null === $this->companyApi) {
            $this->companyApi = $this->getErpClient()->getCompanyApi();
        }

        return $this->companyApi;
    }

    /**
     * @return \Closure
     */
    protected function getBulkCallback()
    {
        return function ($page, $itemPerPage, $force) {
            $params = [
                'page' => $page,
                'items_per_page' => $itemPerPage,
            ];
            $companies = $this->getCompanyApi()->getCompanyCollection($params);
            $currentCount = count($companies);

            if ($force) {
                $this->companyService->resetCompaniesFromErpService($companies);
            }

            return [$currentCount];
        };
    }
}
