<?php

namespace App\Command;

use App\Command\Traits\WithCustomSqlLoggerTrait;
use App\Command\Traits\WithTemplateRulesTrait;
use App\Entity\Email;
use App\Entity\EmailScheduledReport;
use App\Services\CriteriaBuilderService;
use App\Services\ErpServiceClient;
use JMS\JobQueueBundle\Entity\Job;
use Psr\Log\LoggerInterface;
use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class EmailScheduledPaginatorCommand.
 */
class EmailScheduledPaginatorCommand extends Command
{
    use WithCustomSqlLoggerTrait;
    use WithTemplateRulesTrait;

    /**
     * Job queue name for the JMSJobQueueBundle.
     */
    const COMMAND_QUEUE_NAME = 'paginator';

    /**
     * Default items per page we get from erp-service.
     */
    const DEFAULT_ITEMS_PER_PAGE = 1000;

    protected static $defaultName = 'app:scheduler:email-paginator';

    /**
     * @var RegistryInterface
     */
    protected $registry;

    /**
     * @var CriteriaBuilderService
     */
    protected $criteriaBuilderService;

    /**
     * @var ErpServiceClient
     */
    protected $erpServiceClient;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * EmailScheduledPaginatorCommand constructor.
     *
     * @param RegistryInterface      $registry
     * @param CriteriaBuilderService $criteriaBuilderService
     * @param ErpServiceClient       $erpServiceClient
     * @param LoggerInterface        $logger
     */
    public function __construct(RegistryInterface $registry,
                                CriteriaBuilderService $criteriaBuilderService,
                                ErpServiceClient $erpServiceClient,
                                LoggerInterface $logger)
    {
        parent::__construct();

        $this->registry = $registry;
        $this->criteriaBuilderService = $criteriaBuilderService;
        $this->erpServiceClient = $erpServiceClient;
        $this->logger = $logger;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        parent::configure();
        $this
            ->setDescription('Create jobs for each page to get from erp-service for a given template')
            ->addOption(
                'template',
                null,
                InputOption::VALUE_REQUIRED,
                'Template used to create paginated and parallel jobs'
            )
            ->addOption(
                'limit',
                null,
                InputOption::VALUE_REQUIRED,
                'How many items per page to get (default:'.self::DEFAULT_ITEMS_PER_PAGE.').'
            )
        ;
    }

    /**
     * Creates jobs for paginated contracts retrieval from erp-service.
     *
     * @param EmailScheduledReport $emailScheduledReport
     * @param Email                $email
     * @param int                  $page
     * @param int                  $limit
     * @param array                $rules
     */
    private function createEmailTemplatePaginatedJob(EmailScheduledReport $emailScheduledReport, Email $email, int $page, int $limit, array $rules = [])
    {
        $job = new Job(
            EmailScheduledPaginatedCommand::getDefaultName(),
            [
                sprintf('--template=%d', $email->getId()),
                sprintf('--report=%d', $emailScheduledReport->getId()),
                sprintf('--page=%d', $page),
                sprintf('--limit=%d', $limit),
                sprintf('--rules=%s', base64_encode(json_encode($rules))),
            ],
            true,
            EmailScheduledPaginatedCommand::COMMAND_QUEUE_NAME
        );
        $retry = $email->getMaxRetry() ?: EmailScheduledPaginatedCommand::JOB_MAX_RETRY;
        $job->addRelatedEntity($email);
        $job->addRelatedEntity($emailScheduledReport);
        $job->setMaxRetries($retry);
        $job->setMaxRuntime(EmailScheduledPaginatedCommand::JOB_MAX_EXECUTION_TIME);
        $this->registry->getManager()->persist($job);
        $this->registry->getManager()->flush();
    }

    /**
     * @param Email $email
     * @param int   $totalPageTodo
     * @param int   $totalItemsTodo
     *
     * @return EmailScheduledReport
     */
    protected function createEmailScheduledReport(Email $email, int $totalPageTodo, int $totalItemsTodo)
    {
        $report = new EmailScheduledReport();
        $report->setEmail($email);
        $report->setTotalItemsTodo($totalItemsTodo);
        $report->setTotalPageTodo($totalPageTodo);
        $this->registry->getManager()->persist($report);
        $this->registry->getManager()->flush();

        return $report;
    }

    /**
     * Create "Paginated" job commands from contracts number (erp-service).
     *
     * @param InputInterface  $input
     * @param OutputInterface $output
     *
     * @return int|null
     *
     * @throws \GuzzleHttp\Exception\GuzzleException
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        try {
            $this->setCustomSqlLogger($this->registry, null);
            $limit = $input->getOption('limit');
            $itemsPerPage = $limit ?? self::DEFAULT_ITEMS_PER_PAGE;
            $templateId = (int) $input->getOption('template');
            if (null === $templateId) {
                throw new \Exception('Template option must be defined');
            }

            $template = $this->getTemplate($this->registry, $templateId);
            $rules = $this->getTemplateRules($this->criteriaBuilderService, $template);
            $totalTemplateContracts = $this->erpServiceClient->getContractCountForTemplate($template, $rules);
            $this->logger->info('Paginator matching contracts count: '.$totalTemplateContracts);

            // We want to create a job per page to get contracts in parallel if needed.
            if ($totalTemplateContracts > 0) {
                $pageCount = (int) ceil($totalTemplateContracts / $itemsPerPage);
                $report = $this->createEmailScheduledReport($template, $pageCount, $totalTemplateContracts);
                $currentPage = 1;
                while ($currentPage <= $pageCount) {
                    $this->createEmailTemplatePaginatedJob($report, $template, $currentPage, $itemsPerPage, $rules);
                    ++$currentPage;
                }
            }

            return 0;
        } catch (\Exception $exception) {
            $this->logger->error('Job paginator error.', [
                'exception' => $exception,
            ]);

            return -1;
        }
    }
}
