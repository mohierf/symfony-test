<?php

namespace App\Command;

use App\Command\Traits\WithCustomSqlLoggerTrait;
use App\Command\Traits\WithTemplateRulesTrait;
use App\Entity\CriteriaHolderInterface;
use App\Entity\EmailScheduledReport;
use App\Entity\TemplateInterface;
use App\Event\EmailScheduledEvent;
use App\MessageBuilder\EmailMessageBuilder;
use App\Producer\EmailMessageProducerInterface;
use App\Services\CriteriaBuilderService;
use App\Services\ErpServiceClient;
use Psr\Log\LoggerInterface;
use Sfk\ErpClientBundle\Services\ClientRegistryInterface;
use Sfk\ErpClientBundle\Services\ClientRegistryTrait;
use Sfk\MailRouterMessages\Model\TemplateDesigner\EmailType;
use Sfk\MailRouterMessages\Serializer\TemplateDesigner\EmailMessageSerializer;
use Sfk\MailRouterMessages\Services\JsonSchemaService;
use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;

/**
 * Class EmailScheduledPaginatedCommand.
 */
class EmailScheduledPaginatedCommand extends Command implements ClientRegistryInterface
{
    use WithCustomSqlLoggerTrait;
    use WithTemplateRulesTrait;
    use ClientRegistryTrait;

    /**
     * Job queue name for the JMSJobQueueBundle.
     */
    const COMMAND_QUEUE_NAME = 'paginated';

    /**
     * Max run attempts if failed.
     * We wiil do it manually for now.
     */
    const JOB_MAX_RETRY = 0;

    /**
     * Max run time.
     * TO avoid too much memory consumption.
     */
    const JOB_MAX_EXECUTION_TIME = 120;

    const EXCHANGE_ROUTING_KEY_SCHEDULED = 'scheduled';

    protected static $defaultName = 'app:scheduler:email-paginated';

    /**
     * @var RegistryInterface
     */
    protected $registry;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * @var CriteriaBuilderService
     */
    protected $criteriaBuilderService;

    /**
     * @var EmailMessageBuilder
     */
    protected $emailMessageBuilder;

    /**
     * @var EmailMessageProducerInterface
     */
    protected $emailMessageProducer;

    /**
     * @var ErpServiceClient
     */
    protected $erpServiceClient;

    /**
     * @var EventDispatcherInterface
     */
    protected $eventDispatcher;

    /**
     * @var bool
     */
    protected $isTest = false;

    /**
     * EmailScheduledPaginatedCommand constructor.
     *
     * @param RegistryInterface             $registry
     * @param LoggerInterface               $logger
     * @param CriteriaBuilderService        $criteriaBuilderService
     * @param EmailMessageBuilder           $emailMessageBuilder
     * @param EmailMessageProducerInterface $emailMessageProducer
     * @param ErpServiceClient              $erpServiceClient
     * @param EventDispatcherInterface      $eventDispatcher
     */
    public function __construct(RegistryInterface $registry,
                                LoggerInterface $logger,
                                CriteriaBuilderService $criteriaBuilderService,
                                EmailMessageBuilder $emailMessageBuilder,
                                EmailMessageProducerInterface $emailMessageProducer,
                                ErpServiceClient $erpServiceClient,
                                EventDispatcherInterface $eventDispatcher)
    {
        parent::__construct();

        $this->registry = $registry;
        $this->logger = $logger;
        $this->criteriaBuilderService = $criteriaBuilderService;
        $this->emailMessageBuilder = $emailMessageBuilder;
        $this->emailMessageProducer = $emailMessageProducer;
        $this->erpServiceClient = $erpServiceClient;
        $this->eventDispatcher = $eventDispatcher;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        parent::configure();
        $this
            ->setDescription('Create jobs for each page to get from erp-service for a given template')
            ->addOption(
                'template',
                null,
                InputOption::VALUE_REQUIRED,
                'Template used to create paginated and parallel jobs.'
            )
            ->addOption(
                'report',
                null,
                InputOption::VALUE_REQUIRED,
                'Report where to store data'
            )
            ->addOption(
                'page',
                null,
                InputOption::VALUE_REQUIRED,
                'Page number to get (start at 1).'
            )
            ->addOption(
                'limit',
                null,
                InputOption::VALUE_REQUIRED,
                'How many items per page to get.'
            )
            ->addOption(
                'rules',
                null,
                InputOption::VALUE_REQUIRED,
                'Template rules base64encoded'
            )
            ->addOption(
                'test',
                null,
                InputOption::VALUE_NONE,
                'Ran directly to test the command'
            )
        ;
    }

    /**
     * Get rules from command option if given, regenerated from BDD otherwise.
     * We avoid calculating rules for each page getting it from parent command.
     *
     * @param InputInterface          $input
     * @param CriteriaHolderInterface $template
     *
     * @return array|bool|string|null
     *
     * @throws \Exception
     */
    private function getRules(InputInterface $input, CriteriaHolderInterface $template)
    {
        $rules = null;
        $rulesBase64 = $input->getOption('rules');
        if (null !== $rulesBase64) {
            $rules = json_decode(base64_decode($rulesBase64), true);
        } else {
            $rules = $this->getTemplateRules($this->criteriaBuilderService, $template);
        }

        return $rules;
    }

    /**
     * @param string               $eventName
     * @param EmailScheduledReport $report
     * @param int|null             $successCount
     * @param int|null             $errorCount
     * @param bool|null            $pageFailed
     */
    protected function dispatchEvent(string $eventName, ?EmailScheduledReport $report, int $successCount = null, int $errorCount = null, bool $pageFailed = false)
    {
        if (!$this->isTest) {
            $this->eventDispatcher->dispatch($eventName, new EmailScheduledEvent([
                'report' => $report,
                'success_count' => $successCount,
                'error_count' => $errorCount,
                'page_failed' => $pageFailed,
            ]));
        }
    }

    /**
     * @param int $reportId
     *
     * @return EmailScheduledReport|object|null
     *
     * @throws \Exception
     */
    protected function getReport(int $reportId)
    {
        $report = $this->registry->getRepository(EmailScheduledReport::class)->find($reportId);

        if (null === $report) {
            throw new \Exception(sprintf('Report not found: %d', $reportId));
        }

        return $report;
    }

    /**
     * @param TemplateInterface $template
     * @param $contract
     *
     * @throws \Twig\Error\LoaderError
     * @throws \Twig\Error\SyntaxError
     */
    protected function createAndPublishEmailMessage(TemplateInterface $template, $contract)
    {
        $message = $this->emailMessageBuilder->buildData($template, $contract, EmailType::SCHEDULED);
        $jsonSchemaService = new JsonSchemaService();
        $messageSerializer = new EmailMessageSerializer($jsonSchemaService);
        $jsonMessage = $messageSerializer->serialize($message);
        $this->emailMessageProducer->publish($jsonMessage, self::EXCHANGE_ROUTING_KEY_SCHEDULED);
    }

    /**
     * Creates Email messages from Contracts retrieved from erp-service for the given page
     * and send them into message broker.
     *
     * @param InputInterface  $input
     * @param OutputInterface $output
     *
     * @return int|null
     *
     * @throws \Throwable
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $stepSuccessCount = 0;
        $stepErrorCount = 0;
        $stepCount = 0;
        $reportId = $input->getOption('report');
        $this->isTest = $input->getOption('test');
        $report = !$this->isTest ? $this->getReport($reportId) : null;
        try {
            $forceFailed = false;
            $this->setCustomSqlLogger($this->registry, null);
            $templateId = (int) $input->getOption('template');
            if (null === $templateId) {
                throw new \Exception('Template option must be defined');
            }
            $template = $this->getTemplate($this->registry, $templateId);

            $page = $input->getOption('page');
            $limit = $input->getOption('limit');
            $rules = $this->getRules($input, $template);

            $contracts = $this->erpServiceClient->getContractsForTemplateDesigner($template, $page, $limit, $rules);

            $this->dispatchEvent(EmailScheduledEvent::EMAIL_JOB_PAGINATED_STARTED, $report);

            foreach ($contracts as $contract) {
                // A bit odd but we want to send as email as we can.
                // So we do not stop the command when the first error occurs.
                // We seed all messages without errors.
                try {
                    $this->createAndPublishEmailMessage($template, $contract);
                    ++$stepSuccessCount;
                } catch (\Exception $ex) {
                    ++$stepErrorCount;
                    $this->logger->error('Email Generation error', [
                        'message' => $ex->getMessage(),
                        'file' => $ex->getFile(),
                        'line' => $ex->getLine(),
                    ]);
                    $forceFailed = true;
                }
                ++$stepCount;
                if (0 === ($stepCount % 200)) {
                    $this->dispatchEvent(EmailScheduledEvent::EMAIL_JOB_PAGINATED_STEP, $report, $stepSuccessCount, $stepErrorCount);
                    $stepErrorCount = 0;
                    $stepSuccessCount = 0;
                }
            }

            $this->dispatchEvent(EmailScheduledEvent::EMAIL_JOB_PAGINATED_FINISHED, $report, $stepSuccessCount, $stepErrorCount, $forceFailed);

            return $forceFailed ? 1 : 0;
        } catch (\Exception $exception) {
            $this->logger->error('Job paginated error.', [
                'exception' => $exception,
            ]);

            $this->dispatchEvent(EmailScheduledEvent::EMAIL_JOB_PAGINATED_ERROR, $report, $stepSuccessCount, $stepErrorCount);

            return -1;
        }
    }
}
