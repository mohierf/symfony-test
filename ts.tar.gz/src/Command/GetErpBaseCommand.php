<?php

namespace App\Command;

use Doctrine\ORM\EntityManagerInterface;
use Sfk\ErpClientBundle\Services\ClientRegistryInterface;
use Sfk\ErpClientBundle\Services\ClientRegistryTrait;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

/**
 * Class GetErpBaseCommand.
 */
abstract class GetErpBaseCommand extends Command implements ClientRegistryInterface
{
    use ClientRegistryTrait;

    /**
     * Enable/Disable max item per page (cf. erp-service).
     */
    const ENABLE_MAX_ITEM_PER_PAGE = true;

    /**
     * Max item per page configured in erp-service.
     */
    const MAX_ITEM_PER_PAGE = 1000;

    /**
     * Default item per page.
     */
    const DEFAULT_ITEM_PER_PAGE = 1000;

    /**
     * @var EntityManagerInterface
     */
    protected $entityManager;

    /**
     * @var OutputInterface
     */
    protected $output;

    /**
     * ResetAgencyCommand constructor.
     *
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(EntityManagerInterface $entityManager)
    {
        parent::__construct();
        $this->entityManager = $entityManager;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        $this
            ->setDescription('Reset base command')
            ->addOption(
                'force',
                null,
                InputOption::VALUE_NONE,
                'Do it, for real'
            )
            ->addOption(
                'bulk',
                null,
                InputOption::VALUE_REQUIRED,
                'Items per page return from the API',
                static::DEFAULT_ITEM_PER_PAGE
            )
            ->addOption(
                'max-items',
                null,
                InputOption::VALUE_REQUIRED,
                'Max items to get',
                null
            )
            ->addOption(
                'max-items-per-page',
                null,
                InputOption::VALUE_REQUIRED,
                'Max items per page',
                static::MAX_ITEM_PER_PAGE
            )
        ;
    }

    protected function getBulkCallback()
    {
        throw new \LogicException('You must override the getBulkCallback() method in the concrete command class.');
    }

    /**
     * Initialize command if needed.
     *
     * @param InputInterface  $input
     * @param OutputInterface $output
     */
    protected function init(InputInterface $input, OutputInterface $output)
    {
    }

    /**
     * Print more details if needed.
     *
     * @param InputInterface  $input
     * @param OutputInterface $output
     */
    protected function details(InputInterface $input, OutputInterface $output)
    {
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     *
     * @return int|void|null
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->init($input, $output);
        $this->output = $output;
        $io = new SymfonyStyle($input, $output);

        $force = $input->getOption('force');
        $maxItems = $input->getOption('max-items');
        if (null !== $maxItems) {
            $maxItems = (int) max(1, $maxItems);
        }

        if (!$force) {
            $output->writeln('');
            $output->writeln("\t<comment>!!! This is a dry-run, use <info>--force</info> to do it for real</comment>");
        }

        $io->section($this->getName());
        $output->writeln(sprintf("\t<comment>Date: <info>%s</info></comment>", date('Y-m-d H:i:s', time())));
        $output->writeln(
            sprintf("\t<comment>Command: <info>%s</info></comment>", $this->getName()),
            OutputInterface::VERBOSITY_NORMAL
        );

        $itemPerPage = (int) $input->getOption('bulk');
        if (static::ENABLE_MAX_ITEM_PER_PAGE) {
            $maxItemsPerPage = (int) $input->getOption('max-items-per-page');
            $output->writeln(sprintf("\t<comment>Max items per page: <info>%d</info></comment>", $maxItemsPerPage), OutputInterface::VERBOSITY_VERBOSE);
            $itemPerPage = min($maxItemsPerPage, $itemPerPage);
        }

        $output->writeln(sprintf("\t<comment>Bulk: <info>%d</info></comment>", $itemPerPage), OutputInterface::VERBOSITY_VERBOSE);
        $output->writeln(sprintf("\t<comment>Max items : <info>%d</info></comment>", $maxItems), OutputInterface::VERBOSITY_VERBOSE);

        $this->details($input, $output);
        $output->writeln('');

        $bulkCallback = $this->getBulkCallback();
        $connection = $this->entityManager->getConnection();
        $connection->getConfiguration()->setSQLLogger(null);

        $page = 1;
        $totalCount = 0;
        $totalDuration = 0;

        do {
            $start = time();
            if (null !== $maxItems) {
                $itemPerPage = min($maxItems - $totalCount, $itemPerPage);
            }

            list($currentCount) = $bulkCallback->__invoke($page, $itemPerPage, $force);

            $totalCount += $currentCount;
            $duration = time() - $start;
            $totalDuration += $duration;

            $this->printBulkStatus($output, [
               'total_count' => $totalCount,
               'current_count' => $currentCount,
               'page' => $page,
               'duration' => $duration,
               'total_duration' => $totalDuration,
            ]);

            ++$page;
        } while ($currentCount === $itemPerPage && (!$maxItems || $maxItems > $totalCount));

        $io->success(sprintf(
            '%s - %d rows managed in %ds',
            (new \DateTime())->format('Y-m-d H:i:s'),
            $totalCount,
            $totalDuration
        ));
    }

    /**
     * @param OutputInterface $output
     * @param array           $info
     */
    protected function printBulkStatus(OutputInterface $output, array $info)
    {
        $message = sprintf(' => Got <info>%d</info> rows for page <info>%d</info> (total: %s)', $info['current_count'], $info['page'], $info['total_count']);
        $message .= sprintf(' - Mem <comment>%dMo</comment>', memory_get_usage(true) / 1024 / 1024);
        $message .= sprintf(' - Duration <comment>%ds</comment>', $info['duration']);
        $message .= sprintf(' - Total <comment>%ds</comment>', $info['total_duration']);

        $output->writeln($message, OutputInterface::VERBOSITY_VERBOSE);
    }
}
