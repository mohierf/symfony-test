<?php

namespace App\Command;

use App\Services\LanguageService;
use Doctrine\ORM\EntityManagerInterface;
use Sfk\Lib\ErpClient\Api\LanguageApi;

/**
 * Class ResetLanguageCommand.
 */
class ResetLanguageCommand extends GetErpBaseCommand
{
    protected static $defaultName = 'app:reset:language';

    /**
     * @var LanguageService
     */
    private $languageService;

    /**
     * @var LanguageApi
     */
    private $languageApi;

    /**
     * ResetLanguageCommand constructor.
     *
     * @param EntityManagerInterface $entityManager
     * @param LanguageService        $languageService
     */
    public function __construct(EntityManagerInterface $entityManager, LanguageService $languageService)
    {
        parent::__construct($entityManager);
        $this->languageService = $languageService;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        parent::configure();
        $this
            ->setDescription('Reset languages')
        ;
    }

    /**
     * @return LanguageApi
     */
    protected function getLanguageApi()
    {
        if (null === $this->languageApi) {
            $this->languageApi = $this->getErpClient()->getLanguageApi();
        }

        return $this->languageApi;
    }

    /**
     * @return \Closure
     */
    protected function getBulkCallback()
    {
        return function ($page, $itemPerPage, $force) {
            $params = [
                'page' => $page,
                'items_per_page' => $itemPerPage,
            ];

            $languages = $this->getLanguageApi()->getLanguageCollection($params);
            $currentCount = count($languages);

            if ($force) {
                $this->languageService->resetLanguagesFromErpService($languages);
            }

            return [$currentCount];
        };
    }
}
