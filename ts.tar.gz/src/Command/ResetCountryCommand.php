<?php

namespace App\Command;

use App\Services\CountryService;
use Doctrine\ORM\EntityManagerInterface;
use Sfk\Lib\ErpClient\Api\CountryApi;

/**
 * Class ResetCountryCommand.
 */
class ResetCountryCommand extends GetErpBaseCommand
{
    protected static $defaultName = 'app:reset:country';

    /**
     * @var CountryService
     */
    private $countryService;

    /**
     * @var CountryApi
     */
    private $countryApi;

    /**
     * ResetCountryCommand constructor.
     *
     * @param EntityManagerInterface $entityManager
     * @param CountryService         $countryService
     */
    public function __construct(EntityManagerInterface $entityManager, CountryService $countryService)
    {
        parent::__construct($entityManager);
        $this->countryService = $countryService;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        parent::configure();
        $this
            ->setDescription('Reset countries')
        ;
    }

    /**
     * @return CountryApi
     */
    protected function getCountryApi()
    {
        if (null === $this->countryApi) {
            $this->countryApi = $this->getErpClient()->getCountryApi();
        }

        return $this->countryApi;
    }

    /**
     * @return \Closure
     */
    protected function getBulkCallback()
    {
        return function ($page, $itemPerPage, $force) {
            $params = [
                'page' => $page,
                'items_per_page' => $itemPerPage,
            ];

            $countries = $this->getCountryApi()->getCountryCollection($params);
            $currentCount = count($countries);

            if ($force) {
                $this->countryService->resetCountriesFromErpService($countries);
            }

            return [$currentCount];
        };
    }
}
