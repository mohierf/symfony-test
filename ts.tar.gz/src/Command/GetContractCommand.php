<?php

namespace App\Command;

use App\Command\Traits\ByTypeOfActTrait;
use Doctrine\ORM\EntityManagerInterface;
use Sfk\Lib\ErpClient\Api\InsuranceContractApi;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class GetContractCommand.
 */
class GetContractCommand extends GetErpBaseCommand
{
    use ByTypeOfActTrait;

    protected static $defaultName = 'app:get:contract';

    const MAX_ITEM_PER_PAGE = 5000;

    /**
     * @var InsuranceContractApi
     */
    private $api;

    /**
     * ResetCompanyCommand constructor.
     *
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(EntityManagerInterface $entityManager)
    {
        parent::__construct($entityManager);
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     *
     * @throws \Exception
     */
    protected function init(InputInterface $input, OutputInterface $output)
    {
        $this->manageContractTypeArgument($input);
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     */
    protected function details(InputInterface $input, OutputInterface $output)
    {
        $output->writeln(sprintf("\t<comment>Contract type: <info>%s</info></comment>", $this->contractType->getName()));
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        parent::configure();
        $this->setDescription('Get contracts from erp service');
        $this->configureContractTypeArgument($this);
    }

    /**
     * @return \Closure
     *
     * @throws \Exception
     */
    protected function getBulkCallback()
    {
        $erpClient = $this->getErpClient();
        $contractTypeName = $this->contractType->getName();
        $methodApi = sprintf('get%sContractApi', ucfirst($contractTypeName));
        $methodCollection = sprintf('get%sContractCollection', ucfirst($contractTypeName));

        if (!method_exists($erpClient, $methodApi)) {
            throw new \Exception(sprintf('Method "%s" not found in object "%s". Please, check Contract type.', $methodApi, get_class($erpClient)));
        }
        $api = $erpClient->$methodApi();

        if (!method_exists($api, $methodCollection)) {
            throw new \Exception(sprintf('Method "%s" not found in object "%s". Please, check Contract type.', $methodCollection, get_class($api)));
        }

        return function ($page, $itemPerPage, $force) use ($api, $methodCollection) {
            $params = [
                'page' => $page,
                'items_per_page' => $itemPerPage,
            ];

            $contracts = $api->$methodCollection($params);
            $currentCount = count($contracts);

            if (OutputInterface::VERBOSITY_VERY_VERBOSE === $this->output->getVerbosity()) {
                $data = [];
                foreach ($contracts as $contract) {
                    $data[] = $contract->getId();
                }
                $this->output->writeln('');
                $this->output->writeln(join(',', $data));
                $this->output->writeln('');
            }

            return [$currentCount];
        };
    }
}
