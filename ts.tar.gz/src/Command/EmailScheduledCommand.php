<?php

namespace App\Command;

use App\Command\Traits\WithCustomSqlLoggerTrait;
use App\Entity\Email;
use JMS\JobQueueBundle\Entity\Job;
use Psr\Log\LoggerInterface;
use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class EmailScheduledCommand.
 */
class EmailScheduledCommand extends Command
{
    use WithCustomSqlLoggerTrait;

    protected static $defaultName = 'app:scheduler:email-scheduled';

    /**
     * @var RegistryInterface
     */
    protected $registry;

    /**
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * EmailScheduledCommand constructor.
     *
     * @param RegistryInterface $registry
     * @param LoggerInterface   $logger
     */
    public function __construct(RegistryInterface $registry, LoggerInterface $logger)
    {
        parent::__construct();
        $this->registry = $registry;
        $this->logger = $logger;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        parent::configure();
        $this
            ->setDescription('Create job for each planned email to deal with')
        ;
    }

    /**
     * Create a job for each scheduled email.
     * That job will create other jobs to retrieve contracts page by page in parallel.
     *
     * @param array $scheduledEmails
     */
    private function createEmailTemplatePaginatorJobs(array $scheduledEmails = [])
    {
        foreach ($scheduledEmails as $scheduledEmail) {
            $job = new Job(
                EmailScheduledPaginatorCommand::getDefaultName(),
                [
                    sprintf('--template=%d', $scheduledEmail->getId()),
                ],
                true,
                EmailScheduledPaginatorCommand::COMMAND_QUEUE_NAME
            );
            $job->addRelatedEntity($scheduledEmail);
            $this->registry->getManager()->persist($job);
        }

        $this->registry->getManager()->flush();
    }

    /**
     * Create "Paginator" job commands from scheduled templates.
     *
     * @param InputInterface  $input
     * @param OutputInterface $output
     *
     * @return int|null
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        // TODO : Write some tests.
        try {
            $this->setCustomSqlLogger($this->registry, null);
            $now = new \DateTime('today');

            $this->logger->info('Getting scheduled emails.');
            $scheduledEmails = $this->registry
                ->getRepository(Email::class)
                ->getScheduledEmailsByForDate($now);

            $this->logger->info('Scheduled emails count: '.count($scheduledEmails));

            $this->createEmailTemplatePaginatorJobs($scheduledEmails);
            $this->logger->info('Scheduled emil jobs created.');

            return 0;
        } catch (\Exception $exception) {
            $this->logger->error('Cron email scheduler error.', [
                'exception' => $exception,
            ]);

            return -1;
        }
    }
}
