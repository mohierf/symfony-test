<?php

namespace App\Command\Traits;

use App\Entity\CriteriaHolderInterface;
use App\Entity\Email;
use App\Services\CriteriaBuilderService;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Trait WithTemplateRulesTrait.
 */
trait WithTemplateRulesTrait
{
    /**
     * @param RegistryInterface $registry
     * @param int               $templateId
     *
     * @return Email|object|null
     *
     * @throws \Exception
     */
    public function getTemplate(RegistryInterface $registry, int $templateId)
    {
        if (null === $templateId) {
            throw new \Exception('Template option must be defined');
        }

        $repository = $registry->getRepository(Email::class);
        $template = $repository->find($templateId);
        if (null === $template) {
            throw new \Exception(sprintf('Template not found: %s', $templateId));
        }

        return $template;
    }

    /**
     * @param CriteriaBuilderService  $criteriaBuilderService
     * @param CriteriaHolderInterface $template
     *
     * @return array
     *
     * @throws \Exception
     */
    public function getTemplateRules(CriteriaBuilderService $criteriaBuilderService, CriteriaHolderInterface $template)
    {
        $rules = $criteriaBuilderService->getRules($template);

        return $rules;
    }
}
