<?php

namespace App\Command\Traits;

use App\Entity\TypeOfAct;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Trait ByTypeOfActTrait.
 */
trait ByTypeOfActTrait
{
    /**
     * @var string
     */
    public static $contractTypeArgument = 'contract-type';

    /**
     * @var EntityManagerInterface
     */
    protected $entityManager;

    /**
     * @var TypeOfAct
     */
    private $contractType;

    /**
     * @var array
     */
    private $contractTypesNames = [];

    /**
     * @param InputInterface $input
     *
     * @throws \Exception
     */
    protected function manageContractTypeArgument(InputInterface $input)
    {
        $type = $input->getArgument(static::$contractTypeArgument);

        $repo = $this->entityManager->getRepository(TypeOfAct::class);
        $typeOfActs = $repo->findAll();

        foreach ($typeOfActs as $typeOfAct) {
            $this->contractTypesNames[] = $typeOfAct->getName();
            if ($typeOfAct->getName() === $type) {
                $this->contractType = $typeOfAct;
            }
        }

        if (!in_array($type, $this->contractTypesNames)) {
            throw new \Exception(sprintf(
                'Invalid type "%s". Allowed are: %s',
                $type,
                join(', ', $this->contractTypesNames)
            ));
        }
    }

    /**
     * @param Command $command
     */
    protected function configureContractTypeArgument(Command $command)
    {
        $command
            ->addArgument(
                static::$contractTypeArgument,
                InputArgument::REQUIRED,
                'Contract type'
            )
        ;
    }

    /**
     * @param OutputInterface $output
     */
    protected function printContractTypeArgument(OutputInterface $output)
    {
        $output->writeln(sprintf("\t<comment>Contract type: <info>%s</info></comment>", $this->contractType->getName()));
    }
}
