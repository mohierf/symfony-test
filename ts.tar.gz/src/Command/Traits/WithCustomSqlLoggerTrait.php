<?php

namespace App\Command\Traits;

use Doctrine\DBAL\Logging\SQLLogger;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Trait WithCustomSqlLoggerTrait.
 */
trait WithCustomSqlLoggerTrait
{
    /**
     * @param RegistryInterface $registry
     * @param SQLLogger|null    $logger
     */
    protected function setCustomSqlLogger(RegistryInterface $registry, SQLLogger $logger = null)
    {
        $connection = $registry->getEntityManager()->getConnection();
        $connection->getConfiguration()->setSQLLogger($logger);
    }
}
