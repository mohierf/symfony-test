<?php

namespace App\Command;

use App\Command\Traits\ByTypeOfActTrait;
use App\Entity\TypeOfAct;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

/**
 * Class ResetAllCommand.
 */
class ResetAllCommand extends Command
{
    /**
     * How many type of act we are supposed to managed.
     */
    const TYPE_OF_ACT_COUNT = 3;

    /**
     * @var EntityManagerInterface
     */
    protected $entityManager;

    protected static $defaultName = 'app:reset:all';

    protected function configure()
    {
        $this
            ->setDescription('Reset all')
            ->addOption(
                'force',
                null,
                InputOption::VALUE_NONE,
                'Do it, for real'
            )
        ;
    }

    /**
     * @param InputInterface  $input
     * @param OutputInterface $output
     *
     * @return int|void|null
     *
     * @throws \Exception
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $io = new SymfonyStyle($input, $output);

        $application = $this->getApplication();

        // Agencies
        $command = ResetAgencyCommand::getDefaultName();
        $application->find($command)->run(new ArrayInput([
            'command' => $command,
            '--force' => $input->getOption('force'),
        ]), $output);

        // Companies
        $command = ResetCompanyCommand::getDefaultName();
        $application->find($command)->run(new ArrayInput([
            'command' => $command,
            '--force' => $input->getOption('force'),
        ]), $output);

        // Countries
        $command = ResetCountryCommand::getDefaultName();
        $application->find($command)->run(new ArrayInput([
            'command' => $command,
            '--force' => $input->getOption('force'),
        ]), $output);

        // Languages
        $command = ResetLanguageCommand::getDefaultName();
        $application->find($command)->run(new ArrayInput([
            'command' => $command,
            '--force' => $input->getOption('force'),
        ]), $output);

        $repo = $this->entityManager->getRepository(TypeOfAct::class);
        $typeOfActs = $repo->findAll();
        $typeOfActsCount = count($typeOfActs);
        if (self::TYPE_OF_ACT_COUNT !== $typeOfActsCount) {
            $io->error(sprintf(
                    'Found %d type of act in DB, but supposed to have %d.',
                    $typeOfActsCount,
                    self::TYPE_OF_ACT_COUNT)
            );
        }
        foreach ($typeOfActs as $typeOfAct) {
            // Contract statuses
            $command = ResetContractStatusCommand::getDefaultName();
            $application->find($command)->run(new ArrayInput([
                'command' => $command,
                ByTypeOfActTrait::$contractTypeArgument => $typeOfAct->getName(),
                '--force' => $input->getOption('force'),
            ]), $output);

            // Contract payment statuses
            $command = ResetContractPaymentStatusCommand::getDefaultName();
            $application->find($command)->run(new ArrayInput([
                'command' => $command,
                ByTypeOfActTrait::$contractTypeArgument => $typeOfAct->getName(),
                '--force' => $input->getOption('force'),
            ]), $output);

            // Contract packages
            $command = ResetContractPackageCommand::getDefaultName();
            $application->find($command)->run(new ArrayInput([
                'command' => $command,
                ByTypeOfActTrait::$contractTypeArgument => $typeOfAct->getName(),
                '--force' => $input->getOption('force'),
            ]), $output);

            // Contract options
            $command = ResetContractOptionCommand::getDefaultName();
            $application->find($command)->run(new ArrayInput([
                'command' => $command,
                ByTypeOfActTrait::$contractTypeArgument => $typeOfAct->getName(),
                '--force' => $input->getOption('force'),
            ]), $output);

            // Event types
            $command = ResetEventTypeCommand::getDefaultName();
            $application->find($command)->run(new ArrayInput([
                'command' => $command,
                ByTypeOfActTrait::$contractTypeArgument => $typeOfAct->getName(),
                '--force' => $input->getOption('force'),
            ]), $output);

            $command = ResetEventStatusCommand::getDefaultName();
            $application->find($command)->run(new ArrayInput([
                'command' => $command,
                ByTypeOfActTrait::$contractTypeArgument => $typeOfAct->getName(),
                '--force' => $input->getOption('force'),
            ]), $output);

            // Only get contract to test everything is OK.
            $command = GetContractCommand::getDefaultName();
            $application->find($command)->run(new ArrayInput([
                'command' => $command,
                '--force' => true,
                ByTypeOfActTrait::$contractTypeArgument => $typeOfAct->getName(),
                '--bulk' => 10,
                '--max-items' => 10,
            ]), $output);
        }
    }

    /**
     * ResetAgencyCommand constructor.
     *
     * @param EntityManagerInterface $entityManager
     */
    public function __construct(EntityManagerInterface $entityManager)
    {
        parent::__construct();
        $this->entityManager = $entityManager;
    }
}
