<?php

namespace App\Command;

use App\Services\AgencyService;
use Doctrine\ORM\EntityManagerInterface;
use Sfk\Lib\ErpClient\Api\AgencyApi;

/**
 * Class ResetAgencyCommand.
 */
class ResetAgencyCommand extends GetErpBaseCommand
{
    const DEFAULT_ITEM_PER_PAGE = 500;

    protected static $defaultName = 'app:reset:agency';

    /**
     * @var AgencyService
     */
    private $agencyService;

    /**
     * @var AgencyApi
     */
    private $agencyApi;

    /**
     * ResetAgencyCommand constructor.
     *
     * @param EntityManagerInterface $entityManager
     * @param AgencyService          $agencyService
     */
    public function __construct(EntityManagerInterface $entityManager, AgencyService $agencyService)
    {
        parent::__construct($entityManager);
        $this->agencyService = $agencyService;
    }

    /**
     * {@inheritdoc}
     */
    protected function configure()
    {
        parent::configure();
        $this
            ->setDescription('Reset agencies')
        ;
    }

    /**
     * @return AgencyApi
     */
    protected function getAgencyApi()
    {
        if (null === $this->agencyApi) {
            $this->agencyApi = $this->getErpClient()->getAgencyApi();
        }

        return $this->agencyApi;
    }

    /**
     * @return \Closure
     */
    protected function getBulkCallback()
    {
        return function ($page, $itemPerPage, $force) {
            $params = [
                'page' => $page,
                'items_per_page' => $itemPerPage,
            ];
            $agencies = $this->getAgencyApi()->getAgencyCollection($params);
            $currentCount = count($agencies);

            if ($force) {
                $this->agencyService->resetAgenciesFromErpService($agencies);
            }

            return [$currentCount];
        };
    }
}
