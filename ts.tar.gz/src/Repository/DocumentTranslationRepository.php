<?php

namespace App\Repository;

use App\Entity\DocumentTranslation;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class DocumentRepository.
 */
class DocumentTranslationRepository extends ServiceEntityRepository
{
    /**
     * DocumentTranslation Repository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, DocumentTranslation::class);
    }
}
