<?php

namespace App\Repository;

use App\Entity\Language;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class LanguageRepository.
 */
class LanguageRepository extends ServiceEntityRepository
{
    /**
     * CompanyRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Language::class);
    }

    /**
     * @param array       $ids
     * @param string|null $indexBy
     *
     * @return mixed
     */
    public function getAllByIds(array $ids, string $indexBy = null)
    {
        $qb = $this->createQueryBuilder('l', $indexBy ? 'l.'.$indexBy : null);
        $qb->andWhere('l.erpId IN (:ids)')->setParameter('ids', $ids);
        $result = $qb->getQuery()->getResult();

        return $result;
    }
}
