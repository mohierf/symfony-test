<?php

namespace App\Repository;

use App\Entity\EventType;
use App\Entity\TypeOfAct;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class EventTypeRepository.
 */
class EventTypeRepository extends ServiceEntityRepository
{
    /**
     * EventTypeRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, EventType::class);
    }

    /**
     * @param TypeOfAct   $type
     * @param array       $ids
     * @param string|null $indexBy
     *
     * @return mixed
     */
    public function getAllByTypeAndIds(TypeOfAct $type, array $ids, string $indexBy = null)
    {
        $qb = $this->createQueryBuilder('cet', $indexBy ? 'cet.'.$indexBy : null);
        $qb->innerJoin('cet.typeOfAct', 'typeOfAct');
        $qb->andWhere('typeOfAct = :type')->setParameter('type', $type);
        $qb->andWhere('cet.erpId IN (:event_types_ids)')->setParameter('event_types_ids', $ids);
        $result = $qb->getQuery()->getResult();

        return $result;
    }
}
