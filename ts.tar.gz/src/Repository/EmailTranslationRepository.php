<?php

namespace App\Repository;

use App\Entity\EmailTranslation;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class DocumentRepository.
 */
class EmailTranslationRepository extends ServiceEntityRepository
{
    /**
     * DocumentRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, EmailTranslation::class);
    }
}
