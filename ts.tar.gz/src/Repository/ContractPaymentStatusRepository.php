<?php

namespace App\Repository;

use App\Entity\ContractPaymentStatus;
use App\Entity\TypeOfAct;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class ContractPaymentStatusRepository.
 */
class ContractPaymentStatusRepository extends ServiceEntityRepository
{
    /**
     * ContractPaymentStatusRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, ContractPaymentStatus::class);
    }

    /**
     * @param TypeOfAct   $type
     * @param array       $statuses
     * @param string|null $indexBy
     *
     * @return mixed
     */
    public function getAllByStatusesAndType(TypeOfAct $type, array $statuses, string $indexBy = null)
    {
        $qb = $this->createQueryBuilder('cps', $indexBy ? 'cps.'.$indexBy : null);
        $qb->innerJoin('cps.typeOfAct', 'typeOfAct');
        $qb->andWhere('typeOfAct = :type')->setParameter('type', $type);
        $qb->andWhere('cps.status IN (:statuses)')->setParameter('statuses', $statuses);
        $result = $qb->getQuery()->getResult();

        return $result;
    }
}
