<?php

namespace App\Repository;

use App\Entity\CustomVariableTranslation;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class CustomVariableTranslationRepository.
 */
class CustomVariableTranslationRepository extends ServiceEntityRepository
{
    /**
     * CustomVariableTranslationRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, CustomVariableTranslation::class);
    }
}
