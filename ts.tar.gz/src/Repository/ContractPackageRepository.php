<?php

namespace App\Repository;

use App\Entity\ContractPackage;
use App\Entity\TypeOfAct;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class ContractPackageRepository.
 */
class ContractPackageRepository extends ServiceEntityRepository
{
    /**
     * ContractPackageRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, ContractPackage::class);
    }

    /**
     * @param TypeOfAct   $type
     * @param array       $ids
     * @param string|null $indexBy
     *
     * @return mixed
     */
    public function getAllByTypeAndIds(TypeOfAct $type, array $ids, string $indexBy = null)
    {
        $qb = $this->createQueryBuilder('cp', $indexBy ? 'cp.'.$indexBy : null);
        $qb->innerJoin('cp.typeOfAct', 'typeOfAct');
        $qb->andWhere('typeOfAct = :type')->setParameter('type', $type);
        $qb->andWhere('cp.erpId IN (:packages_ids)')->setParameter('packages_ids', $ids);
        $result = $qb->getQuery()->getResult();

        return $result;
    }
}
