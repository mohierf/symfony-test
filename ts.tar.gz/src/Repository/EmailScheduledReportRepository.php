<?php

namespace App\Repository;

use App\Entity\EmailScheduledReport;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class EmailScheduledReportRepository.
 */
class EmailScheduledReportRepository extends ServiceEntityRepository
{
    /**
     * EmailScheduledReportRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, EmailScheduledReport::class);
    }
}
