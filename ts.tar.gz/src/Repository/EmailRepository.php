<?php

namespace App\Repository;

use App\Entity\Email;
use App\Entity\ObjectAgencyLinkInterface;
use App\Entity\TypeOfAct;
use App\Exception\MissingErpDataException;
use Datetime;
use DateTimeImmutable;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Exception;
use Sfk\Lib\ErpClient\Model\InsuranceContractRead;
use Sfk\Lib\ErpClient\Model\PrivilegeContractRead;
use Sfk\Lib\ErpClient\Model\WebsiteContractRead;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class EmailRepository.
 */
class EmailRepository extends ServiceEntityRepository
{
    /**
     * EmailRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Email::class);
    }

    /**
     * Returns email scheduled and configured for the given date.
     *
     * @param Datetime $baseDate
     *
     * @return array
     */
    public function getScheduledEmailsByForDate(Datetime $baseDate): array
    {
        $qb = $this->createQueryBuilder('e');

        $baseDateConditions = $qb->expr()->andX(
            $qb->expr()->orX('e.beginSendPeriod IS NULL', ':base_date >= e.beginSendPeriod'),
            $qb->expr()->orX('e.endSendPeriod IS NULL', ':base_date <= e.endSendPeriod')
        );

        $qb->andWhere('e.scheduled = :email_scheduled')->setParameter('email_scheduled', true);
        $qb->andWhere('e.active = :email_active')->setParameter('email_active', true);
        $qb->andWhere($baseDateConditions)->setParameter('base_date', $baseDate);

        return $qb->getQuery()->getResult();
    }

    /**
     * Returns templates whom criteria match with a given contract.
     *
     * @param InsuranceContractRead|PrivilegeContractRead|WebsiteContractRead $contract
     * @param string                                                          $typeOfAct
     * @param string|null                                                     $categoryCode
     *
     * @return array
     *
     * @throws Exception
     */
    public function findMatchingTemplates($contract, string $typeOfAct, ?string $categoryCode): array
    {
        $now = new DateTimeImmutable('now');

        $qb = $this->createQueryBuilder('email');

        // Get only ACTIVE template
        $qb->andWhere('email.active = :active')->setParameter('active', true);

        // Get only AUTOMATIC sending
        $qb->andWhere('email.automatic = :automatic')->setParameter('automatic', true);

        /*** TYPE OF ACT ***/
        if ($typeOfAct && in_array($typeOfAct, TypeOfAct::TYPES_OF_ACT, true)) {
            $qb->innerJoin('email.typeOfAct', 'type_of_act');
            $qb->andWhere('type_of_act.name = :typeOfAct')->setParameter('typeOfAct', $typeOfAct);
        } else {
            // A contract must have a type of act
            throw new MissingErpDataException(sprintf('Type of act is missing for contract %s.', $contract->getId()));
        }

        /*** CATEGORY ***/
        $qb->innerJoin('email.category', 'category');
        if ($categoryCode) {
            $qb->andWhere('category.code = :categoryCode')->setParameter('categoryCode', $categoryCode);
        } else {
            $qb->andWhere('category.code IS NULL');
        }

        /*** COMPANY ***/
        if (($company = $contract->getCompany()) && ($companyId = $company->getId())) {
            $qb->innerJoin('email.company', 'company');
            $qb->andWhere('company.erpId = :companyId')->setParameter('companyId', $companyId);
        } else {
            // A contract must have a company
            throw new MissingErpDataException(sprintf('Company is missing for contract %s.', $contract->getId()));
        }

        /* COUNTRY CODE OF THE CLIENT ADDRESS ***/
        if (($client = $contract->getClient()) && ($addresses = $client->getAddresses())) {
            $qb->innerJoin('email.country', 'country');
            $countryId = null;
            foreach ($addresses as $address) {
                if ('client' === $address->getType()) {
                    if (($city = $address->getAddress()->getCity()) && $country = $city->getCountry()) {
                        $countryId = $country->getId();
                    }
                    break;
                }
            }
            if ($countryId) {
                $qb->andWhere('country.erpId = :countryId')->setParameter('countryId', $countryId);
            } else {
                // A contract must have a client country code
                throw new MissingErpDataException(sprintf('Client or client country is missing for contract %s.', $contract->getId()));
            }
        } else {
            // A contract must have at least an client's address of type 'client'
            throw new MissingErpDataException(sprintf('Client address is missing for contract %s.', $contract->getId()));
        }

        /*** PAYMENT STATUS ***/
        $qb->leftJoin('email.paymentStatuses', 'payment_statuses');
        if ($contract->getPaymentStatus()) {
            $paymentStatusCondition = $qb->expr()->orX(
                'payment_statuses.status IS NULL',
                'payment_statuses.status = :paymentStatus'
            );
            $qb->andWhere($paymentStatusCondition)->setParameter('paymentStatus', $contract->getPaymentStatus());
        } else {
            $qb->andWhere('payment_statuses.status IS NULL');
        }

        /*** PACKAGE ***/
        if (($package = $contract->getPackage()) && ($packageErpId = $package->getId())) {
            // The contract package must match templates having the same package or none
            $qb->leftJoin('email.packages', 'packages');
            $packageCondition = $qb->expr()->orX('packages.erpId IS NULL', 'packages.erpId = :packageErpId');
            $qb->andWhere($packageCondition)->setParameter('packageErpId', $packageErpId);
        } else {
            // A contract must have a package
            throw new MissingErpDataException(sprintf('Package is missing for contract %s.', $contract->getId()));
        }

        /*** CONTRACT STATUS ***/
        $qb->leftJoin('email.contractStatuses', 'contract_statuses');
        $qb->leftJoin('contract_statuses.contractStatus', 'contract_status');
        if ($contract->getStatus()) {
            // If the contract has a status then it match templates having the same contract status (with no delay) or none
            $contractStatusCondition = $qb->expr()->orX(
                'contract_status.status IS NULL',
                $qb->expr()->andX(
                    'contract_status.status = :contractStatus',
                    $qb->expr()->orX('contract_statuses.minDelaySinceStatusChange IS NULL', 'contract_statuses.minDelaySinceStatusChange = 0')
                )
            );
            $qb->andWhere($contractStatusCondition)->setParameter('contractStatus', $contract->getStatus());
        } else {
            // If the contract has no status then it matches all templates without statuses
            $qb->andWhere('contract_status.status IS NULL');
        }

        /*** AGENCIES ***/
        if ($agency = $contract->getAgency()) {
            /*** AGENCY LANGUAGE CODE ***/
            if (($agencylanguage = $agency->getLanguage()) && ($languageId = $agencylanguage->getId())) {
                $qb->innerJoin('email.language', 'language');
                $qb->andWhere('language.erpId = :agencylanguageId')->setParameter('agencylanguageId', $languageId);
            } else {
                throw new MissingErpDataException(sprintf('Agency language is missing for contract %s.', $contract->getId()));
            }

            $qb->leftJoin('email.agencies', 'agencies');
            $qb->leftJoin('agencies.agency', 'agency');
            // If there is no selected agency (ie agencies.type IS NULL) then the contract always match
            $agenciesCondition = $qb->expr()->orX('agencies.type IS NULL');
            $agenciesCondition->add($qb->expr()->andX("agencies.type = '".ObjectAgencyLinkInterface::TYPE_AGENCY."'", 'agency.erpId = :agencyId'));
            $qb->setParameter('agencyId', $agency->getId());

            if ($mainAgency = $agency->getMainAgency()) {
                $agenciesCondition->add($qb->expr()->andX("agencies.type = '".ObjectAgencyLinkInterface::TYPE_MAIN_AGENCY."'", 'agency.erpId = :mainAgencyId'));
                $qb->setParameter('mainAgencyId', $mainAgency->getId());
            }

            if ($groupAgency = $agency->getGroupAgency()) {
                $agenciesCondition->add($qb->expr()->andX("agencies.type = '".ObjectAgencyLinkInterface::TYPE_GROUP_AGENCY."'", 'agency.erpId = :groupAgencyId'));
                $qb->setParameter('groupAgencyId', $groupAgency->getId());
            }
        } else {
            throw new MissingErpDataException(sprintf('Agency is missing for contract %s.', $contract->getId()));
        }

        $qb->andWhere($agenciesCondition);

        /*** EVENTS ***/
        $events = $contract->getEvents();

        if ($events) {
            $qb->leftJoin('email.contractEvents', 'contract_events');
            $qb->leftJoin('contract_events.eventType', 'event_type');
            $qb->leftJoin('contract_events.eventStatus', 'event_status');

            $contractEventsCondition = $qb->expr()->orX('event_type.erpId IS NULL');
            foreach ($events as $index => $event) {
                // When the status of an event changes, we have to know how long after its creation this occurs
                $eventAge = $now->diff($event->getCreation())->days;
                $contractEventsCondition->add(
                    $qb->expr()->andX(
                        'event_type.erpId = :eventType'.$index,
                        'event_status.status = :status'.$index,
                        $qb->expr()->orX(
                            'contract_events.minDelaySinceEventCreation IS NULL',
                            'contract_events.minDelaySinceEventCreation = 0',
                            'contract_events.minDelaySinceEventCreation <= :eventAge'.$index
                        ),
                        $qb->expr()->orX(
                            'contract_events.maxDelaySinceEventCreation IS NULL',
                            'contract_events.maxDelaySinceEventCreation = 0',
                            'contract_events.maxDelaySinceEventCreation >= :eventAge'.$index
                        )
                    )
                );
                $qb->setParameter('eventType'.$index, $event->getType()->getId())
                    ->setParameter('status'.$index, $event->getStatus())
                    ->setParameter('eventAge'.$index, $eventAge);
            }
            $qb->andWhere($contractEventsCondition);
        }

        /*** SENDING PERIOD ***/
        $baseDateConditions = $qb->expr()->andX(
            $qb->expr()->orX('email.beginSendPeriod IS NULL', ':date >= email.beginSendPeriod'),
            $qb->expr()->orX('email.endSendPeriod IS NULL', ':date <= email.endSendPeriod')
        );

        $qb->andWhere($baseDateConditions)->setParameter('date', $now);

        return $qb->getQuery()->getResult();
    }
}
