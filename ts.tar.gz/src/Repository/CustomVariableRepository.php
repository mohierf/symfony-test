<?php

namespace App\Repository;

use App\Entity\CustomVariable;
use App\Entity\Email;
use App\Entity\Template;
use App\Entity\TemplateInterface;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class CustomVariableRepository.
 */
class CustomVariableRepository extends ServiceEntityRepository
{
    /**
     * CustomVariableRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, CustomVariable::class);
    }

    /**
     * Returns templates whom criteria match with a given contract.
     *
     * @param CustomVariable $customVariable
     *
     * @return array
     */
    public function findTemplatesByCustomVariable(CustomVariable $customVariable): array
    {
        $result = [];

        $templatesCollections = [
            'email' => $this->getEntityManager()->getRepository('App:Email')->findAll(),
            'template' => $this->getEntityManager()->getRepository('App:Template')->findAll(),
            'document' => $this->getEntityManager()->getRepository('App:Document')->findAll(),
        ];

        // @todo Should be improved.
        foreach ($templatesCollections as $type => $templatesCollection) {
            foreach ($templatesCollection as $template) {
                if ($variables = $this->findCustomVariablesByTemplate($template)) {
                    foreach ($variables as $variable) {
                        if ($variable === $customVariable) {
                            $result[$type][$template->getId()] = $template;
                        }
                    }
                }
            }
        }

        return $result;
    }

    /**
     * Returns templates whom criteria match with a given contract.
     *
     * @param TemplateInterface|Email|Template $template
     *
     * @return array
     */
    public function findCustomVariablesByTemplate(TemplateInterface $template): array
    {
        $templateClassName = get_class($template);

        $qb = $this->createQueryBuilder('cv');

        $qb->leftJoin('cv.typeOfAct', 'typeOfAct');
        $typeOfActCondition = $qb->expr()->orX('typeOfAct IS NULL');
        if (property_exists($templateClassName, 'typeOfAct')) {
            $typeOfActCondition->add($qb->expr()->orX('typeOfAct = :typeOfAct'));
            $qb->setParameter('typeOfAct', $template->getTypeOfAct());
        }
        $qb->andWhere($typeOfActCondition);

        $qb->leftJoin('cv.company', 'company');
        $companyCondition = $qb->expr()->orX('company IS NULL');
        if (property_exists($templateClassName, 'company')) {
            $companyCondition->add($qb->expr()->orX('company = :company'));
            $qb->setParameter('company', $template->getCompany());
        }
        $qb->andWhere($companyCondition);

        $qb->leftJoin('cv.language', 'language');
        $languageCondition = $qb->expr()->orX('language IS NULL');
        if (property_exists($templateClassName, 'language')) {
            $languageCondition->add($qb->expr()->orX('language = :language'));
            $qb->setParameter('language', $template->getLanguage());
        }
        $qb->andWhere($languageCondition);

        $qb->leftJoin('cv.country', 'country');
        $countryCondition = $qb->expr()->orX('country IS NULL');
        if (property_exists($templateClassName, 'country')) {
            $countryCondition->add($qb->expr()->orX('country = :country'));
            $qb->setParameter('country', $template->getCountry());
        }
        $qb->andWhere($countryCondition);

        $qb->leftJoin('cv.agencies', 'agencies');
        $qb->leftJoin('agencies.agency', 'agency');
        $agenciesCondition = $qb->expr()->orX('agency IS NULL');
        if (property_exists($templateClassName, 'agencies')) {
            foreach ($template->getAgencies() as $key => $agency) {
                $agenciesCondition->add($qb->expr()->orX('agencies.agency = :agency'.$key));
                $qb->setParameter('agency'.$key, $agency->getAgency());
                $agenciesCondition->add($qb->expr()->orX('agencies.agency = :mainAgency'.$key));
                $qb->setParameter('mainAgency'.$key, $agency->getAgency()->getMainAgency());
                $agenciesCondition->add($qb->expr()->orX('agencies.agency = :groupAgency'.$key));
                $qb->setParameter('groupAgency'.$key, $agency->getAgency()->getGroupAgency());
            }
        }
        $qb->andWhere($agenciesCondition);

        $qb->leftJoin('cv.agencyFamilies', 'family');
        $agencyFamiliesCondition = $qb->expr()->orX('family IS NULL');
        if (property_exists($templateClassName, 'agencies')) {
            foreach ($template->getAgencies() as $key => $agency) {
                if ($agency->getAgency()->getFamily()) {
                    $agencyFamiliesCondition->add($qb->expr()->orX('family = :family'.$key));
                    $qb->setParameter('family'.$key, $agency->getAgency()->getFamily());
                }
            }
        }
        $qb->andWhere($agencyFamiliesCondition);

        return $qb->getQuery()->getResult();
    }
}
