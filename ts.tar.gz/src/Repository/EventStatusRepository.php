<?php

namespace App\Repository;

use App\Entity\EventStatus;
use App\Entity\TypeOfAct;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class EventStatusRepository.
 */
class EventStatusRepository extends ServiceEntityRepository
{
    /**
     * EventStatusRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, EventStatus::class);
    }

    /**
     * @param TypeOfAct   $type
     * @param array       $statuses
     * @param string|null $indexBy
     *
     * @return mixed
     */
    public function getAllByStatusesAndType(TypeOfAct $type, array $statuses, string $indexBy = null)
    {
        $qb = $this->createQueryBuilder('es', $indexBy ? 'es.'.$indexBy : null);
        $qb->innerJoin('es.typeOfAct', 'typeOfAct');
        $qb->andWhere('typeOfAct = :type')->setParameter('type', $type);
        $qb->andWhere('es.status IN (:statuses)')->setParameter('statuses', $statuses);
        $result = $qb->getQuery()->getResult();

        return $result;
    }
}
