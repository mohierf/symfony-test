<?php

namespace App\Repository;

use App\Entity\Agency;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class AgencyRepository.
 */
class AgencyRepository extends ServiceEntityRepository
{
    /**
     * AgencyRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Agency::class);
    }

    /**
     * @param array       $ids
     * @param string|null $indexBy
     *
     * @return mixed
     */
    public function getAllByIds(array $ids, string $indexBy = null)
    {
        $qb = $this->createQueryBuilder('a', $indexBy ? 'a.'.$indexBy : null);
        $qb->andWhere('a.erpId IN (:agencies_ids)')->setParameter('agencies_ids', $ids);
        $result = $qb->getQuery()->getResult();

        return $result;
    }
}
