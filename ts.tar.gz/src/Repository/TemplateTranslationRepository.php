<?php

namespace App\Repository;

use App\Entity\TemplateTranslation;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class TemplateTranslationRepository.
 */
class TemplateTranslationRepository extends ServiceEntityRepository
{
    /**
     * TemplateTranslationRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, TemplateTranslation::class);
    }
}
