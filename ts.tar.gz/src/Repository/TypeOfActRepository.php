<?php

namespace App\Repository;

use App\Entity\TypeOfAct;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class TypeOfActRepository.
 */
class TypeOfActRepository extends ServiceEntityRepository
{
    /**
     * TypeOfActRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, TypeOfAct::class);
    }
}
