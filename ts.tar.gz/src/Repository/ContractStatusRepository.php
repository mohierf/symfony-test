<?php

namespace App\Repository;

use App\Entity\ContractStatus;
use App\Entity\TypeOfAct;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class ContractStatusRepository.
 */
class ContractStatusRepository extends ServiceEntityRepository
{
    /**
     * ContractStatusRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, ContractStatus::class);
    }

    /**
     * @param TypeOfAct   $type
     * @param array       $statuses
     * @param string|null $indexBy
     *
     * @return mixed
     */
    public function getAllByStatusesAndType(TypeOfAct $type, array $statuses, string $indexBy = null)
    {
        $qb = $this->createQueryBuilder('cs', $indexBy ? 'cs.'.$indexBy : null);
        $qb->innerJoin('cs.typeOfAct', 'typeOfAct');
        $qb->andWhere('typeOfAct = :type')->setParameter('type', $type);
        $qb->andWhere('cs.status IN (:statuses)')->setParameter('statuses', $statuses);
        $result = $qb->getQuery()->getResult();

        return $result;
    }
}
