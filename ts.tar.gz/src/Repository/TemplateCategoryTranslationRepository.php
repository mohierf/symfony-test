<?php

namespace App\Repository;

use App\Entity\TemplateCategoryTranslation;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class TemplateCategoryTranslationRepository.
 */
class TemplateCategoryTranslationRepository extends ServiceEntityRepository
{
    /**
     * TemplateCategoryTranslationRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, TemplateCategoryTranslation::class);
    }
}
