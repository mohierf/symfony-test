<?php

namespace App\Repository;

use App\Entity\TemplateCategory;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class TemplateCategoryRepository.
 */
class TemplateCategoryRepository extends ServiceEntityRepository
{
    /**
     * TemplateCategoryRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, TemplateCategory::class);
    }
}
