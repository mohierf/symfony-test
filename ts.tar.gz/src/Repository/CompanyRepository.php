<?php

namespace App\Repository;

use App\Entity\Company;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * Class CompanyRepository.
 */
class CompanyRepository extends ServiceEntityRepository
{
    /**
     * CompanyRepository constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Company::class);
    }

    /**
     * @param array       $ids
     * @param string|null $indexBy
     *
     * @return mixed
     */
    public function getAllByIds(array $ids, string $indexBy = null)
    {
        $qb = $this->createQueryBuilder('c', $indexBy ? 'c.'.$indexBy : null);
        $qb->andWhere('c.erpId IN (:ids)')->setParameter('ids', $ids);
        $result = $qb->getQuery()->getResult();

        return $result;
    }
}
