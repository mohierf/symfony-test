<?php

namespace App\Producer;

/**
 * Class LanguageMessageProducer.
 */
class LanguageMessageProducer extends BaseMessageProducer
{
    /**
     * {@inheritdoc}
     */
    protected function buildMessage(array $options = []): array
    {
        $data = [
            'type' => 'insert',
            'data' => [
                'id' => $this->generator->randomNumber(8),
                'code' => $this->generator->locale,
            ],
        ];

        return array_merge($data, $options);
    }
}
