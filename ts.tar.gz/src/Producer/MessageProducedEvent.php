<?php

namespace App\Producer;

use Symfony\Component\EventDispatcher\Event;

/**
 * Class MessageProducedEvent.
 */
class MessageProducedEvent extends Event
{
    const PRE_PRODUCTION = 'pre_message_production';
    const POST_PRODUCTION = 'post_message_production';

    /**
     * @var array
     */
    protected $message = [];

    public function __construct(array $message = [])
    {
        $this->message = $message;
    }

    /**
     * @return array
     */
    public function getMessage(): array
    {
        return $this->message;
    }
}
