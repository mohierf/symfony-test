<?php

namespace App\Producer;

use App\Services\RetryService;
use OldSound\RabbitMqBundle\RabbitMq\ProducerInterface;

/**
 * Class EmailMessageProducer.
 */
class EmailMessageProducer implements EmailMessageProducerInterface
{
    /**
     * @var ProducerInterface
     */
    protected $producer;

    /**
     * @var RetryService
     */
    protected $retryService;

    /**
     * EmailMessageProducer constructor.
     *
     * @param ProducerInterface $producer
     * @param RetryService      $retryService
     */
    public function __construct(ProducerInterface $producer, RetryService $retryService)
    {
        $this->producer = $producer;
        $this->retryService = $retryService;
    }

    /**
     * @param string $message
     * @param string $routingKey
     * @param array  $additionalProperties
     *
     * @return mixed|void
     *
     * @throws \Exception
     */
    public function publish(string $message, $routingKey = '', array $additionalProperties = [])
    {
        $this->retryService->callRetry(function () use ($message, $routingKey, $additionalProperties) {
            return $this->producer->publish($message, $routingKey, $additionalProperties);
        });
    }
}
