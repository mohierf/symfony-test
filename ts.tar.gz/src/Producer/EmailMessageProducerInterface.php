<?php

namespace App\Producer;

/**
 * Interface EmailMessageProducerInterface.
 */
interface EmailMessageProducerInterface
{
    /**
     * @param string $message
     * @param string $routingKey
     * @param array  $additionalProperties
     *
     * @return mixed
     */
    public function publish(string $message, $routingKey = '', array $additionalProperties = []);
}
