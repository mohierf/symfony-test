<?php

namespace App\Producer;

/**
 * Class CountryMessageProducer.
 */
class CountryMessageProducer extends BaseMessageProducer
{
    /**
     * {@inheritdoc}
     */
    protected function buildMessage(array $options = []): array
    {
        $data = [
            'type' => 'insert',
            'data' => [
                'id' => $this->generator->randomNumber(8),
                'name' => 'PRODUCED: '.$this->generator->country,
                'code' => $this->generator->languageCode,
            ],
        ];

        return array_merge($data, $options);
    }
}
