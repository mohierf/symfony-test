<?php

namespace App\Producer;

/**
 * Class ProducerRegistry.
 */
class ProducerRegistry
{
    /**
     * @var array
     */
    protected $producers = [];

    /**
     * @param $table
     * @param $object
     */
    public function addProducer(string $table, MessageProducerInterface $object)
    {
        $this->producers[$table] = $object;
    }

    /**
     * @return array
     */
    public function getProducers()
    {
        return $this->producers;
    }

    /**
     * @param string $table
     *
     * @return MessageProducerInterface
     */
    public function getProducer(string $table)
    {
        if (!isset($this->producers[$table])) {
            throw new \InvalidArgumentException(sprintf('No producer found for table "%s"', $table));
        }

        return $this->producers[$table];
    }
}
