<?php

namespace App\Producer;

/**
 * Class CompanyMessageProducer.
 */
class CompanyMessageProducer extends BaseMessageProducer
{
    /**
     * {@inheritdoc}
     */
    protected function buildMessage(array $options = []): array
    {
        $data = [
            'type' => 'insert',
            'data' => [
                'id' => $this->generator->randomNumber(8),
                'code' => $this->generator->name,
                'name' => 'PRODUCED: '.$this->generator->name,
            ],
        ];

        return array_merge($data, $options);
    }
}
