<?php

namespace App\Producer;

/**
 * Class AgencyMessageProducer.
 */
class AgencyMessageProducer extends BaseMessageProducer
{
    /**
     * {@inheritdoc}
     */
    protected function buildMessage(array $options = []): array
    {
        $data = [
            'type' => 'insert',
            'data' => [
                'id' => $this->generator->randomNumber(8),
                'name' => 'PRODUCED: '.$this->generator->name,
                'id_group_agency' => $this->generator->randomNumber(),
                'id_main_agency' => $this->generator->randomNumber(),
            ],
        ];

        return array_merge($data, $options);
    }
}
