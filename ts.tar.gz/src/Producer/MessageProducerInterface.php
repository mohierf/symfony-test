<?php

namespace App\Producer;

/**
 * Interface MessageProducerInterface.
 */
interface MessageProducerInterface
{
    /**
     * @param string $databaseName
     *
     * @return self
     */
    public function setDatabaseName(string $databaseName);

    /**
     * @return string
     */
    public function getDatabaseName(): string;

    /**
     * @param string $tableName
     *
     * @return self
     */
    public function setTableName(string $tableName);

    /**
     * @return string
     */
    public function getTableName(): string;

    /**
     * @return string
     */
    public function getModel(): string;

    /**
     * @param string $model
     */
    public function setModel(string $model);

    /**
     * @param array $attributes
     *
     * @return self
     */
    public function setSyncedAttributes(array $attributes);

    /**
     * @param array $identifiers
     *
     * @return self
     */
    public function setIdentifiers(array $identifiers);

    /**
     * Produce a message.
     *
     * @param array $options
     *
     * @return mixed
     */
    public function produce(array $options = []);
}
