<?php

namespace App\Producer;

use App\Synchronizer\BaseSynchronizer;
use Doctrine\ORM\EntityManagerInterface;
use Faker\Generator;
use OldSound\RabbitMqBundle\RabbitMq\Producer as RabbitMQProducer;
use Symfony\Component\EventDispatcher\EventDispatcher;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;

/**
 * Class BaseMessageProducer.
 */
class BaseMessageProducer implements MessageProducerInterface
{
    /**
     * @var string
     */
    protected $databaseName;

    /**
     * @var string
     */
    protected $tableName;

    /**
     * @var string
     */
    protected $model;

    /**
     * @var array
     */
    protected $syncedAttributes = [];

    /**
     * @var array
     */
    protected $identifiers = [];

    /**
     * @var RabbitMQProducer
     */
    protected $producer;

    /**
     * @var EntityManagerInterface
     */
    protected $entityManager;

    /**
     * @var Generator
     */
    protected $generator;

    /**
     * @var EventDispatcherInterface
     */
    protected $eventDispatcher;

    /**
     * {@inheritdoc}
     */
    public function setDatabaseName(string $databaseName)
    {
        $this->databaseName = $databaseName;

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getDatabaseName(): string
    {
        return $this->databaseName;
    }

    /**
     * {@inheritdoc}
     */
    public function setTableName(string $tableName)
    {
        $this->tableName = $tableName;

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function getTableName(): string
    {
        return $this->tableName;
    }

    /**
     * {@inheritdoc}
     */
    public function getModel(): string
    {
        return $this->model;
    }

    /**
     * {@inheritdoc}
     */
    public function setModel(string $model)
    {
        $this->model = $model;

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setSyncedAttributes(array $attributes)
    {
        $this->syncedAttributes = $attributes;

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setIdentifiers(array $identifiers)
    {
        $this->identifiers = $identifiers;

        return $this;
    }

    public function getMandatoryData()
    {
        return array_merge($this->identifiers, $this->syncedAttributes);
    }

    /**
     * BaseMessageProducer constructor.
     *
     * @param EntityManagerInterface   $entityManager
     * @param RabbitMQProducer         $producer
     * @param Generator                $generator
     * @param EventDispatcherInterface $eventDispatcher
     */
    public function __construct(
        EntityManagerInterface $entityManager,
        RabbitMQProducer $producer,
        Generator $generator,
        EventDispatcherInterface $eventDispatcher)
    {
        $this->entityManager = $entityManager;
        $this->producer = $producer;
        $this->generator = $generator;
        $this->eventDispatcher = $eventDispatcher;
    }

    final public function produce(array $options = [])
    {
        $data = [
            'database' => $this->databaseName,
            'table' => $this->tableName,
            'data' => [],
        ];

        $customData = $this->buildMessage($options);
        $dataArray = $customData['data'];
        $mandatoryData = $this->getMandatoryData();
        $hasMandoryData = array_diff_key(array_flip($mandatoryData), $dataArray);

        if (!empty($hasMandoryData)) {
            throw new \Exception(sprintf(
                'Missing fields "%s". Found: "%s"',
                join(', ', array_keys($hasMandoryData)),
                join(', ', array_keys($dataArray))
            ));
        }

        $data = array_merge($data, $customData);
        if (!in_array($data['type'], BaseSynchronizer::$events)) {
            throw new \Exception('Invalid type '.$data['type']);
        }

        $this->eventDispatcher->dispatch(MessageProducedEvent::PRE_PRODUCTION, new MessageProducedEvent($data));
        $this->producer->publish(json_encode($data));
        $this->eventDispatcher->dispatch(MessageProducedEvent::POST_PRODUCTION, new MessageProducedEvent($data));
    }

    /**
     * Build message data.
     *
     * @param array $options
     *
     * @return array
     */
    protected function buildMessage(array $options = []): array
    {
        $data = [
            'test' => true,
            'type' => 'insert',
            'data' => [
                'id' => $this->generator->randomNumber(8),
                'name' => 'PRODUCED: '.$this->generator->name,
            ],
        ];

        return array_merge($data, $options);
    }
}
