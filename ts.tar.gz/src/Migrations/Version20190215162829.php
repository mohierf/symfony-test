<?php

    declare(strict_types=1);

namespace App\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
     * Auto-generated Migration: Please modify to your needs!
     */
    final class Version20190215162829 extends AbstractMigration
    {
        public function getDescription(): string
        {
            return '';
        }

        public function up(Schema $schema): void
        {
            // this up() migration is auto-generated, please modify it to your needs
            $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

            $this->addSql('CREATE TABLE cron_report (id INT AUTO_INCREMENT NOT NULL, job_id INT DEFAULT NULL, run_at DATETIME NOT NULL, run_time DOUBLE PRECISION NOT NULL, exit_code INT NOT NULL, output LONGTEXT NOT NULL, INDEX IDX_B6C6A7F5BE04EA9 (job_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE cron_job (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(191) NOT NULL, command VARCHAR(1024) NOT NULL, schedule VARCHAR(191) NOT NULL, description VARCHAR(191) NOT NULL, enabled TINYINT(1) NOT NULL, UNIQUE INDEX un_name (name), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('ALTER TABLE cron_report ADD CONSTRAINT FK_B6C6A7F5BE04EA9 FOREIGN KEY (job_id) REFERENCES cron_job (id)');
            $this->addSql('ALTER TABLE email ADD cron_job_id INT DEFAULT NULL, ADD begin_send_period DATETIME DEFAULT NULL, ADD end_send_period DATETIME DEFAULT NULL');
            $this->addSql('ALTER TABLE email ADD CONSTRAINT FK_E7927C7479099ED8 FOREIGN KEY (cron_job_id) REFERENCES cron_job (id)');
            $this->addSql('CREATE UNIQUE INDEX UNIQ_E7927C7479099ED8 ON email (cron_job_id)');
        }

        public function down(Schema $schema): void
        {
            // this down() migration is auto-generated, please modify it to your needs
            $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

            $this->addSql('ALTER TABLE email DROP FOREIGN KEY FK_E7927C7479099ED8');
            $this->addSql('ALTER TABLE cron_report DROP FOREIGN KEY FK_B6C6A7F5BE04EA9');
            $this->addSql('DROP TABLE cron_report');
            $this->addSql('DROP TABLE cron_job');
            $this->addSql('DROP INDEX UNIQ_E7927C7479099ED8 ON email');
            $this->addSql('ALTER TABLE email DROP cron_job_id, DROP begin_send_period, DROP end_send_period');
        }
    }
