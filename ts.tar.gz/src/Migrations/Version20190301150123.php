<?php

    declare(strict_types=1);

namespace App\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
     * Auto-generated Migration: Please modify to your needs!
     */
    final class Version20190301150123 extends AbstractMigration
    {
        public function getDescription(): string
        {
            return '';
        }

        public function up(Schema $schema): void
        {
            // this up() migration is auto-generated, please modify it to your needs
            $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

            $this->addSql('CREATE TABLE contract_recovery_supervision (id INT UNSIGNED AUTO_INCREMENT NOT NULL, template_id INT UNSIGNED DEFAULT NULL, job_id BIGINT UNSIGNED DEFAULT NULL, state VARCHAR(15) NOT NULL, startedAt DATETIME DEFAULT NULL, closedAt DATETIME DEFAULT NULL, excluded LONGTEXT NOT NULL COMMENT \'(DC2Type:array)\', max_contracts INT UNSIGNED DEFAULT 0 NOT NULL, recovered_contracts INT UNSIGNED DEFAULT 0 NOT NULL, planned_pagination INT UNSIGNED DEFAULT 0 NOT NULL, pagination_finished INT UNSIGNED DEFAULT 0 NOT NULL, pagination_failed INT UNSIGNED DEFAULT 0 NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, UNIQUE INDEX UNIQ_6E9779CD5DA0FB8 (template_id), UNIQUE INDEX UNIQ_6E9779CDBE04EA9 (job_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('ALTER TABLE contract_recovery_supervision ADD CONSTRAINT FK_6E9779CD5DA0FB8 FOREIGN KEY (template_id) REFERENCES email (id)');
            $this->addSql('ALTER TABLE contract_recovery_supervision ADD CONSTRAINT FK_6E9779CDBE04EA9 FOREIGN KEY (job_id) REFERENCES jms_jobs (id)');
            $this->addSql('ALTER TABLE email ADD priority INT UNSIGNED DEFAULT 0 NOT NULL, ADD max_retry INT UNSIGNED DEFAULT 0 NOT NULL');
        }

        public function down(Schema $schema): void
        {
            // this down() migration is auto-generated, please modify it to your needs
            $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

            $this->addSql('DROP TABLE contract_recovery_supervision');
            $this->addSql('ALTER TABLE email DROP priority, DROP max_retry');
        }
    }
