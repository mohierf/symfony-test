<?php

declare(strict_types=1);

namespace App\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190220144807 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE invoice_translation (id INT AUTO_INCREMENT NOT NULL, translatable_id INT UNSIGNED DEFAULT NULL, name VARCHAR(255) NOT NULL, locale VARCHAR(255) NOT NULL, INDEX IDX_A327275C2C2AC5D3 (translatable_id), UNIQUE INDEX invoice_translation_unique_translation (translatable_id, locale), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE invoice (id INT UNSIGNED AUTO_INCREMENT NOT NULL, child_id INT UNSIGNED DEFAULT NULL, parent_id INT UNSIGNED DEFAULT NULL, language_id INT UNSIGNED DEFAULT NULL, company_id INT UNSIGNED DEFAULT NULL, css LONGTEXT DEFAULT NULL, css_metadata LONGTEXT DEFAULT NULL, html LONGTEXT DEFAULT NULL, html_metadata LONGTEXT DEFAULT NULL, assets LONGTEXT DEFAULT NULL, version INT NOT NULL, active TINYINT(1) NOT NULL, locked TINYINT(1) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, UNIQUE INDEX UNIQ_90651744DD62C21B (child_id), UNIQUE INDEX UNIQ_90651744727ACA70 (parent_id), INDEX IDX_9065174482F1BAF4 (language_id), INDEX IDX_90651744979B1AD6 (company_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE invoice_translation ADD CONSTRAINT FK_A327275C2C2AC5D3 FOREIGN KEY (translatable_id) REFERENCES invoice (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE invoice ADD CONSTRAINT FK_90651744DD62C21B FOREIGN KEY (child_id) REFERENCES invoice (id)');
        $this->addSql('ALTER TABLE invoice ADD CONSTRAINT FK_90651744727ACA70 FOREIGN KEY (parent_id) REFERENCES invoice (id) ON DELETE SET NULL');
        $this->addSql('ALTER TABLE invoice ADD CONSTRAINT FK_9065174482F1BAF4 FOREIGN KEY (language_id) REFERENCES language (id)');
        $this->addSql('ALTER TABLE invoice ADD CONSTRAINT FK_90651744979B1AD6 FOREIGN KEY (company_id) REFERENCES company (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE invoice_translation DROP FOREIGN KEY FK_A327275C2C2AC5D3');
        $this->addSql('ALTER TABLE invoice DROP FOREIGN KEY FK_90651744DD62C21B');
        $this->addSql('ALTER TABLE invoice DROP FOREIGN KEY FK_90651744727ACA70');
        $this->addSql('DROP TABLE invoice_translation');
        $this->addSql('DROP TABLE invoice');
    }
}
