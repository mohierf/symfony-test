<?php

declare(strict_types=1);

namespace App\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190405103247 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE invoice DROP FOREIGN KEY FK_90651744727ACA70');
        $this->addSql('ALTER TABLE invoice DROP FOREIGN KEY FK_90651744DD62C21B');
        $this->addSql('ALTER TABLE invoice_translation DROP FOREIGN KEY FK_A327275C2C2AC5D3');
        $this->addSql('DROP TABLE invoice');
        $this->addSql('DROP TABLE invoice_translation');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE invoice (id INT UNSIGNED AUTO_INCREMENT NOT NULL, child_id INT UNSIGNED DEFAULT NULL, parent_id INT UNSIGNED DEFAULT NULL, language_id INT UNSIGNED DEFAULT NULL, company_id INT UNSIGNED DEFAULT NULL, css LONGTEXT DEFAULT NULL COLLATE utf8mb4_unicode_ci, css_metadata LONGTEXT DEFAULT NULL COLLATE utf8mb4_unicode_ci, html LONGTEXT DEFAULT NULL COLLATE utf8mb4_unicode_ci, html_metadata LONGTEXT DEFAULT NULL COLLATE utf8mb4_unicode_ci, assets LONGTEXT DEFAULT NULL COLLATE utf8mb4_unicode_ci, version INT NOT NULL, active TINYINT(1) NOT NULL, locked TINYINT(1) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, uuid CHAR(36) NOT NULL COLLATE utf8mb4_unicode_ci COMMENT \'(DC2Type:uuid)\', UNIQUE INDEX UNIQ_90651744DD62C21B (child_id), INDEX IDX_9065174482F1BAF4 (language_id), INDEX IDX_90651744979B1AD6 (company_id), UNIQUE INDEX UNIQ_90651744D17F50A6 (uuid), UNIQUE INDEX UNIQ_90651744727ACA70 (parent_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('CREATE TABLE invoice_translation (id INT AUTO_INCREMENT NOT NULL, translatable_id INT UNSIGNED DEFAULT NULL, name VARCHAR(255) NOT NULL COLLATE utf8mb4_unicode_ci, locale VARCHAR(255) NOT NULL COLLATE utf8mb4_unicode_ci, UNIQUE INDEX invoice_translation_unique_translation (translatable_id, locale), INDEX IDX_A327275C2C2AC5D3 (translatable_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE invoice ADD CONSTRAINT FK_90651744727ACA70 FOREIGN KEY (parent_id) REFERENCES invoice (id) ON DELETE SET NULL');
        $this->addSql('ALTER TABLE invoice ADD CONSTRAINT FK_9065174482F1BAF4 FOREIGN KEY (language_id) REFERENCES language (id)');
        $this->addSql('ALTER TABLE invoice ADD CONSTRAINT FK_90651744979B1AD6 FOREIGN KEY (company_id) REFERENCES company (id)');
        $this->addSql('ALTER TABLE invoice ADD CONSTRAINT FK_90651744DD62C21B FOREIGN KEY (child_id) REFERENCES invoice (id)');
        $this->addSql('ALTER TABLE invoice_translation ADD CONSTRAINT FK_A327275C2C2AC5D3 FOREIGN KEY (translatable_id) REFERENCES invoice (id) ON DELETE CASCADE');
    }
}
