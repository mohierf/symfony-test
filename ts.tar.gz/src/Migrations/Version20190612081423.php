<?php

declare(strict_types=1);

namespace App\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190612081423 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE custom_variable_translation (id INT AUTO_INCREMENT NOT NULL, translatable_id INT UNSIGNED DEFAULT NULL, name VARCHAR(255) NOT NULL, locale VARCHAR(255) NOT NULL, INDEX IDX_71CEBF4C2C2AC5D3 (translatable_id), UNIQUE INDEX custom_variable_translation_unique_translation (translatable_id, locale), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE custom_variable (id INT UNSIGNED AUTO_INCREMENT NOT NULL, company_id INT UNSIGNED DEFAULT NULL, country_id INT UNSIGNED DEFAULT NULL, language_id INT UNSIGNED DEFAULT NULL, type_of_act_id INT UNSIGNED DEFAULT NULL, css LONGTEXT DEFAULT NULL, css_metadata LONGTEXT DEFAULT NULL, html LONGTEXT DEFAULT NULL, html_metadata LONGTEXT DEFAULT NULL, assets LONGTEXT DEFAULT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, INDEX IDX_299F60E9979B1AD6 (company_id), INDEX IDX_299F60E9F92F3E70 (country_id), INDEX IDX_299F60E982F1BAF4 (language_id), INDEX IDX_299F60E9726BD122 (type_of_act_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE custom_variable_agency (id INT UNSIGNED AUTO_INCREMENT NOT NULL, agency_id INT UNSIGNED NOT NULL, custom_variable_id INT UNSIGNED NOT NULL, type VARCHAR(50) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, INDEX IDX_99539D8ECDEADB2A (agency_id), INDEX IDX_99539D8EC53FCB44 (custom_variable_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE custom_variable_translation ADD CONSTRAINT FK_71CEBF4C2C2AC5D3 FOREIGN KEY (translatable_id) REFERENCES custom_variable (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE custom_variable ADD CONSTRAINT FK_299F60E9979B1AD6 FOREIGN KEY (company_id) REFERENCES company (id)');
        $this->addSql('ALTER TABLE custom_variable ADD CONSTRAINT FK_299F60E9F92F3E70 FOREIGN KEY (country_id) REFERENCES country (id)');
        $this->addSql('ALTER TABLE custom_variable ADD CONSTRAINT FK_299F60E982F1BAF4 FOREIGN KEY (language_id) REFERENCES language (id)');
        $this->addSql('ALTER TABLE custom_variable ADD CONSTRAINT FK_299F60E9726BD122 FOREIGN KEY (type_of_act_id) REFERENCES type_of_act (id)');
        $this->addSql('ALTER TABLE custom_variable_agency ADD CONSTRAINT FK_99539D8ECDEADB2A FOREIGN KEY (agency_id) REFERENCES agency (id)');
        $this->addSql('ALTER TABLE custom_variable_agency ADD CONSTRAINT FK_99539D8EC53FCB44 FOREIGN KEY (custom_variable_id) REFERENCES custom_variable (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE custom_variable_translation DROP FOREIGN KEY FK_71CEBF4C2C2AC5D3');
        $this->addSql('ALTER TABLE custom_variable_agency DROP FOREIGN KEY FK_99539D8EC53FCB44');
        $this->addSql('DROP TABLE custom_variable_translation');
        $this->addSql('DROP TABLE custom_variable');
        $this->addSql('DROP TABLE custom_variable_agency');
    }
}
