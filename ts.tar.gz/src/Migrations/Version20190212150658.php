<?php

    declare(strict_types=1);

namespace App\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
     * Auto-generated Migration: Please modify to your needs!
     */
    final class Version20190212150658 extends AbstractMigration
    {
        public function up(Schema $schema): void
        {
            // this up() migration is auto-generated, please modify it to your needs
            $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

            $this->addSql('CREATE TABLE email_contract_event_link (id INT AUTO_INCREMENT NOT NULL, email_id INT UNSIGNED DEFAULT NULL, event_id INT UNSIGNED DEFAULT NULL, status_id INT UNSIGNED DEFAULT NULL, min_delay INT DEFAULT NULL, max_delay INT DEFAULT NULL, INDEX IDX_39956D04A832C1C9 (email_id), INDEX IDX_39956D0471F7E88B (event_id), INDEX IDX_39956D046BF700BD (status_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE email_sender (id INT UNSIGNED AUTO_INCREMENT NOT NULL, type_of_act_id INT UNSIGNED DEFAULT NULL, name VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, INDEX IDX_229A993F726BD122 (type_of_act_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE agency (id INT UNSIGNED AUTO_INCREMENT NOT NULL, group_agency_id INT UNSIGNED DEFAULT NULL, main_agency_id INT UNSIGNED DEFAULT NULL, erp_id BIGINT UNSIGNED NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, name VARCHAR(255) NOT NULL, INDEX IDX_70C0C6E6D5987CB (group_agency_id), INDEX IDX_70C0C6E6ED5C7C88 (main_agency_id), UNIQUE INDEX erp_identifier_idx (erp_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE document_translation (id INT AUTO_INCREMENT NOT NULL, translatable_id INT UNSIGNED DEFAULT NULL, name VARCHAR(255) NOT NULL, locale VARCHAR(255) NOT NULL, INDEX IDX_36C072052C2AC5D3 (translatable_id), UNIQUE INDEX document_translation_unique_translation (translatable_id, locale), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE company (id INT UNSIGNED AUTO_INCREMENT NOT NULL, erp_id BIGINT UNSIGNED NOT NULL, code VARCHAR(255) NOT NULL, name VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, UNIQUE INDEX erp_identifier_idx (erp_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE event_status (id INT UNSIGNED AUTO_INCREMENT NOT NULL, type_of_act_id INT UNSIGNED DEFAULT NULL, status VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, INDEX IDX_4999124E726BD122 (type_of_act_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE contract_option (id INT UNSIGNED AUTO_INCREMENT NOT NULL, type_of_act_id INT UNSIGNED NOT NULL, name VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, erp_id BIGINT UNSIGNED NOT NULL, INDEX IDX_66C6E5FD726BD122 (type_of_act_id), UNIQUE INDEX identifier_idx (erp_id, type_of_act_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE contract_package (id INT UNSIGNED AUTO_INCREMENT NOT NULL, type_of_act_id INT UNSIGNED NOT NULL, name VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, erp_id BIGINT UNSIGNED NOT NULL, INDEX IDX_D6391A5D726BD122 (type_of_act_id), UNIQUE INDEX identifier_idx (erp_id, type_of_act_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE document (id INT UNSIGNED AUTO_INCREMENT NOT NULL, child_id INT UNSIGNED DEFAULT NULL, parent_id INT UNSIGNED DEFAULT NULL, type_of_act_id INT UNSIGNED DEFAULT NULL, company_id INT UNSIGNED DEFAULT NULL, category_id BIGINT UNSIGNED DEFAULT NULL, language_id INT UNSIGNED DEFAULT NULL, country_id INT UNSIGNED DEFAULT NULL, css LONGTEXT DEFAULT NULL, css_metadata LONGTEXT DEFAULT NULL, html LONGTEXT DEFAULT NULL, html_metadata LONGTEXT DEFAULT NULL, assets LONGTEXT DEFAULT NULL, version INT NOT NULL, active TINYINT(1) NOT NULL, locked TINYINT(1) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, UNIQUE INDEX UNIQ_D8698A76DD62C21B (child_id), UNIQUE INDEX UNIQ_D8698A76727ACA70 (parent_id), INDEX IDX_D8698A76726BD122 (type_of_act_id), INDEX IDX_D8698A76979B1AD6 (company_id), INDEX IDX_D8698A7612469DE2 (category_id), INDEX IDX_D8698A7682F1BAF4 (language_id), INDEX IDX_D8698A76F92F3E70 (country_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE document_contract_package_link (document_id INT UNSIGNED NOT NULL, contract_package_id INT UNSIGNED NOT NULL, INDEX IDX_4E68D733C33F7837 (document_id), INDEX IDX_4E68D733ED0D0AD6 (contract_package_id), PRIMARY KEY(document_id, contract_package_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE email_test (id INT UNSIGNED AUTO_INCREMENT NOT NULL, email VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, UNIQUE INDEX UNIQ_47495E89E7927C74 (email), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE document_agency (id INT UNSIGNED AUTO_INCREMENT NOT NULL, agency_id INT UNSIGNED NOT NULL, document_id INT UNSIGNED NOT NULL, type VARCHAR(50) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, INDEX IDX_CEA27780CDEADB2A (agency_id), INDEX IDX_CEA27780C33F7837 (document_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE country (id INT UNSIGNED AUTO_INCREMENT NOT NULL, erp_id BIGINT UNSIGNED NOT NULL, code VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, UNIQUE INDEX erp_identifier_idx (erp_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE language (id INT UNSIGNED AUTO_INCREMENT NOT NULL, erp_id BIGINT UNSIGNED NOT NULL, code VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, UNIQUE INDEX erp_identifier_idx (erp_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE email_attachment (id INT UNSIGNED AUTO_INCREMENT NOT NULL, email_id INT UNSIGNED NOT NULL, size INT DEFAULT NULL, mime_type VARCHAR(255) DEFAULT NULL, original_name VARCHAR(255) DEFAULT NULL, file_name VARCHAR(255) DEFAULT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, INDEX IDX_D5EC2B64A832C1C9 (email_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE feature (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, description LONGTEXT DEFAULT NULL, code VARCHAR(255) DEFAULT \'\' NOT NULL, UNIQUE INDEX UNIQ_1FD775665E237E06 (name), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE contract_status (id INT UNSIGNED AUTO_INCREMENT NOT NULL, type_of_act_id INT UNSIGNED DEFAULT NULL, status VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, INDEX IDX_47408051726BD122 (type_of_act_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE email_contract_status_link (id INT AUTO_INCREMENT NOT NULL, email_id INT UNSIGNED DEFAULT NULL, status_id INT UNSIGNED DEFAULT NULL, min_delay INT DEFAULT NULL, max_delay INT DEFAULT NULL, INDEX IDX_8269BA2EA832C1C9 (email_id), INDEX IDX_8269BA2E6BF700BD (status_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE email_translation (id INT AUTO_INCREMENT NOT NULL, translatable_id INT UNSIGNED DEFAULT NULL, name VARCHAR(255) NOT NULL, locale VARCHAR(255) NOT NULL, INDEX IDX_A2A939D82C2AC5D3 (translatable_id), UNIQUE INDEX email_translation_unique_translation (translatable_id, locale), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE country_translation (id INT AUTO_INCREMENT NOT NULL, translatable_id INT UNSIGNED DEFAULT NULL, name VARCHAR(255) NOT NULL, locale VARCHAR(255) NOT NULL, INDEX IDX_A1FE6FA42C2AC5D3 (translatable_id), UNIQUE INDEX country_translation_unique_translation (translatable_id, locale), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE event_type (id INT UNSIGNED AUTO_INCREMENT NOT NULL, type_of_act_id INT UNSIGNED DEFAULT NULL, name VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, erp_id BIGINT UNSIGNED NOT NULL, INDEX IDX_93151B82726BD122 (type_of_act_id), UNIQUE INDEX identifier_idx (erp_id, type_of_act_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE contract_payment_status (id INT UNSIGNED AUTO_INCREMENT NOT NULL, type_of_act_id INT UNSIGNED DEFAULT NULL, status VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, INDEX IDX_D6B1FFED726BD122 (type_of_act_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE type_of_act (id INT UNSIGNED AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE email_agency (id INT UNSIGNED AUTO_INCREMENT NOT NULL, agency_id INT UNSIGNED NOT NULL, email_id INT UNSIGNED NOT NULL, type VARCHAR(50) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, INDEX IDX_D5A1516CDEADB2A (agency_id), INDEX IDX_D5A1516A832C1C9 (email_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE category_translation (id INT AUTO_INCREMENT NOT NULL, translatable_id BIGINT UNSIGNED DEFAULT NULL, name VARCHAR(255) NOT NULL, locale VARCHAR(255) NOT NULL, INDEX IDX_3F207042C2AC5D3 (translatable_id), UNIQUE INDEX category_translation_unique_translation (translatable_id, locale), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE category (id BIGINT UNSIGNED NOT NULL, code VARCHAR(255) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE user (id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL, first_name VARCHAR(255) DEFAULT NULL, last_name VARCHAR(255) DEFAULT NULL, enabled TINYINT(1) NOT NULL, locked TINYINT(1) NOT NULL, password VARCHAR(255) DEFAULT \'\' NOT NULL, expired TINYINT(1) NOT NULL, language VARCHAR(255) DEFAULT \'fr_FR\', username VARCHAR(255) NOT NULL, salt VARCHAR(255) DEFAULT NULL, roles LONGTEXT NOT NULL COMMENT \'(DC2Type:simple_array)\', fail_attempts INT NOT NULL, last_login DATETIME DEFAULT NULL, password_requested_at DATETIME DEFAULT NULL, confirmation_token VARCHAR(255) DEFAULT NULL, creation_date DATETIME DEFAULT NULL, last_update DATETIME DEFAULT NULL, UNIQUE INDEX UNIQ_8D93D649F85E0677 (username), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE user_feature_link (id_user BIGINT UNSIGNED NOT NULL, id_feature INT NOT NULL, INDEX IDX_E44A6A806B3CA4B (id_user), INDEX IDX_E44A6A80C14ADC16 (id_feature), PRIMARY KEY(id_user, id_feature)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE user_group_link (id_user BIGINT UNSIGNED NOT NULL, id_group INT NOT NULL, INDEX IDX_B891046D6B3CA4B (id_user), INDEX IDX_B891046D834505F5 (id_group), PRIMARY KEY(id_user, id_group)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE user_group (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, description LONGTEXT DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE group_feature_link (id_group INT NOT NULL, id_feature INT NOT NULL, INDEX IDX_88C05CBB834505F5 (id_group), INDEX IDX_88C05CBBC14ADC16 (id_feature), PRIMARY KEY(id_group, id_feature)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE email (id INT UNSIGNED AUTO_INCREMENT NOT NULL, sender_id INT UNSIGNED DEFAULT NULL, child_id INT UNSIGNED DEFAULT NULL, parent_id INT UNSIGNED DEFAULT NULL, type_of_act_id INT UNSIGNED DEFAULT NULL, company_id INT UNSIGNED DEFAULT NULL, category_id BIGINT UNSIGNED DEFAULT NULL, language_id INT UNSIGNED DEFAULT NULL, country_id INT UNSIGNED DEFAULT NULL, subject VARCHAR(255) NOT NULL, manual TINYINT(1) NOT NULL, automatic TINYINT(1) NOT NULL, scheduled TINYINT(1) NOT NULL, css LONGTEXT DEFAULT NULL, css_metadata LONGTEXT DEFAULT NULL, html LONGTEXT DEFAULT NULL, html_metadata LONGTEXT DEFAULT NULL, assets LONGTEXT DEFAULT NULL, version INT NOT NULL, active TINYINT(1) NOT NULL, locked TINYINT(1) NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, INDEX IDX_E7927C74F624B39D (sender_id), UNIQUE INDEX UNIQ_E7927C74DD62C21B (child_id), UNIQUE INDEX UNIQ_E7927C74727ACA70 (parent_id), INDEX IDX_E7927C74726BD122 (type_of_act_id), INDEX IDX_E7927C74979B1AD6 (company_id), INDEX IDX_E7927C7412469DE2 (category_id), INDEX IDX_E7927C7482F1BAF4 (language_id), INDEX IDX_E7927C74F92F3E70 (country_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE email_test_link (email_id INT UNSIGNED NOT NULL, email_test_id INT UNSIGNED NOT NULL, INDEX IDX_3CDE2C15A832C1C9 (email_id), INDEX IDX_3CDE2C15A39D6C96 (email_test_id), PRIMARY KEY(email_id, email_test_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE email_contract_package_link (email_id INT UNSIGNED NOT NULL, contract_package_id INT UNSIGNED NOT NULL, INDEX IDX_6C63A7AFA832C1C9 (email_id), INDEX IDX_6C63A7AFED0D0AD6 (contract_package_id), PRIMARY KEY(email_id, contract_package_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('CREATE TABLE email_contract_payment_status_link (email_id INT UNSIGNED NOT NULL, contract_payment_status_id INT UNSIGNED NOT NULL, INDEX IDX_B7929A22A832C1C9 (email_id), INDEX IDX_B7929A22E839F87D (contract_payment_status_id), PRIMARY KEY(email_id, contract_payment_status_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
            $this->addSql('ALTER TABLE email_contract_event_link ADD CONSTRAINT FK_39956D04A832C1C9 FOREIGN KEY (email_id) REFERENCES email (id)');
            $this->addSql('ALTER TABLE email_contract_event_link ADD CONSTRAINT FK_39956D0471F7E88B FOREIGN KEY (event_id) REFERENCES event_type (id)');
            $this->addSql('ALTER TABLE email_contract_event_link ADD CONSTRAINT FK_39956D046BF700BD FOREIGN KEY (status_id) REFERENCES event_status (id)');
            $this->addSql('ALTER TABLE email_sender ADD CONSTRAINT FK_229A993F726BD122 FOREIGN KEY (type_of_act_id) REFERENCES type_of_act (id)');
            $this->addSql('ALTER TABLE agency ADD CONSTRAINT FK_70C0C6E6D5987CB FOREIGN KEY (group_agency_id) REFERENCES agency (id)');
            $this->addSql('ALTER TABLE agency ADD CONSTRAINT FK_70C0C6E6ED5C7C88 FOREIGN KEY (main_agency_id) REFERENCES agency (id)');
            $this->addSql('ALTER TABLE document_translation ADD CONSTRAINT FK_36C072052C2AC5D3 FOREIGN KEY (translatable_id) REFERENCES document (id) ON DELETE CASCADE');
            $this->addSql('ALTER TABLE event_status ADD CONSTRAINT FK_4999124E726BD122 FOREIGN KEY (type_of_act_id) REFERENCES type_of_act (id)');
            $this->addSql('ALTER TABLE contract_option ADD CONSTRAINT FK_66C6E5FD726BD122 FOREIGN KEY (type_of_act_id) REFERENCES type_of_act (id)');
            $this->addSql('ALTER TABLE contract_package ADD CONSTRAINT FK_D6391A5D726BD122 FOREIGN KEY (type_of_act_id) REFERENCES type_of_act (id)');
            $this->addSql('ALTER TABLE document ADD CONSTRAINT FK_D8698A76DD62C21B FOREIGN KEY (child_id) REFERENCES document (id)');
            $this->addSql('ALTER TABLE document ADD CONSTRAINT FK_D8698A76727ACA70 FOREIGN KEY (parent_id) REFERENCES document (id) ON DELETE SET NULL');
            $this->addSql('ALTER TABLE document ADD CONSTRAINT FK_D8698A76726BD122 FOREIGN KEY (type_of_act_id) REFERENCES type_of_act (id)');
            $this->addSql('ALTER TABLE document ADD CONSTRAINT FK_D8698A76979B1AD6 FOREIGN KEY (company_id) REFERENCES company (id)');
            $this->addSql('ALTER TABLE document ADD CONSTRAINT FK_D8698A7612469DE2 FOREIGN KEY (category_id) REFERENCES category (id)');
            $this->addSql('ALTER TABLE document ADD CONSTRAINT FK_D8698A7682F1BAF4 FOREIGN KEY (language_id) REFERENCES language (id)');
            $this->addSql('ALTER TABLE document ADD CONSTRAINT FK_D8698A76F92F3E70 FOREIGN KEY (country_id) REFERENCES country (id)');
            $this->addSql('ALTER TABLE document_contract_package_link ADD CONSTRAINT FK_4E68D733C33F7837 FOREIGN KEY (document_id) REFERENCES document (id) ON DELETE CASCADE');
            $this->addSql('ALTER TABLE document_contract_package_link ADD CONSTRAINT FK_4E68D733ED0D0AD6 FOREIGN KEY (contract_package_id) REFERENCES contract_package (id) ON DELETE CASCADE');
            $this->addSql('ALTER TABLE document_agency ADD CONSTRAINT FK_CEA27780CDEADB2A FOREIGN KEY (agency_id) REFERENCES agency (id)');
            $this->addSql('ALTER TABLE document_agency ADD CONSTRAINT FK_CEA27780C33F7837 FOREIGN KEY (document_id) REFERENCES document (id)');
            $this->addSql('ALTER TABLE email_attachment ADD CONSTRAINT FK_D5EC2B64A832C1C9 FOREIGN KEY (email_id) REFERENCES email (id)');
            $this->addSql('ALTER TABLE contract_status ADD CONSTRAINT FK_47408051726BD122 FOREIGN KEY (type_of_act_id) REFERENCES type_of_act (id)');
            $this->addSql('ALTER TABLE email_contract_status_link ADD CONSTRAINT FK_8269BA2EA832C1C9 FOREIGN KEY (email_id) REFERENCES email (id)');
            $this->addSql('ALTER TABLE email_contract_status_link ADD CONSTRAINT FK_8269BA2E6BF700BD FOREIGN KEY (status_id) REFERENCES contract_status (id)');
            $this->addSql('ALTER TABLE email_translation ADD CONSTRAINT FK_A2A939D82C2AC5D3 FOREIGN KEY (translatable_id) REFERENCES email (id) ON DELETE CASCADE');
            $this->addSql('ALTER TABLE country_translation ADD CONSTRAINT FK_A1FE6FA42C2AC5D3 FOREIGN KEY (translatable_id) REFERENCES country (id) ON DELETE CASCADE');
            $this->addSql('ALTER TABLE event_type ADD CONSTRAINT FK_93151B82726BD122 FOREIGN KEY (type_of_act_id) REFERENCES type_of_act (id)');
            $this->addSql('ALTER TABLE contract_payment_status ADD CONSTRAINT FK_D6B1FFED726BD122 FOREIGN KEY (type_of_act_id) REFERENCES type_of_act (id)');
            $this->addSql('ALTER TABLE email_agency ADD CONSTRAINT FK_D5A1516CDEADB2A FOREIGN KEY (agency_id) REFERENCES agency (id)');
            $this->addSql('ALTER TABLE email_agency ADD CONSTRAINT FK_D5A1516A832C1C9 FOREIGN KEY (email_id) REFERENCES email (id)');
            $this->addSql('ALTER TABLE category_translation ADD CONSTRAINT FK_3F207042C2AC5D3 FOREIGN KEY (translatable_id) REFERENCES category (id) ON DELETE CASCADE');
            $this->addSql('ALTER TABLE user_feature_link ADD CONSTRAINT FK_E44A6A806B3CA4B FOREIGN KEY (id_user) REFERENCES user (id)');
            $this->addSql('ALTER TABLE user_feature_link ADD CONSTRAINT FK_E44A6A80C14ADC16 FOREIGN KEY (id_feature) REFERENCES feature (id)');
            $this->addSql('ALTER TABLE user_group_link ADD CONSTRAINT FK_B891046D6B3CA4B FOREIGN KEY (id_user) REFERENCES user (id)');
            $this->addSql('ALTER TABLE user_group_link ADD CONSTRAINT FK_B891046D834505F5 FOREIGN KEY (id_group) REFERENCES user_group (id)');
            $this->addSql('ALTER TABLE group_feature_link ADD CONSTRAINT FK_88C05CBB834505F5 FOREIGN KEY (id_group) REFERENCES user_group (id)');
            $this->addSql('ALTER TABLE group_feature_link ADD CONSTRAINT FK_88C05CBBC14ADC16 FOREIGN KEY (id_feature) REFERENCES feature (id)');
            $this->addSql('ALTER TABLE email ADD CONSTRAINT FK_E7927C74F624B39D FOREIGN KEY (sender_id) REFERENCES email_sender (id)');
            $this->addSql('ALTER TABLE email ADD CONSTRAINT FK_E7927C74DD62C21B FOREIGN KEY (child_id) REFERENCES email (id)');
            $this->addSql('ALTER TABLE email ADD CONSTRAINT FK_E7927C74727ACA70 FOREIGN KEY (parent_id) REFERENCES email (id) ON DELETE SET NULL');
            $this->addSql('ALTER TABLE email ADD CONSTRAINT FK_E7927C74726BD122 FOREIGN KEY (type_of_act_id) REFERENCES type_of_act (id)');
            $this->addSql('ALTER TABLE email ADD CONSTRAINT FK_E7927C74979B1AD6 FOREIGN KEY (company_id) REFERENCES company (id)');
            $this->addSql('ALTER TABLE email ADD CONSTRAINT FK_E7927C7412469DE2 FOREIGN KEY (category_id) REFERENCES category (id)');
            $this->addSql('ALTER TABLE email ADD CONSTRAINT FK_E7927C7482F1BAF4 FOREIGN KEY (language_id) REFERENCES language (id)');
            $this->addSql('ALTER TABLE email ADD CONSTRAINT FK_E7927C74F92F3E70 FOREIGN KEY (country_id) REFERENCES country (id)');
            $this->addSql('ALTER TABLE email_test_link ADD CONSTRAINT FK_3CDE2C15A832C1C9 FOREIGN KEY (email_id) REFERENCES email (id) ON DELETE CASCADE');
            $this->addSql('ALTER TABLE email_test_link ADD CONSTRAINT FK_3CDE2C15A39D6C96 FOREIGN KEY (email_test_id) REFERENCES email_test (id) ON DELETE CASCADE');
            $this->addSql('ALTER TABLE email_contract_package_link ADD CONSTRAINT FK_6C63A7AFA832C1C9 FOREIGN KEY (email_id) REFERENCES email (id) ON DELETE CASCADE');
            $this->addSql('ALTER TABLE email_contract_package_link ADD CONSTRAINT FK_6C63A7AFED0D0AD6 FOREIGN KEY (contract_package_id) REFERENCES contract_package (id) ON DELETE CASCADE');
            $this->addSql('ALTER TABLE email_contract_payment_status_link ADD CONSTRAINT FK_B7929A22A832C1C9 FOREIGN KEY (email_id) REFERENCES email (id) ON DELETE CASCADE');
            $this->addSql('ALTER TABLE email_contract_payment_status_link ADD CONSTRAINT FK_B7929A22E839F87D FOREIGN KEY (contract_payment_status_id) REFERENCES contract_payment_status (id) ON DELETE CASCADE');
        }

        public function down(Schema $schema): void
        {
            // this down() migration is auto-generated, please modify it to your needs
            $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

            $this->addSql('ALTER TABLE email DROP FOREIGN KEY FK_E7927C74F624B39D');
            $this->addSql('ALTER TABLE agency DROP FOREIGN KEY FK_70C0C6E6D5987CB');
            $this->addSql('ALTER TABLE agency DROP FOREIGN KEY FK_70C0C6E6ED5C7C88');
            $this->addSql('ALTER TABLE document_agency DROP FOREIGN KEY FK_CEA27780CDEADB2A');
            $this->addSql('ALTER TABLE email_agency DROP FOREIGN KEY FK_D5A1516CDEADB2A');
            $this->addSql('ALTER TABLE document DROP FOREIGN KEY FK_D8698A76979B1AD6');
            $this->addSql('ALTER TABLE email DROP FOREIGN KEY FK_E7927C74979B1AD6');
            $this->addSql('ALTER TABLE email_contract_event_link DROP FOREIGN KEY FK_39956D046BF700BD');
            $this->addSql('ALTER TABLE document_contract_package_link DROP FOREIGN KEY FK_4E68D733ED0D0AD6');
            $this->addSql('ALTER TABLE email_contract_package_link DROP FOREIGN KEY FK_6C63A7AFED0D0AD6');
            $this->addSql('ALTER TABLE document_translation DROP FOREIGN KEY FK_36C072052C2AC5D3');
            $this->addSql('ALTER TABLE document DROP FOREIGN KEY FK_D8698A76DD62C21B');
            $this->addSql('ALTER TABLE document DROP FOREIGN KEY FK_D8698A76727ACA70');
            $this->addSql('ALTER TABLE document_contract_package_link DROP FOREIGN KEY FK_4E68D733C33F7837');
            $this->addSql('ALTER TABLE document_agency DROP FOREIGN KEY FK_CEA27780C33F7837');
            $this->addSql('ALTER TABLE email_test_link DROP FOREIGN KEY FK_3CDE2C15A39D6C96');
            $this->addSql('ALTER TABLE document DROP FOREIGN KEY FK_D8698A76F92F3E70');
            $this->addSql('ALTER TABLE country_translation DROP FOREIGN KEY FK_A1FE6FA42C2AC5D3');
            $this->addSql('ALTER TABLE email DROP FOREIGN KEY FK_E7927C74F92F3E70');
            $this->addSql('ALTER TABLE document DROP FOREIGN KEY FK_D8698A7682F1BAF4');
            $this->addSql('ALTER TABLE email DROP FOREIGN KEY FK_E7927C7482F1BAF4');
            $this->addSql('ALTER TABLE user_feature_link DROP FOREIGN KEY FK_E44A6A80C14ADC16');
            $this->addSql('ALTER TABLE group_feature_link DROP FOREIGN KEY FK_88C05CBBC14ADC16');
            $this->addSql('ALTER TABLE email_contract_status_link DROP FOREIGN KEY FK_8269BA2E6BF700BD');
            $this->addSql('ALTER TABLE email_contract_event_link DROP FOREIGN KEY FK_39956D0471F7E88B');
            $this->addSql('ALTER TABLE email_contract_payment_status_link DROP FOREIGN KEY FK_B7929A22E839F87D');
            $this->addSql('ALTER TABLE email_sender DROP FOREIGN KEY FK_229A993F726BD122');
            $this->addSql('ALTER TABLE event_status DROP FOREIGN KEY FK_4999124E726BD122');
            $this->addSql('ALTER TABLE contract_option DROP FOREIGN KEY FK_66C6E5FD726BD122');
            $this->addSql('ALTER TABLE contract_package DROP FOREIGN KEY FK_D6391A5D726BD122');
            $this->addSql('ALTER TABLE document DROP FOREIGN KEY FK_D8698A76726BD122');
            $this->addSql('ALTER TABLE contract_status DROP FOREIGN KEY FK_47408051726BD122');
            $this->addSql('ALTER TABLE event_type DROP FOREIGN KEY FK_93151B82726BD122');
            $this->addSql('ALTER TABLE contract_payment_status DROP FOREIGN KEY FK_D6B1FFED726BD122');
            $this->addSql('ALTER TABLE email DROP FOREIGN KEY FK_E7927C74726BD122');
            $this->addSql('ALTER TABLE document DROP FOREIGN KEY FK_D8698A7612469DE2');
            $this->addSql('ALTER TABLE category_translation DROP FOREIGN KEY FK_3F207042C2AC5D3');
            $this->addSql('ALTER TABLE email DROP FOREIGN KEY FK_E7927C7412469DE2');
            $this->addSql('ALTER TABLE user_feature_link DROP FOREIGN KEY FK_E44A6A806B3CA4B');
            $this->addSql('ALTER TABLE user_group_link DROP FOREIGN KEY FK_B891046D6B3CA4B');
            $this->addSql('ALTER TABLE user_group_link DROP FOREIGN KEY FK_B891046D834505F5');
            $this->addSql('ALTER TABLE group_feature_link DROP FOREIGN KEY FK_88C05CBB834505F5');
            $this->addSql('ALTER TABLE email_contract_event_link DROP FOREIGN KEY FK_39956D04A832C1C9');
            $this->addSql('ALTER TABLE email_attachment DROP FOREIGN KEY FK_D5EC2B64A832C1C9');
            $this->addSql('ALTER TABLE email_contract_status_link DROP FOREIGN KEY FK_8269BA2EA832C1C9');
            $this->addSql('ALTER TABLE email_translation DROP FOREIGN KEY FK_A2A939D82C2AC5D3');
            $this->addSql('ALTER TABLE email_agency DROP FOREIGN KEY FK_D5A1516A832C1C9');
            $this->addSql('ALTER TABLE email DROP FOREIGN KEY FK_E7927C74DD62C21B');
            $this->addSql('ALTER TABLE email DROP FOREIGN KEY FK_E7927C74727ACA70');
            $this->addSql('ALTER TABLE email_test_link DROP FOREIGN KEY FK_3CDE2C15A832C1C9');
            $this->addSql('ALTER TABLE email_contract_package_link DROP FOREIGN KEY FK_6C63A7AFA832C1C9');
            $this->addSql('ALTER TABLE email_contract_payment_status_link DROP FOREIGN KEY FK_B7929A22A832C1C9');
            $this->addSql('DROP TABLE email_contract_event_link');
            $this->addSql('DROP TABLE email_sender');
            $this->addSql('DROP TABLE agency');
            $this->addSql('DROP TABLE document_translation');
            $this->addSql('DROP TABLE company');
            $this->addSql('DROP TABLE event_status');
            $this->addSql('DROP TABLE contract_option');
            $this->addSql('DROP TABLE contract_package');
            $this->addSql('DROP TABLE document');
            $this->addSql('DROP TABLE document_contract_package_link');
            $this->addSql('DROP TABLE email_test');
            $this->addSql('DROP TABLE document_agency');
            $this->addSql('DROP TABLE country');
            $this->addSql('DROP TABLE language');
            $this->addSql('DROP TABLE email_attachment');
            $this->addSql('DROP TABLE feature');
            $this->addSql('DROP TABLE contract_status');
            $this->addSql('DROP TABLE email_contract_status_link');
            $this->addSql('DROP TABLE email_translation');
            $this->addSql('DROP TABLE country_translation');
            $this->addSql('DROP TABLE event_type');
            $this->addSql('DROP TABLE contract_payment_status');
            $this->addSql('DROP TABLE type_of_act');
            $this->addSql('DROP TABLE email_agency');
            $this->addSql('DROP TABLE category_translation');
            $this->addSql('DROP TABLE category');
            $this->addSql('DROP TABLE user');
            $this->addSql('DROP TABLE user_feature_link');
            $this->addSql('DROP TABLE user_group_link');
            $this->addSql('DROP TABLE user_group');
            $this->addSql('DROP TABLE group_feature_link');
            $this->addSql('DROP TABLE email');
            $this->addSql('DROP TABLE email_test_link');
            $this->addSql('DROP TABLE email_contract_package_link');
            $this->addSql('DROP TABLE email_contract_payment_status_link');
        }
    }
