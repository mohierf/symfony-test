<?php

declare(strict_types=1);

namespace App\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190612152354 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE custom_variable_agency_family (custom_variable_id INT UNSIGNED NOT NULL, agency_family_id INT UNSIGNED NOT NULL, INDEX IDX_9AFF49DFC53FCB44 (custom_variable_id), INDEX IDX_9AFF49DFE92D679F (agency_family_id), PRIMARY KEY(custom_variable_id, agency_family_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE agency_family (id INT UNSIGNED AUTO_INCREMENT NOT NULL, erp_id BIGINT UNSIGNED NOT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, name VARCHAR(255) NOT NULL, UNIQUE INDEX erp_identifier_idx (erp_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE custom_variable_agency_family ADD CONSTRAINT FK_9AFF49DFC53FCB44 FOREIGN KEY (custom_variable_id) REFERENCES custom_variable (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE custom_variable_agency_family ADD CONSTRAINT FK_9AFF49DFE92D679F FOREIGN KEY (agency_family_id) REFERENCES agency_family (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE agency ADD family_id INT UNSIGNED DEFAULT NULL');
        $this->addSql('ALTER TABLE agency ADD CONSTRAINT FK_70C0C6E6C35E566A FOREIGN KEY (family_id) REFERENCES agency_family (id)');
        $this->addSql('CREATE INDEX IDX_70C0C6E6C35E566A ON agency (family_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE custom_variable_agency_family DROP FOREIGN KEY FK_9AFF49DFE92D679F');
        $this->addSql('ALTER TABLE agency DROP FOREIGN KEY FK_70C0C6E6C35E566A');
        $this->addSql('DROP TABLE custom_variable_agency_family');
        $this->addSql('DROP TABLE agency_family');
        $this->addSql('DROP INDEX IDX_70C0C6E6C35E566A ON agency');
        $this->addSql('ALTER TABLE agency DROP family_id');
    }
}
