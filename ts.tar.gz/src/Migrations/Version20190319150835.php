<?php

declare(strict_types=1);

namespace App\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190319150835 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE email_scheduled_report (id INT UNSIGNED AUTO_INCREMENT NOT NULL, email_id INT UNSIGNED NOT NULL, started_at DATETIME DEFAULT NULL, finished_at DATETIME DEFAULT NULL, status VARCHAR(255) NOT NULL, total_page_todo INT UNSIGNED DEFAULT NULL, total_page_success INT UNSIGNED DEFAULT NULL, total_page_error INT UNSIGNED DEFAULT NULL, total_items_todo INT UNSIGNED DEFAULT NULL, total_items_success INT UNSIGNED DEFAULT NULL, total_items_error INT UNSIGNED DEFAULT NULL, creation DATETIME NOT NULL, last_update DATETIME NOT NULL, INDEX IDX_66E81B2AA832C1C9 (email_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE email_scheduled_report ADD CONSTRAINT FK_66E81B2AA832C1C9 FOREIGN KEY (email_id) REFERENCES email (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('DROP TABLE email_scheduled_report');
    }
}
