<?php

declare(strict_types=1);

namespace App\Migrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190306082934 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE email ADD uuid CHAR(36) NOT NULL COMMENT \'(DC2Type:uuid)\'');
        $this->addSql('UPDATE email SET uuid = UUID()');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_E7927C74D17F50A6 ON email (uuid)');
        $this->addSql('ALTER TABLE document ADD uuid CHAR(36) NOT NULL COMMENT \'(DC2Type:uuid)\'');
        $this->addSql('UPDATE document SET uuid = UUID()');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_D8698A76D17F50A6 ON document (uuid)');
        $this->addSql('ALTER TABLE invoice ADD uuid CHAR(36) NOT NULL COMMENT \'(DC2Type:uuid)\'');
        $this->addSql('UPDATE invoice SET uuid = UUID()');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_90651744D17F50A6 ON invoice (uuid)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf('mysql' !== $this->connection->getDatabasePlatform()->getName(), 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('DROP INDEX UNIQ_D8698A76D17F50A6 ON document');
        $this->addSql('ALTER TABLE document DROP uuid');
        $this->addSql('DROP INDEX UNIQ_E7927C74D17F50A6 ON email');
        $this->addSql('ALTER TABLE email DROP uuid');
        $this->addSql('DROP INDEX UNIQ_90651744D17F50A6 ON invoice');
        $this->addSql('ALTER TABLE invoice DROP uuid');
    }
}
