<?php

namespace App\Controller;

use App\Entity\JsonSchema;
use App\Entity\Template;
use App\Model\GlobalContext;
use App\Repository\JsonSchemaRepository;
use App\Repository\TemplateRepository;
use App\Services\TemplateService;
use ReflectionException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/placeholder")
 */
class PlaceholderController extends AbstractController
{
    /**
     * @var TemplateService
     */
    private $templateService;

    /**
     * PlaceholderController constructor.
     *
     * @param TemplateService $templateService
     */
    public function __construct(TemplateService $templateService)
    {
        $this->templateService = $templateService;
    }

    /**
     * @Route("/translated-list/", name="translated-placeholders-list", options={"expose"=true}, methods="GET")
     *
     * @param Request            $request
     * @param TemplateRepository $templateRepository
     *
     * @return JsonResponse
     *
     * @throws ReflectionException
     */
    public function getTranslatedPlaceholders(Request $request, TemplateRepository $templateRepository): JsonResponse
    {
        $param = $request->get('context');

        if ('template' === $param && $templateId = $request->get('templateId')) {
            /** @var Template $template */
            $param = $templateRepository->find($templateId);
        }

        return new JsonResponse($this->templateService->getTranslatedPlaceholders($param));
    }

    /**
     * @Route("/", name="placeholder_index", options={"expose"=true}, methods="GET")
     *
     * @param JsonSchemaRepository $jsonSchemaRepository
     *
     * @return Response
     *
     * @throws ReflectionException
     */
    public function index(JsonSchemaRepository $jsonSchemaRepository): Response
    {
        $placeholdersList = [];
        foreach (TemplateService::CONTEXT_CLASS as $context => $contextClass) {
            /* @var GlobalContext $contextClass */
            $placeholdersList[$context] = $contextClass::getSpecificConstants();
        }

        $jsonSchemas = $jsonSchemaRepository->findAll();

        /** @var JsonSchema $schema */
        foreach ($jsonSchemas as $schema) {
            $template = (new Template())->setJsonSchema($schema);
            $placeholdersList[$schema->getName().' (schema)'] = array_diff(
                $this->templateService->getPlaceholdersByTemplate($template),
                GlobalContext::getSpecificConstants()
            );
        }

        return $this->render('placeholder/index.html.twig', ['list' => $placeholdersList]);
    }
}
