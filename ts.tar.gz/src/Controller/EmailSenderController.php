<?php

namespace App\Controller;

use App\Entity\EmailSender;
use App\Form\EmailSenderType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/email-sender")
 */
class EmailSenderController extends AbstractController
{
    /**
     * @Route("/", name="email_sender_index", methods="GET")
     */
    public function index(): Response
    {
        $emailSenders = $this->getDoctrine()
            ->getRepository(EmailSender::class)
            ->findAll();

        return $this->render('email_sender/index.html.twig', ['email_senders' => $emailSenders]);
    }

    /**
     * @Route("/new", name="email_sender_new", methods="GET|POST")
     */
    public function new(Request $request): Response
    {
        $emailSender = new EmailSender();
        $form = $this->createForm(EmailSenderType::class, $emailSender);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($emailSender);
            $em->flush();

            return $this->redirectToRoute('email_sender_index');
        }

        return $this->render('email_sender/new.html.twig', [
            'email_sender' => $emailSender,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="email_sender_show", methods="GET")
     */
    public function show(EmailSender $emailSender): Response
    {
        return $this->render('email_sender/show.html.twig', ['email_sender' => $emailSender]);
    }

    /**
     * @Route("/{id}/edit", name="email_sender_edit", methods="GET|POST")
     */
    public function edit(Request $request, EmailSender $emailSender): Response
    {
        $form = $this->createForm(EmailSenderType::class, $emailSender);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('email_sender_index', ['id' => $emailSender->getId()]);
        }

        return $this->render('email_sender/edit.html.twig', [
            'email_sender' => $emailSender,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="email_sender_delete", methods="DELETE")
     */
    public function delete(Request $request, EmailSender $emailSender): Response
    {
        if ($this->isCsrfTokenValid('delete'.$emailSender->getId(), $request->request->get('_token'))) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($emailSender);
            $em->flush();
        }

        return $this->redirectToRoute('email_sender_index');
    }
}
