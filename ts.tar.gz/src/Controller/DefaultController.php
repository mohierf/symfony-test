<?php

namespace App\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Sfk\ErpClientBundle\Services\ClientRegistryInterface;
use Sfk\ErpClientBundle\Services\ClientRegistryTrait;
use Sfk\StandardBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class DefaultController.
 */
class DefaultController extends AbstractController implements ClientRegistryInterface
{
    use ClientRegistryTrait;

    /**
     * @Route("/", name="homepage")
     *
     * @return array
     * @Template("default/index.html.twig")
     */
    public function indexAction(): array
    {
        // a simple notification
        $this->addFlash('success', 'test notification');

        return [];
    }

    /**
     * @param $section
     *
     * @return array
     */
    public function _topMenuAction($section): array
    {
        return [
            'section' => $section,
        ];
    }

    /**
     * @param string $route
     *
     * @return Response
     */
    public function _leftMenuAction(string $route): Response
    {
        $menu = [
            [
                'heading' => 'Administration',
                'items' => [
                    'users' => [
                        'id' => 'users',
                        'subnav' => 'Users',
                        'icon' => 'icon-user',
                        'class' => '',
                        'items' => [],
                    ],
                    'parameters' => [
                        'id' => 'parameters',
                        'subnav' => 'Paramétrage',
                        'icon' => 'icon-wrench',
                        'class' => '',
                        'items' => [],
                    ],
                    'tools' => [
                        'id' => 'tools',
                        'subnav' => 'Outils',
                        'icon' => 'icon-compass',
                        'class' => '',
                        'items' => [],
                    ],
                ],
            ],
        ];

        $menuUsers = &$menu[0]['items']['users']['items'];
        $menuParameters = &$menu[0]['items']['parameters']['items'];
        $toolsParameters = &$menu[0]['items']['tools']['items'];

        if ($this->isGranted('ROLE_ADMIN')) {
            $menuUsers = [
                'users' => [
                    'label' => 'Utilisateurs',
                    'route' => 'admin_user_list',
                    'class' => false !== strpos($route, 'admin_user_') ? 'active' : '',
                ],
                'groups' => [
                    'label' => 'Groupes',
                    'route' => 'admin_group_list',
                    'class' => false !== strpos($route, 'admin_group_') ? 'active' : '',
                ],
            ];

            $menuParameters = [
                'type_of_acts' => [
                    'label' => 'Types d\'actes',
                    'route' => 'type_of_act_index',
                    'class' => false !== strpos($route, 'type_of_act_') ? 'active' : '',
                ],
                'template_categories' => [
                    'label' => 'Catégories de template',
                    'route' => 'template_category_index',
                    'class' => false !== strpos($route, 'template_category_') ? 'active' : '',
                ],
                'json_schema' => [
                    'label' => 'Schémas JSON',
                    'route' => 'json_schema_index',
                    'class' => false !== strpos($route, 'json_schema_') ? 'active' : '',
                ],
            ];
        }

        if ($this->isGranted('FEATURE_DOCUMENT')) {
            $menuParameters['documents'] = [
                'label' => 'Documents',
                'route' => 'document_index',
                'class' => false !== strpos($route, 'document') ? 'active' : '',
            ];
        }

        if ($this->isGranted('FEATURE_EMAIL')) {
            $menuParameters['emails'] = [
                'label' => 'Emails',
                'route' => 'email_index',
                'class' => false !== strpos($route, 'email_') ? 'active' : '',
            ];
            $menuParameters['emails_test'] = [
                'label' => 'Emails test',
                'route' => 'email_test_index',
                'class' => false !== strpos($route, 'email_test_') ? 'active' : '',
            ];
            $menuParameters['emails_sender'] = [
                'label' => 'Emails sender',
                'route' => 'email_sender_index',
                'class' => false !== strpos($route, 'email_sender_') ? 'active' : '',
            ];
        }

        if ($this->isGranted('FEATURE_TEMPLATE')) {
            $menuParameters['templates'] = [
                'label' => 'Templates génériques',
                'route' => 'template_index',
                'class' => false !== strpos($route, 'template') ? 'active' : '',
            ];
        }

        if ($this->isGranted('FEATURE_DOCUMENT') || $this->isGranted('FEATURE_EMAIL')) {
            $menuParameters['placeholders'] = [
                'label' => 'Placeholders',
                'route' => 'placeholder_index',
                'class' => false !== strpos($route, 'placeholder_') ? 'active' : '',
            ];
        }

        if ($this->isGranted('FEATURE_DOCUMENT') || $this->isGranted('FEATURE_EMAIL')) {
            $menuParameters['custom_variables'] = [
                'label' => 'Custom variables',
                'route' => 'custom_variable_index',
                'class' => false !== strpos($route, 'custom_variable_') ? 'active' : '',
            ];
        }

        if ($this->isGranted('ROLE_ADMIN')) {
            $toolsParameters = [
                'Templates matching a contract' => [
                    'label' => 'Templates/contract',
                    'route' => 'email_which_template_match_contract',
                    'class' => false !== strpos($route, 'tools_') ? 'active' : '',
                ],
            ];
        }

        return $this->render(
            '_leftMenu.html.twig',
            [
                'menu' => $menu,
            ]
        );
    }

    /**
     * @Route("/_fragementFooter/{section}", name="footer")
     *
     * @param $section
     *
     * @return array
     * @Template("_footer.html.twig")
     */
    public function _footerAction($section): array
    {
        return [
            'section' => $section,
        ];
    }
}
