<?php

namespace App\Controller;

use App\Entity\EmailTest;
use App\Form\EmailTestType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;

/**
 * @Route("/email-test")
 * @Security("is_granted('FEATURE_EMAIL')")
 */
class EmailTestController extends AbstractController
{
    /**
     * @return Response
     *
     * @Route("/", name="email_test_index", methods="GET")
     */
    public function index(): Response
    {
        $emailTests = $this->getDoctrine()
            ->getRepository(EmailTest::class)
            ->findAll();

        return $this->render('email_test/index.html.twig', ['email_tests' => $emailTests]);
    }

    /**
     * @param Request $request
     *
     * @return Response
     *
     * @Route("/new", name="email_test_new", methods="GET|POST")
     */
    public function new(Request $request): Response
    {
        $emailTest = new EmailTest();
        $form = $this->createForm(EmailTestType::class, $emailTest);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($emailTest);
            $em->flush();

            return $this->redirectToRoute('email_test_index');
        }

        return $this->render('email_test/new.html.twig', [
            'email_test' => $emailTest,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @param EmailTest $emailTest
     *
     * @return Response
     *
     * @Route("/{id}", name="email_test_show", methods="GET")
     */
    public function show(EmailTest $emailTest): Response
    {
        return $this->render('email_test/show.html.twig', ['email_test' => $emailTest]);
    }

    /**
     * @param Request   $request
     * @param EmailTest $emailTest
     *
     * @return Response
     *
     * @Route("/{id}/edit", name="email_test_edit", methods="GET|POST")
     */
    public function edit(Request $request, EmailTest $emailTest): Response
    {
        $form = $this->createForm(EmailTestType::class, $emailTest);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('email_test_index', ['id' => $emailTest->getId()]);
        }

        return $this->render('email_test/edit.html.twig', [
            'email_test' => $emailTest,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @param Request   $request
     * @param EmailTest $emailTest
     *
     * @return Response
     *
     * @Route("/{id}", name="email_test_delete", methods="DELETE")
     */
    public function delete(Request $request, EmailTest $emailTest): Response
    {
        if ($this->isCsrfTokenValid('delete'.$emailTest->getId(), $request->request->get('_token'))) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($emailTest);
            $em->flush();
        }

        return $this->redirectToRoute('email_test_index');
    }
}
