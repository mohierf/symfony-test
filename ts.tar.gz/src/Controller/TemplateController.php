<?php

namespace App\Controller;

use App\Entity\Template;
use App\Form\TemplateType;
use App\Repository\TemplateRepository;
use App\Services\CustomVariableService;
use App\Services\HtmlToPdfClient;
use App\Services\TemplateService;
use Exception;
use Psr\Log\LoggerInterface;
use Ramsey\Uuid\Uuid;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Sfk\ErpClientBundle\Services\ClientRegistryTrait;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Throwable;

/**
 * @Route("/template")
 * @Security("is_granted('FEATURE_TEMPLATE')")
 */
class TemplateController extends Controller
{
    use ClientRegistryTrait;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * @var CustomVariableService
     */
    private $customVariableService;

    /**
     * TemplateController constructor.
     *
     * @param LoggerInterface       $logger
     * @param CustomVariableService $customVariableService
     */
    public function __construct(LoggerInterface $logger, CustomVariableService $customVariableService)
    {
        $this->logger = $logger;
        $this->customVariableService = $customVariableService;
    }

    /**
     * @Route("/new-version/{id}", name="template_new_version")
     *
     * @param Request  $request
     * @param Template $template
     *
     * @return Response
     *
     * @throws Exception
     */
    public function createNewVersion(Request $request, Template $template): Response
    {
        return $this->edit($request, $template->createNewVersion());
    }

    /**
     * @Route("/{id}/edit", name="template_edit", methods="GET|POST")
     *
     * @param Request  $request
     * @param Template $template
     *
     * @return Response
     *
     * @throws Exception
     */
    public function edit(Request $request, Template $template): Response
    {
        $form = $this->createForm(
            TemplateType::class,
            $template,
            [
                'object_id' => $template->getId(),
            ]
        );
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();

            /** @var Template $template */
            $template = $form->getData();

            $em->persist($template);
            $em->flush();

            $this->addFlash('success', 'Template saved');

            return $this->redirectToRoute('template_edit', ['id' => $template->getId()]);
        }

        $params = [
            'object' => $template,
            'form' => $form->createView(),
            'customVariables' => $this->customVariableService->getCustomVariablesByTemplate($template),
        ];

        if (!$template->getId()) {
            $params['temporaryTemplateId'] = Uuid::uuid4();
            $params['copy'] = 1;
        }

        return $this->render('template/edit.html.twig', $params);
    }

    /**
     * @Route("/{id}", name="template_delete", methods="DELETE")
     *
     * @param Request  $request
     * @param Template $template
     *
     * @return Response
     */
    public function delete(Request $request, Template $template): Response
    {
        if ($this->isCsrfTokenValid('delete'.$template->getId(), $request->request->get('_token'))) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($template);
            $em->flush();
            $this->addFlash('success', 'Template deleted');
        }

        return $this->redirectToRoute('template_index');
    }

    /**
     * @Route("/", name="template_index", methods="GET")
     *
     * @param TemplateRepository $templateRepository
     *
     * @return Response
     */
    public function index(TemplateRepository $templateRepository): Response
    {
        return $this->render(
            'template/index.html.twig',
            [
                'objects' => $templateRepository->findAll(),
            ]
        );
    }

    /**
     * @Route("/new", name="template_new", methods="GET|POST")
     *
     * @param Request $request
     *
     * @return Response
     *
     * @throws Exception
     */
    public function new(Request $request): Response
    {
        $template = new Template();
        $form = $this->createForm(TemplateType::class, $template);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($template);
            $em->flush();

            $this->addFlash('success', 'Template created');

            return $this->redirectToRoute('template_edit', ['id' => $template->getId()]);
        }

        return $this->render(
            'template/new.html.twig',
            [
                'object' => $template,
                'form' => $form->createView(),
                'temporaryTemplateId' => Uuid::uuid4(),
                'customVariables' => $this->customVariableService->getCustomVariablesByTemplate($template),
            ]
        );
    }

    /**
     * @Route("/show/{id}", name="template_show", methods="GET")
     *
     * @param Template $template
     *
     * @return Response
     */
    public function show(Template $template): Response
    {
        return $this->render('template/show.html.twig', ['object' => $template]);
    }

    /**
     * @Route("/pdf-preview/{id}", name="template_pdf_preview", methods="POST")
     *
     * @param Template        $template
     * @param TemplateService $templateService
     * @param HtmlToPdfClient $htmlToPdfClient
     * @param Request         $request
     *
     * @return Response
     *
     * @throws Throwable
     */
    public function pdfPreview(Template $template, TemplateService $templateService, HtmlToPdfClient $htmlToPdfClient, Request $request): ?Response
    {
        $jsonData = $request->get('jsonData');
        $data = json_decode($jsonData, true);

        try {
            $context = $templateService->getContextData($template, $data);
            $html = $templateService->render($template, TemplateService::TEMPLATE_MODE_RAW, $context);
            // @TODO Change the name of the file
            $filename = 'template-'.date('YmdHis').'.pdf';
            $response = $htmlToPdfClient->convert($html, $filename);

            return new Response($response->getBody(), $response->getStatusCode(), $response->getHeaders());
        } catch (Exception $e) {
            $this->logger->error(
                'The PDF file could not be generated',
                [
                    'exception' => $e,
                ]
            );

            return new Response($e->getMessage(), $e->getCode());
        }
    }

    /**
     * @Route("/html-preview/{id}", name="template_html_preview", methods="POST")
     *
     * @param Template        $template
     * @param TemplateService $templateService
     * @param Request         $request
     *
     * @return Response
     *
     * @throws Throwable
     */
    public function htmlPreview(Template $template, TemplateService $templateService, Request $request): Response
    {
        $jsonData = $request->get('jsonData');
        $data = json_decode($jsonData, true);

        try {
            $context = $templateService->getContextData($template, $data);
            $render = $templateService->render($template, TemplateService::TEMPLATE_MODE_PREVIEW, $context);
        } catch (Exception $e) {
            $this->logger->error(
                'HTML preview has failed',
                [
                    'exception' => $e,
                ]
            );

            return new Response($e->getMessage(), $e->getCode());
        }

        return new Response($render);
    }
}
