<?php

namespace App\Controller;

use App\Entity\Email;
use App\Entity\EmailTest;
use App\Entity\TypeOfAct;
use App\Form\EmailType;
use App\Repository\EmailRepository;
use App\Services\CriteriaBuilderService;
use App\Services\CustomVariableService;
use App\Services\ErpServiceClient;
use App\Services\MailRouterClient;
use App\Services\TemplateService;
use ErrorException;
use Exception;
use GuzzleHttp\Exception\ClientException;
use Psr\Log\LoggerInterface;
use Ramsey\Uuid\Uuid;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Sfk\ErpClientBundle\Services\ClientRegistryTrait;
use Sfk\Lib\ErpClient\ApiException;
use Sfk\Lib\ErpClient\Model\InsuranceContractRead;
use Sfk\Lib\ErpClient\Model\PrivilegeContractRead;
use Sfk\Lib\ErpClient\Model\WebsiteContractRead;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Error\SyntaxError;

/**
 * @Route("/email")
 * @Security("is_granted('FEATURE_EMAIL')")
 */
class EmailController extends Controller
{
    use ClientRegistryTrait;

    /**
     * @var LoggerInterface
     */
    private $logger;

    /**
     * EmailController constructor.
     *
     * @param LoggerInterface $logger
     */
    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    /**
     * @Route("/new-version/{id}", name="email_new_version")
     *
     * @param Request $request
     * @param Email   $email
     *
     * @return Response
     *
     * @throws Exception
     */
    public function createNewVersion(Request $request, Email $email): Response
    {
        return $this->edit($request, $email->createNewVersion());
    }

    /**
     * @Route("/{id}/edit", name="email_edit", methods="GET|POST")
     *
     * @param Request               $request
     * @param Email                 $email
     * @param CustomVariableService $customVariableService
     *
     * @return Response
     *
     * @throws Exception
     */
    public function edit(Request $request, Email $email, CustomVariableService $customVariableService): Response
    {
        $form = $this->createForm(
            EmailType::class,
            $email,
            [
                'object_id' => $email->getId(),
            ]
        );
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();

            /** @var Email $email */
            $email = $form->getData();

            $em->persist($email);
            $em->flush();

            $this->addFlash('success', 'Email saved');

            return $this->redirectToRoute('email_edit', ['id' => $email->getId()]);
        }

        $params = [
            'object' => $email,
            'form' => $form->createView(),
            'customVariables' => $customVariableService->getCustomVariablesByTemplate($email),
        ];

        if (!$email->getId()) {
            $params['temporaryTemplateId'] = Uuid::uuid4();
            $params['copy'] = 1;
        }

        return $this->render('email/edit.html.twig', $params);
    }

    /**
     * @Route("/{id}", name="email_delete", methods="DELETE")
     *
     * @param Request $request
     * @param Email   $email
     *
     * @return Response
     */
    public function delete(Request $request, Email $email): Response
    {
        if ($this->isCsrfTokenValid('delete'.$email->getId(), $request->request->get('_token'))) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($email);
            $em->flush();
            $this->addFlash('success', 'Email deleted');
        }

        return $this->redirectToRoute('email_index');
    }

    /**
     * @Route("/", name="email_index", methods="GET")
     *
     * @param EmailRepository $emailRepository
     *
     * @return Response
     */
    public function index(EmailRepository $emailRepository): Response
    {
        return $this->render(
            'email/index.html.twig',
            [
                'objects' => $emailRepository->findAll(),
                'typesOfAct' => $this->getDoctrine()->getRepository(TypeOfAct::class)->findAll(),
            ]
        );
    }

    /**
     * @Route("/new/{id}", name="email_new", methods="GET|POST")
     *
     * @param Request               $request
     * @param TypeOfAct             $typeOfAct
     * @param CustomVariableService $customVariableService
     *
     * @return Response
     *
     * @throws Exception
     */
    public function new(Request $request, TypeOfAct $typeOfAct, CustomVariableService $customVariableService): Response
    {
        $email = new Email();
        $email->setTypeOfAct($typeOfAct);
        $form = $this->createForm(EmailType::class, $email);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($email);
            $em->flush();
            $this->addFlash('success', 'Email created');

            return $this->redirectToRoute('email_edit', ['id' => $email->getId()]);
        }

        return $this->render(
            'email/new.html.twig',
            [
                'object' => $email,
                'form' => $form->createView(),
                'temporaryTemplateId' => Uuid::uuid4(),
                'customVariables' => $customVariableService->getCustomVariablesByTemplate($email),
            ]
        );
    }

    /**
     * @Route("/show/{id}", name="email_show", methods="GET")
     *
     * @param Email $email
     *
     * @return Response
     */
    public function show(Email $email): Response
    {
        return $this->render('email/show.html.twig', ['object' => $email]);
    }

    /**
     * @Route("/render/{id}", name="email_render", methods="GET")
     *
     * @param Email           $email
     * @param TemplateService $templateService
     * @param Request         $request
     *
     * @return Response
     *
     * @throws LoaderError
     * @throws RuntimeError
     * @throws SyntaxError
     * @throws Exception
     */
    public function getRenderedEmail(Email $email, TemplateService $templateService, Request $request): Response
    {
        $contractId = $request->get('contract');

        try {
            $context = $templateService->getContextData($email, $contractId);
            $render = $templateService->render($email, TemplateService::TEMPLATE_MODE_PREVIEW, $context);
        } catch (ApiException $exception) {
            return new Response($exception->getMessage(), $exception->getCode());
        }

        return new Response($render);
    }

    /**
     * @Route("/send/{id}", name="email_send", methods="GET")
     *
     * @param Email           $email
     * @param TemplateService $templateService
     * @param Request         $request
     *
     * @return string|Response
     *
     * @throws LoaderError
     * @throws SyntaxError
     */
    public function send(Email $email, TemplateService $templateService, Request $request)
    {
        $contractId = $request->get('contract');

        try {
            // TODO : Use the Email Message Builder
            $contract = $templateService->getContextData($email, $contractId);
            $data['subject'] = $templateService->renderSubject($email, $contract);
            $data['content'] = $templateService->renderContent($email, $contract);
            $data['companyCode'] = $email->getCompany()->getCode();
            $data['senderEmail'] = $email->getSender()->getEmail();
            /** @var EmailTest $recipient */
            foreach ($email->getTestEmails() as $recipient) {
                $data['recipients'][$recipient->getId()] = $recipient->getEmail();
            }

            $client = $this->get(MailRouterClient::class);
            try {
                $client->sendEmail($data);
                $this->addFlash('success', 'Email successfully sent');
            } catch (ClientException $e) {
                $this->addFlash('danger', 'Error when sending the email');
                $this->logger->error(
                    'Error when sending the email',
                    [
                        'exception' => $e,
                    ]
                );
            }
        } catch (ApiException $e) {
            $this->addFlash('danger', sprintf('No %s contract found with the ID %s', $email->getTypeOfAct()->getName(), $contractId));
            $this->logger->error(
                sprintf('No %s contract found with the ID %s', $email->getTypeOfAct()->getName(), $contractId),
                [
                    'exception' => $e,
                ]
            );
        }

        return $this->redirectToRoute('email_edit', ['id' => $email->getId()]);
    }

    /**
     * @Route("/search_criteria/{id}", name="email_search_criteria", methods="GET")
     *
     * @param Email                  $email
     * @param CriteriaBuilderService $criteriaBuilder
     *
     * @return Response
     *
     * @throws Exception
     */
    public function extractRules(Email $email, CriteriaBuilderService $criteriaBuilder): Response
    {
        $rules = $criteriaBuilder->getRules($email);

        return $this->render('email/rules.html.twig', ['object' => $email, 'rules' => $rules]);
    }

    /**
     * For testing purpose.
     *
     * @Route("/which-templates-match-this-contract", name="email_which_template_match_contract", methods="GET|POST")
     *
     * @param Request          $request
     * @param EmailRepository  $emailRepository
     * @param ErpServiceClient $erpServiceClient
     *
     * @return Response
     *
     * @throws Exception
     */
    public function templatesMatchingAContract(Request $request, EmailRepository $emailRepository, ErpServiceClient $erpServiceClient): Response
    {
        $defaultData = [
            'id_contract' => '',
            'type_of_act' => 'insurance',
            'type' => 'insert',
        ];

        $form = $this->createFormBuilder($defaultData)
            ->add('id_contract', TextType::class)
            ->add(
                'type_of_act',
                EntityType::class,
                [
                    'class' => TypeOfAct::class,
                    'choice_value' => 'name',
                ]
            )
            ->add('type', ChoiceType::class, ['choices' => ['insert' => 'insert', 'update' => 'update']])
            ->add('search', SubmitType::class)
            ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $data = $form->getData();
            $contractId = $data['id_contract'];
            $typeOfAct = $data['type_of_act'];
            $type = $data['type'];
            $category = 'insert' === $type ? 'SIGN' : null;

            $client = $erpServiceClient->getErpClient();
            $matchingTemplates = [];
            $otherTemplates = [];

            try {
                switch ($typeOfAct) {
                    case TypeOfAct::INSURANCE:
                        $contract = $client->getInsuranceContractApi()->getInsuranceContractItem(['id' => $contractId]);
                        break;
                    case TypeOfAct::PRIVILEGE:
                        $contract = $client->getPrivilegeContractApi()->getPrivilegeContractItem(['id' => $contractId]);
                        break;
                    case TypeOfAct::WEBSITE:
                        $contract = $client->getWebsiteContractApi()->getWebsiteContractItem(['id' => $contractId]);
                        break;
                    default:
                        $contract = null;
                }
            } catch (ApiException | ErrorException $e) {
                $this->addFlash('danger', 'Contract n°'.$contractId.' not found.');

                return $this->render(
                    'email/emails_matching_contract.html.twig',
                    [
                        'form' => $form->createView(),
                    ]
                );
            }

            $allTemplates = $emailRepository->findAll();

            foreach ($emailRepository->findMatchingTemplates($contract, $typeOfAct, $category) as $template) {
                /* @var InsuranceContractRead|PrivilegeContractRead|WebsiteContractRead $template */
                $matchingTemplates[$template->getId()] = $template;
            }

            foreach ($allTemplates as $key => $template) {
                /** @var InsuranceContractRead|PrivilegeContractRead|WebsiteContractRead|Email $template */
                /** @var TypeOfAct $typeOfAct */
                if (!array_key_exists($template->getId(), $matchingTemplates) && $template->getTypeOfAct()->getName() === $typeOfAct->getName()) {
                    $otherTemplates[$key] = $template;
                }
            }

            return $this->render('email/emails_matching_contract.html.twig', ['form' => $form->createView(), 'matchingTemplates' => $matchingTemplates, 'otherTemplates' => $otherTemplates, 'contract' => $contract, 'type' => $type, 'category' => $category, 'typeOfAct' => $typeOfAct]);
        }

        return $this->render(
            'email/emails_matching_contract.html.twig',
            [
                'form' => $form->createView(),
            ]
        );
    }
}
