<?php

namespace App\Controller;

use App\Entity\TemplateCategory;
use App\Form\TemplateCategoryType;
use App\Repository\TemplateCategoryRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/template-category")
 * @Security("is_granted('ROLE_ADMIN')")
 */
class TemplateCategoryController extends AbstractController
{
    /**
     * @Route("/{id}", name="template_category_delete", methods="DELETE")
     *
     * @param Request          $request
     * @param TemplateCategory $templateCategory
     *
     * @return Response
     */
    public function delete(Request $request, TemplateCategory $templateCategory): Response
    {
        if ($this->isCsrfTokenValid('delete'.$templateCategory->getId(), $request->request->get('_token'))) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($templateCategory);
            $em->flush();
        }

        return $this->redirectToRoute('template_category_index');
    }

    /**
     * @Route("/{id}/edit", name="template_category_edit", methods="GET|POST")
     *
     * @param Request          $request
     * @param TemplateCategory $templateCategory
     *
     * @return Response
     */
    public function edit(Request $request, TemplateCategory $templateCategory): Response
    {
        $form = $this->createForm(TemplateCategoryType::class, $templateCategory);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('template_category_index', ['id' => $templateCategory->getId()]);
        }

        return $this->render(
            'template_category/edit.html.twig',
            [
                'template_category' => $templateCategory,
                'form' => $form->createView(),
            ]
        );
    }

    /**
     * @Route("/", name="template_category_index", methods="GET")
     *
     * @param TemplateCategoryRepository $templateCategoryRepository
     *
     * @return Response
     */
    public function index(TemplateCategoryRepository $templateCategoryRepository): Response
    {
        return $this->render('template_category/index.html.twig', ['template_categories' => $templateCategoryRepository->findAll()]);
    }

    /**
     * @Route("/new", name="template_category_new", methods="GET|POST")
     *
     * @param Request $request
     *
     * @return Response
     */
    public function new(Request $request): Response
    {
        $templateCategory = new TemplateCategory();
        $form = $this->createForm(TemplateCategoryType::class, $templateCategory);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($templateCategory);
            $em->flush();

            return $this->redirectToRoute('template_category_index');
        }

        return $this->render(
            'template_category/new.html.twig',
            [
                'template_category' => $templateCategory,
                'form' => $form->createView(),
            ]
        );
    }

    /**
     * @Route("/{id}", name="template_category_show", methods="GET")
     *
     * @param TemplateCategory $templateCategory
     *
     * @return Response
     */
    public function show(TemplateCategory $templateCategory): Response
    {
        return $this->render('template_category/show.html.twig', ['template_category' => $templateCategory]);
    }
}
