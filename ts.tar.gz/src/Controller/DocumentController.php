<?php

namespace App\Controller;

use App\Entity\Document;
use App\Form\DocumentType;
use App\Repository\DocumentRepository;
use App\Services\CustomVariableService;
use Ramsey\Uuid\Uuid;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Twig\Environment;

/**
 * @Route("/document")
 * @Security("is_granted('FEATURE_DOCUMENT')")
 */
class DocumentController extends AbstractController
{
    /**
     * @var CustomVariableService
     */
    private $customVariableService;

    /**
     * DocumentController constructor.
     *
     * @param CustomVariableService $customVariableService
     */
    public function __construct(CustomVariableService $customVariableService)
    {
        $this->customVariableService = $customVariableService;
    }

    /**
     * @Route("/new-version/{id}", name="document_new_version")
     *
     * @param Request  $request
     * @param Document $document
     *
     * @return Response
     *
     * @throws \Exception
     */
    public function createNewVersion(Request $request, Document $document): Response
    {
        return $this->edit($request, $document->createNewVersion());
    }

    /**
     * @Route("/{id}/edit", name="document_edit", methods="GET|POST")
     *
     * @param Request  $request
     * @param Document $document
     *
     * @return Response
     *
     * @throws \Exception
     */
    public function edit(Request $request, Document $document): Response
    {
        $form = $this->createForm(DocumentType::class, $document, [
            'object_id' => $document->getId(),
        ]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $document = $form->getData();
            $em->persist($document);
            $em->flush();

            $this->addFlash('success', 'Document saved');

            return $this->redirectToRoute('document_edit', ['id' => $document->getId()]);
        }

        $params = [
            'object' => $document,
            'form' => $form->createView(),
            'customVariables' => $this->customVariableService->getCustomVariablesByTemplate($document),
        ];

        if (!$document->getId()) {
            $params['temporaryTemplateId'] = Uuid::uuid4();
            $params['copy'] = 1;
        }

        return $this->render('document/edit.html.twig', $params);
    }

    /**
     * @Route("/{id}", name="document_delete", methods="DELETE")
     *
     * @param Request  $request
     * @param Document $document
     *
     * @return Response
     */
    public function delete(Request $request, Document $document): Response
    {
        if ($this->isCsrfTokenValid('delete'.$document->getId(), $request->request->get('_token'))) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($document);
            $em->flush();
        }

        return $this->redirectToRoute('document_index');
    }

    /**
     * @Route("/", name="document_index", methods="GET")
     *
     * @param DocumentRepository $documentRepository
     *
     * @return Response
     */
    public function index(DocumentRepository $documentRepository): Response
    {
        return $this->render('document/index.html.twig', ['objects' => $documentRepository->findAll()]);
    }

    /**
     * @Route("/new", name="document_new", methods="GET|POST")
     *
     * @param Request $request
     *
     * @return Response
     *
     * @throws \Exception
     */
    public function new(Request $request): Response
    {
        $document = new Document();
        $form = $this->createForm(DocumentType::class, $document);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($document);
            $em->flush();

            return $this->redirectToRoute('document_edit', ['id' => $document->getId()]);
        }

        return $this->render('document/new.html.twig', [
            'object' => $document,
            'form' => $form->createView(),
            'temporaryTemplateId' => Uuid::uuid4(),
            'customVariables' => $this->customVariableService->getCustomVariablesByTemplate($document),
        ]);
    }

    /**
     * @Route("/preview/{id}", name="document_preview", methods="GET")
     *
     * @param Document    $document
     * @param Environment $twig
     *
     * @return Response
     *
     * @throws \Twig\Error\LoaderError
     * @throws \Twig\Error\SyntaxError
     */
    public function preview(Document $document, Environment $twig): Response
    {
        $context = $this->getDoctrine()->getRepository('App:Placeholder')->findFields();
        $source = '<html><head></head><body><style>'.$document->getCss().'</style>'.$document->getHtml().'</body></html>';
        $render = $twig->createTemplate($source)->render($context);

        return new Response($render, 200);
    }

    /**
     * @Route("/{id}", name="document_show", methods="GET")
     *
     * @param Document $document
     *
     * @return Response
     */
    public function show(Document $document): Response
    {
        return $this->render('document/show.html.twig', ['object' => $document]);
    }
}
