<?php

namespace App\Controller;

use App\Entity\TypeOfAct;
use App\Form\TypeOfActType;
use App\Repository\TypeOfActRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/type-of-act")
 * @Security("is_granted('ROLE_ADMIN')")
 */
class TypeOfActController extends AbstractController
{
    /**
     * @Route("/{id}", name="type_of_act_delete", methods="DELETE")
     *
     * @param Request   $request
     * @param TypeOfAct $typeOfAct
     *
     * @return Response
     */
    public function delete(Request $request, TypeOfAct $typeOfAct): Response
    {
        if ($this->isCsrfTokenValid('delete'.$typeOfAct->getId(), $request->request->get('_token'))) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($typeOfAct);
            $em->flush();
        }

        return $this->redirectToRoute('type_of_act_index');
    }

    /**
     * @Route("/{id}/edit", name="type_of_act_edit", methods="GET|POST")
     *
     * @param Request   $request
     * @param TypeOfAct $typeOfAct
     *
     * @return Response
     */
    public function edit(Request $request, TypeOfAct $typeOfAct): Response
    {
        $form = $this->createForm(TypeOfActType::class, $typeOfAct);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('type_of_act_index', ['id' => $typeOfAct->getId()]);
        }

        return $this->render('type_of_act/edit.html.twig', [
            'type_of_act' => $typeOfAct,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/", name="type_of_act_index", methods="GET")
     *
     * @param TypeOfActRepository $typeOfActRepository
     *
     * @return Response
     */
    public function index(TypeOfActRepository $typeOfActRepository): Response
    {
        return $this->render('type_of_act/index.html.twig', ['type_of_acts' => $typeOfActRepository->findAll()]);
    }

    /**
     * @Route("/new", name="type_of_act_new", methods="GET|POST")
     *
     * @param Request $request
     *
     * @return Response
     */
    public function new(Request $request): Response
    {
        $typeOfAct = new TypeOfAct();
        $form = $this->createForm(TypeOfActType::class, $typeOfAct);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($typeOfAct);
            $em->flush();

            return $this->redirectToRoute('type_of_act_index');
        }

        return $this->render('type_of_act/new.html.twig', [
            'type_of_act' => $typeOfAct,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="type_of_act_show", methods="GET")
     *
     * @param TypeOfAct $typeOfAct
     *
     * @return Response
     */
    public function show(TypeOfAct $typeOfAct): Response
    {
        return $this->render('type_of_act/show.html.twig', ['type_of_act' => $typeOfAct]);
    }
}
