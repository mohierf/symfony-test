<?php

namespace App\Controller;

use App\Entity\CustomVariable;
use App\Entity\TemplateInterface;
use App\Form\CustomVariableType;
use App\Repository\CustomVariableRepository;
use App\Services\CustomVariableService;
use Ramsey\Uuid\Uuid;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Sfk\ErpClientBundle\Services\ClientRegistryTrait;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class CustomVariableController.
 *
 * @Route("/custom-variable")
 * @Security("is_granted('FEATURE_EMAIL')")
 */
class CustomVariableController extends Controller
{
    use ClientRegistryTrait;

    /**
     * @Route("/{id}/edit", name="custom_variable_edit", methods="GET|POST")
     *
     * @param Request               $request
     * @param CustomVariable        $customVariable
     * @param CustomVariableService $customVariableService
     *
     * @return Response
     */
    public function edit(Request $request, CustomVariable $customVariable, CustomVariableService $customVariableService): Response
    {
        $form = $this->createForm(
            CustomVariableType::class,
            $customVariable,
            [
                'object_id' => $customVariable->getId(),
            ]
        );
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            /** @var CustomVariable $customVariable */
            $customVariable = $form->getData();
            $em->persist($customVariable);
            $em->flush();

            $this->addFlash('success', 'Custom variable saved');

            return $this->redirectToRoute('custom_variable_edit', ['id' => $customVariable->getId()]);
        }

        $params = [
            'object' => $customVariable,
            'form' => $form->createView(),
            'templates' => $customVariableService->getTemplatesByCustomVariable($customVariable),
        ];

        return $this->render('custom_variable/edit.html.twig', $params);
    }

    /**
     * @Route("/{id}", name="custom_variable_delete", methods="DELETE")
     *
     * @param Request        $request
     * @param CustomVariable $customVariable
     *
     * @return Response
     */
    public function delete(Request $request, CustomVariable $customVariable): Response
    {
        if ($this->isCsrfTokenValid('delete'.$customVariable->getId(), $request->request->get('_token'))) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($customVariable);
            $em->flush();
            $this->addFlash('success', 'Custom variable deleted');
        }

        return $this->redirectToRoute('custom_variable_index');
    }

    /**
     * @Route("/", name="custom_variable_index", methods="GET")
     *
     * @param CustomVariableRepository $customVariableRepository
     *
     * @return Response
     */
    public function index(CustomVariableRepository $customVariableRepository): Response
    {
        return $this->render(
            'custom_variable/index.html.twig',
            [
                'objects' => $customVariableRepository->findAll(),
            ]
        );
    }

    /**
     * @Route("/new", name="custom_variable_new", methods="GET|POST")
     *
     * @param Request               $request
     * @param CustomVariableService $customVariableService
     *
     * @return Response
     *
     * @throws \Exception
     */
    public function new(Request $request, CustomVariableService $customVariableService): Response
    {
        $customVariable = new CustomVariable();
        $form = $this->createForm(CustomVariableType::class, $customVariable);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($customVariable);
            $em->flush();
            $this->addFlash('success', 'Custom variable created');

            return $this->redirectToRoute('custom_variable_edit', ['id' => $customVariable->getId()]);
        }

        return $this->render(
            'custom_variable/new.html.twig',
            [
                'object' => $customVariable,
                'form' => $form->createView(),
                'temporaryTemplateId' => Uuid::uuid4(),
                'templates' => $customVariableService->getTemplatesByCustomVariable($customVariable),
            ]
        );
    }

    /**
     * @Route("/translated-list", name="translated-custom-variables-list", options={"expose"=true}, methods="GET")
     *
     * @param Request               $request
     * @param CustomVariableService $customVariableService
     *
     * @return JsonResponse
     */
    public function getTranslatedCustomVariables(Request $request, CustomVariableService $customVariableService): JsonResponse
    {
        $return = [];

        if (($id = $request->get('id')) && ($type = strtolower($request->get('type'))) && in_array($type, TemplateInterface::TEMPLATE_TYPES, true)) {
            /** @var TemplateInterface $template */
            $template = $this->getDoctrine()->getRepository('App:'.ucfirst($type))->find($id);

            $return = $customVariableService->getCustomVariablesNamesIndexedByDisplayName($template);
        }

        return new JsonResponse($return);
    }

    /**
     * @Route("/display-list", name="display-custom-variables-list", options={"expose"=true}, methods="GET")
     *
     * @param Request               $request
     * @param CustomVariableService $customVariableService
     *
     * @return JsonResponse
     */
    public function getCustomVariablesDisplayNames(Request $request, CustomVariableService $customVariableService): JsonResponse
    {
        $return = [];

        if (($id = $request->get('id')) && ($type = strtolower($request->get('type'))) && in_array($type, TemplateInterface::TEMPLATE_TYPES, true)) {
            /** @var TemplateInterface $template */
            $template = $this->getDoctrine()->getRepository('App:'.ucfirst($type))->find($id);

            $return = $customVariableService->getCustomVariablesDisplayNamesIndexedByStoreName($template);
        }

        return new JsonResponse($return);
    }
}
