<?php

namespace App\Security;

use Symfony\Component\Security\Core\User\UserInterface;

class User implements UserInterface
{
    /**
     * @var array
     */
    private $roles;

    /**
     * @var string
     */
    private $password;

    /**
     * @var string
     */
    private $username;

    /**
     * {@inheritdoc}
     */
    public function getRoles()
    {
        return $this->roles;
    }

    /**
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * {@inheritdoc}
     */
    public function getSalt()
    {
        return null;
    }

    /**
     * {@inheritdoc}
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * {@inheritdoc}
     */
    public function eraseCredentials()
    {
    }

    /**
     * Define from associative array.
     *
     * @param array $row
     *
     * @return static
     */
    public static function fromRow(array $row)
    {
        $row += [
            'token' => null,
            'roles' => [],
        ];

        $user = new static();
        $user->password = $row['token'];
        $user->roles = $row['roles'];

        return $user;
    }

    /**
     * @param string $username
     *
     * @return static
     */
    public function setUsername(string $username)
    {
        $this->username = $username;

        return $this;
    }

    /**
     * Return a fake ID.
     *
     * @return string
     */
    public function getId()
    {
        return $this->username;
    }
}
