<?php

namespace App\Security;

use Symfony\Component\Filesystem\Exception\FileNotFoundException;
use Symfony\Component\Security\Core\Exception\UnsupportedUserException;
use Symfony\Component\Security\Core\Exception\UsernameNotFoundException;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Yaml\Yaml;

class YamlUserProvider implements UserProviderInterface
{
    /**
     * @var string
     */
    private $kernelRootDir;

    /**
     * @var string
     */
    private $usersFilePath;

    /**
     * UserProvider constructor.
     *
     * @param string $kernelRootDir
     * @param string $usersFilePath
     */
    public function __construct(string $kernelRootDir, string $usersFilePath)
    {
        $this->kernelRootDir = $kernelRootDir;
        $this->usersFilePath = $usersFilePath;
    }

    /**
     * {@inheritdoc}
     *
     * @throws \Exception
     */
    public function loadUserByUsername($token)
    {
        if ('' === $token) {
            throw new \Exception('missing credentials');
        }

        // absolute path ?
        if ('/' === $this->usersFilePath[0]) {
            $path = $this->usersFilePath;
        } // else, relative path
        else {
            $path = $this->kernelRootDir.'/../'.$this->usersFilePath;
        }

        // if file is missing, the service is not available => error 500
        if (!file_exists($path)) {
            throw new FileNotFoundException($path);
        }

        $conf = Yaml::parseFile($path);
        if (!isset($conf['users']) || !is_array($conf['users'])) {
            throw new \Exception('users key not found in config');
        }
        foreach ($conf['users'] as $username => $userRow) {
            if (isset($userRow['token']) && $token === $userRow['token']) {
                $user = User::fromRow($userRow);
                $user->setUsername($username);

                return $user;
            }
        }

        throw new UsernameNotFoundException('user not found by token');
    }

    /**
     * {@inheritdoc}
     */
    public function refreshUser(UserInterface $user)
    {
        if (!$user instanceof User) {
            throw new UnsupportedUserException(sprintf('Invalid user class "%s".', get_class($user)));
        }
    }

    /**
     * Tells Symfony to use this provider for this User class.
     */
    public function supportsClass($class)
    {
        return User::class === $class;
    }
}
