<?php

namespace App\Model;

/**
 * Class InsuranceContext.
 */
class InsuranceContext extends ActContext
{
    /**
     * @return array
     *
     * @throws \Exception
     */
    public function getContext(): array
    {
        return empty($this->getInsuranceContext()) ? parent::getContext() : array_merge(parent::getContext(), $this->getInsuranceContext());
    }

    /**
     * Get constants related to insurance contracts.
     *
     * @return array
     */
    public function getInsuranceContext(): array
    {
        $context = [];

        return $context;
    }
}
