<?php

namespace App\Model;

/**
 * Class PrivilegeContext.
 */
class PrivilegeContext extends ActContext
{
    /**
     * @return array
     *
     * @throws \Exception
     */
    public function getContext(): array
    {
        return empty($this->getPrivilegeContext()) ? parent::getContext() : array_merge(parent::getContext(), $this->getPrivilegeContext());
    }

    /**
     * Get constants related to privilege contracts.
     *
     * @return array
     */
    public function getPrivilegeContext(): array
    {
        $context = [];

        return $context;
    }
}
