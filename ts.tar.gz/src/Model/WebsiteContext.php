<?php

namespace App\Model;

/**
 * Class WebsiteContext.
 */
class WebsiteContext extends ActContext
{
    // @Todo Replace by real data
    public const WEBSITE_NAME = 'website_name';
    public const WEBSITE_DOMAIN_NAME = 'website_domain_name';
    public const WEBSITE_EMAIL = 'website_email';

    /**
     * @return array
     *
     * @throws \Exception
     */
    public function getContext(): array
    {
        return empty($this->getWebsiteContext()) ? parent::getContext() : array_merge(parent::getContext(), $this->getWebsiteContext());
    }

    /**
     * Get constants related to website contracts.
     *
     * @return array
     */
    public function getWebsiteContext(): array
    {
        // @Todo Replace by real data
        $context[self::WEBSITE_NAME] = 'My website';
        $context[self::WEBSITE_DOMAIN_NAME] = 'mywebsite.hubside.com';
        $context[self::WEBSITE_EMAIL] = 'test@hubside.com';

        return $context;
    }
}
