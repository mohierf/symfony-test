<?php

namespace App\Model;

/**
 * Class GlobalContext.
 *
 * Define constants shared by all templates
 */
class GlobalContext
{
    public const TIME_DATE = 'time_date';
    public const TIME_HOURS = 'time_hours';
    public const TIME_MINUTES = 'time_minutes';
    public const TIME_SECONDS = 'time_seconds';

    /**
     * GlobalContext constructor.
     */
    public function __construct()
    {
    }

    /**
     * Retrieve specific constants of a given context.
     *
     * @throws \ReflectionException
     */
    public static function getSpecificConstants(): array
    {
        $parentConstants = [];
        $parentClass = get_parent_class(static::class);

        if ($parentClass) {
            $reflectionParent = new \ReflectionClass($parentClass);
            $parentConstants = $reflectionParent->getConstants();
        }

        return array_diff(static::getConstants(), $parentConstants);
    }

    /**
     * Retrieve all constants of a given context.
     *
     * @throws \ReflectionException
     */
    public static function getConstants(): array
    {
        $reflection = new \ReflectionClass(static::class);
        $constants = $reflection->getConstants();

        // Exclude variables whose key ends with '_TABLE'. They are not usable in templates.
        $constantsKeysAllowed = array_filter(
            array_keys($constants),
            function ($name) {
                return !preg_match('/_TABLE$/', $name);
            }
        );

        return array_intersect_key($constants, array_flip($constantsKeysAllowed));
    }

    /**
     * Get global context constants.
     *
     * @return array
     *
     * @throws \Exception
     */
    public function getContext(): array
    {
        $date = new \DateTime();

        $context[self::TIME_DATE] = $date->format('d/m/Y');
        $context[self::TIME_HOURS] = $date->format('H');
        $context[self::TIME_MINUTES] = $date->format('i');
        $context[self::TIME_SECONDS] = $date->format('s');

        return $context;
    }
}
