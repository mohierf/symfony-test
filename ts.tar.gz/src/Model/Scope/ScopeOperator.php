<?php

namespace App\Model\Scope;

/**
 * Scope operators.
 */
class ScopeOperator
{
    public const AND_OPERATOR = 'AND';
    public const BETWEEN_OPERATOR = 'BETWEEN';
    public const EQUAL_OPERATOR = '=';
    public const GREATER_THAN_OPERATOR = '>';
    public const GREATER_THAN_EQUAL_OPERATOR = '>=';
    public const IN_OPERATOR = 'IN';
    public const IS_NOT_NULL_OPERATOR = 'IS NOT NULL';
    public const IS_NULL_OPERATOR = 'IS NULL';
    public const LIKE_OPERATOR = 'LIKE';
    public const LOWER_THAN_OPERATOR = '<';
    public const LOWER_THAN_EQUAL_OPERATOR = '<=';
    public const NOT_BETWEEN_OPERATOR = 'NOT BETWEEN';
    public const NOT_EQUAL_OPERATOR = '<>';
    public const NOT_IN_OPERATOR = 'NOT IN';
    public const NOT_LIKE_OPERATOR = 'NOT LIKE';
    public const OR_OPERATOR = 'OR';

    public const AND_FUNCTION = 'and';
    public const BETWEEN_FUNCTION = 'between';
    public const EQUAL_FUNCTION = 'eq';
    public const GREATER_THAN_FUNCTION = 'gt';
    public const GREATER_THAN_EQUAL_FUNCTION = 'gte';
    public const IN_FUNCTION = 'in';
    public const IS_NOT_NULL_FUNCTION = 'isNotNull';
    public const IS_NULL_FUNCTION = 'isNull';
    public const LIKE_FUNCTION = 'like';
    public const LOWER_THAN_FUNCTION = 'lt';
    public const LOWER_THAN_EQUAL_FUNCTION = 'lte';
    public const NOT_BETWEEN_FUNCTION = 'notBetween';
    public const NOT_EQUAL_FUNCTION = 'neq';
    public const NOT_IN_FUNCTION = 'notIn';
    public const NOT_LIKE_FUNCTION = 'notLike';
    public const OR_FUNCTION = 'or';

    public const TYPE_STRING = 'string';
    public const TYPE_INTEGER = 'integer';
    public const TYPE_DATETIME = 'datetime';

    /**
     * Return "formatted operation".
     *
     * @param string     $operator
     * @param array|null $values
     * @param null       $column
     *
     * @return array
     */
    public static function addOperator(string $operator, ?array $values, $column = null): array
    {
        $value_array = is_array($values) ? $values : [$values];

        switch (strtoupper(trim($operator))) {
            case self::AND_FUNCTION:
            case self::AND_OPERATOR:
                $op = self::and($value_array);
                break;
            case self::OR_FUNCTION:
            case self::OR_OPERATOR:
                $op = self::or($value_array);
                break;
            case self::LIKE_FUNCTION:
            case self::LIKE_OPERATOR:
                $op = self::like($column, $value_array[0]);
                break;
            case self::NOT_LIKE_FUNCTION:
            case self::NOT_LIKE_OPERATOR:
                $op = self::notLike($column, $value_array[0]);
                break;
            case self::EQUAL_FUNCTION:
            case self::EQUAL_OPERATOR:
                $op = self::eq($column, $value_array[0]);
                break;
            case self::NOT_EQUAL_FUNCTION:
            case self::NOT_EQUAL_OPERATOR:
                $op = self::neq($column, $value_array[0]);
                break;
            case self::GREATER_THAN_FUNCTION:
            case self::GREATER_THAN_OPERATOR:
                $op = self::gt($column, $value_array[0]);
                break;
            case self::GREATER_THAN_EQUAL_FUNCTION:
            case self::GREATER_THAN_EQUAL_OPERATOR:
                $op = self::gte($column, $value_array[0]);
                break;
            case self::LOWER_THAN_FUNCTION:
            case self::LOWER_THAN_OPERATOR:
                $op = self::lt($column, $value_array[0]);
                break;
            case self::LOWER_THAN_EQUAL_FUNCTION:
            case self::LOWER_THAN_EQUAL_OPERATOR:
                $op = self::lte($column, $value_array[0]);
                break;
            case self::IN_FUNCTION:
            case self::IN_OPERATOR:
                $op = self::in($column, $value_array);
                break;
            case self::NOT_IN_FUNCTION:
            case self::NOT_IN_OPERATOR:
                $op = self::notIn($column, $value_array);
                break;
            case self::IS_NULL_FUNCTION:
            case self::IS_NULL_OPERATOR:
                $op = self::isNull($column);
                break;
            case self::IS_NOT_NULL_FUNCTION:
            case self::IS_NOT_NULL_OPERATOR:
                $op = self::isNotNull($column);
                break;
            case self::BETWEEN_FUNCTION:
            case self::BETWEEN_OPERATOR:
                $op = self::between($column, $value_array[0], $value_array[1]);
                break;
            case self::NOT_BETWEEN_FUNCTION:
            case self::NOT_BETWEEN_OPERATOR:
                $op = self::notBetween($column, $value_array[0], $value_array[1]);
                break;
            default:
                $op = $operator;
        }

        return $op;
    }

    protected static function cast($value, $type)
    {
        $value = self::quote($value);
        if (self::TYPE_INTEGER === $type) {
            $value = (int) $value;
        } elseif (self::TYPE_DATETIME == $type) {
            $value = (new \DateTime($value))->format('Y-m-d H:i:s');
        }

        return $value;
    }

    /**
     * @param array $value_array
     *
     * @return array
     */
    public static function and(array $value_array): array
    {
        return [self::AND_FUNCTION => ['value' => $value_array]];
    }

    /**
     * @param $value_array
     *
     * @return array
     */
    public static function or($value_array): array
    {
        return [self::OR_FUNCTION => ['value' => $value_array]];
    }

    /**
     * @param string      $column
     * @param string|null $value
     *
     * @return array
     */
    public static function like(string $column, ?string $value): array
    {
        return null === $value ? self::isNull($column) : [self::LIKE_FUNCTION => ['column' => $column, 'value' => self::quote($value)]];
    }

    /**
     * @param string $column
     *
     * @return array
     */
    public static function isNull(string $column): array
    {
        return [self::IS_NULL_FUNCTION => ['column' => $column]];
    }

    /**
     * Quote.
     *
     * @param string $string
     *
     * @return string
     */
    public static function quote(string $string): string
    {
        //return "'".self::escape($string)."'";
        return self::escape($string);
    }

    /**
     * Returns a string with backslashes before characters that need to be escaped.
     * As required by MySQL and suitable for multi-byte character sets
     * Characters encoded are NUL (ASCII 0), \n, \r, \, ', ", and ctrl-Z.
     *
     * @param string $string String to add slashes to
     *
     * @return string $string with `\` prepended to reserved characters
     *
     * @author Trevor Herselman
     */
    final protected static function escape(string $string): string
    {
        return preg_replace('~[\x00\x0A\x0D\x1A\x22\x27\x5C]~u', '\\\$0', $string);
    }

    /**
     * @param string      $column
     * @param string|null $value
     *
     * @return array
     */
    public static function notLike(string $column, ?string $value): array
    {
        return null === $value ? self::isNotNull($column) : [self::NOT_LIKE_FUNCTION => ['column' => $column, 'value' => self::quote($value)]];
    }

    /**
     * @param string $column
     *
     * @return array
     */
    public static function isNotNull(string $column): array
    {
        return [self::IS_NOT_NULL_FUNCTION => ['column' => $column]];
    }

    /**
     * @param string      $column
     * @param string|null $value
     * @param string      $type
     *
     * @return array
     */
    public static function eq(string $column, ?string $value = '', $type = self::TYPE_STRING): array
    {
        $value = self::cast(self::quote($value), $type);

        return null === $value ? self::isNull($column) : [self::EQUAL_FUNCTION => ['column' => $column, 'type' => $type, 'value' => $value]];
    }

    /**
     * @param string      $column
     * @param string|null $value
     * @param string      $type
     *
     * @return array
     */
    public static function neq(string $column, ?string $value, $type = self::TYPE_STRING): array
    {
        $value = self::cast(self::quote($value), $type);

        return null === $value ? self::isNotNull($column) : [self::NOT_EQUAL_FUNCTION => ['column' => $column, 'type' => $type, 'value' => $value]];
    }

    /**
     * @param string      $column
     * @param string|null $value
     * @param string      $type
     *
     * @return array
     */
    public static function gt(string $column, ?string $value, $type = self::TYPE_STRING): array
    {
        $value = self::cast(self::quote($value), $type);

        return null === $value ? self::isNotNull($column) : [self::GREATER_THAN_FUNCTION => ['column' => $column, 'type' => $type, 'value' => $value]];
    }

    /**
     * @param string      $column
     * @param string|null $value
     * @param string      $type
     *
     * @return array
     */
    public static function gte(string $column, ?string $value, $type = self::TYPE_STRING): array
    {
        $value = self::cast(self::quote($value), $type);

        return null === $value ? self::isNotNull($column) : [self::GREATER_THAN_EQUAL_FUNCTION => ['column' => $column, 'type' => $type, 'value' => $value]];
    }

    /**
     * @param string      $column
     * @param string|null $value
     * @param string      $type
     *
     * @return array
     */
    public static function lt(string $column, ?string $value, $type = self::TYPE_STRING): array
    {
        $value = self::cast(self::quote($value), $type);

        return null === $value ? self::isNull($column) : [self::LOWER_THAN_FUNCTION => ['column' => $column, 'type' => $type, 'value' => $value]];
    }

    /**
     * @param string      $column
     * @param string|null $value
     * @param string      $type
     *
     * @return array
     */
    public static function lte(string $column, ?string $value, $type = self::TYPE_STRING): array
    {
        $value = self::cast(self::quote($value), $type);

        return null === $value ? self::isNull($column) : [self::LOWER_THAN_EQUAL_FUNCTION => ['column' => $column, 'type' => $type, 'value' => $value]];
    }

    /**
     * @param string $column
     * @param array  $value_array
     * @param string $type
     *
     * @return array
     */
    public static function in(string $column, array $value_array, $type = self::TYPE_STRING): array
    {
        return [
            self::IN_FUNCTION => [
                'column' => $column,
                'type' => $type,
                'value' => array_map(
                    function ($value) use ($type) {
                        $value = self::cast(self::quote($value), $type);

                        return $value;
                    },
                    $value_array
                ),
            ],
        ];
    }

    /**
     * @param string $column
     * @param array  $value_array
     * @param string $type
     *
     * @return array
     */
    public static function notIn(string $column, array $value_array, $type = self::TYPE_STRING): array
    {
        return [
            self::NOT_IN_FUNCTION => [
                'column' => $column,
                'type' => $type,
                'value' => array_map(
                    function ($value) use ($type) {
                        $value = self::cast(self::quote($value), $type);

                        return $value;
                    },
                    $value_array
                ),
            ],
        ];
    }

    /**
     * @param string $column
     * @param string $valueMin
     * @param string $valueMax
     * @param string $type
     *
     * @return array
     */
    public static function between(string $column, string $valueMin, string $valueMax, $type = self::TYPE_STRING): array
    {
        return [self::BETWEEN_FUNCTION => [
                'column' => $column, 'type' => $type, 'value' => [
                    self::cast(self::quote($valueMin), $type),
                    self::cast(self::quote($valueMax), $type),
                ],
            ],
        ];
    }

    /**
     * @param string $column
     * @param string $valueMin
     * @param string $valueMax
     * @param string $type
     *
     * @return array
     */
    public static function notBetween(string $column, string $valueMin, string $valueMax, $type = self::TYPE_STRING): array
    {
        return [self::NOT_BETWEEN_FUNCTION => [
                'column' => $column, 'type' => $type, 'value' => [
                    self::cast(self::quote($valueMin), $type),
                    self::cast(self::quote($valueMax), $type),
                ],
            ],
        ];
    }
}
