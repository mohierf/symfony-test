<?php

namespace App\Model;

use ApiPlatform\Core\Annotation\ApiProperty;
use ApiPlatform\Core\Annotation\ApiResource;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * Class Ping.
 *
 * @ApiResource(
 *     itemOperations={
 *          "ping"={
 *              "method"="POST",
 *              "route_name"="ping",
 *              "swagger_context"={
 *                  "summary"="Ping the service to check connection credentials"
 *              },
 *          }
 *     },
 *     collectionOperations={},
 *     attributes={
 *          "normalization_context"={
 *              "groups"={"ping:read"},
 *              "swagger_definition_name"="Read"
 *          },
 *          "denormalization_context"={
 *              "groups"={"ping:write"},
 *              "swagger_definition_name"="Write"
 *          }
 *     }
 * )
 */
class Ping
{
    /**
     * @var string
     *
     * @ApiProperty(
     *     iri="https://schema.org/result",
     *     attributes={
     *          "swagger_context"={
     *                  "type"="string",
     *          },
     *      }
     * )
     *
     * @Groups({"ping:read"})
     */
    private $message;

    /**
     * @return string
     */
    public function getMessage(): string
    {
        return $this->message;
    }

    /**
     * @param string $message
     */
    public function setMessage(string $message): void
    {
        $this->message = $message;
    }
}
