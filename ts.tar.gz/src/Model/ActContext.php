<?php

namespace App\Model;

use DateTimeImmutable;
use Sfk\Lib\ErpClient\Model\AddressRead;
use Sfk\Lib\ErpClient\Model\InsuranceContractRead;
use Sfk\Lib\ErpClient\Model\ModelInterface;
use Sfk\Lib\ErpClient\Model\PrivilegeContractRead;
use Sfk\Lib\ErpClient\Model\WebsiteContractRead;

/**
 * Class ActContext.
 */
abstract class ActContext extends GlobalContext
{
    // Contract
    public const CONTRACT_CLOSING_DATE = 'contract_closing_date';
    public const CONTRACT_DATE = 'contract_date';
    public const CONTRACT_DATE_PLUS_1_MONTH = 'contract_date_plus_1_month';
    public const CONTRACT_DATE_PLUS_12_MONTHS = 'contract_date_plus_12_months';
    public const CONTRACT_DATE_PLUS_2_MONTHS = 'contract_date_plus_2_months';
    public const CONTRACT_MEAN_OF_PAYMENT = 'contract_mean_of_payment';
    public const CONTRACT_NUMBER = 'contract_number';
    public const CONTRACT_PACKAGE_NAME = 'contract_package_name';
    public const CONTRACT_STATUS = 'contract_status';
    // Options
    public const CONTRACT_OPTIONS_LIST = 'contract_options_list';
    public const CONTRACT_OPTIONS_WITH_AMOUNTS_LIST = 'contract_options_with_amounts_listk';
    // Client
    /* @Todo Remove if it is the same data as ADDRESS_CLIENT_NAME */
    public const CLIENT_NAME = 'client_name';
    // Address : client
    public const ADDRESS_CLIENT_CIVILITY = 'address_client_civility';
    public const ADDRESS_CLIENT_NAME = 'address_client_name';
    public const ADDRESS_CLIENT_ADDRESS = 'address_client_address';
    public const ADDRESS_CLIENT_CITY = 'address_client_city';
    public const ADDRESS_CLIENT_POSTAL_CODE = 'address_client_postal_code';
    public const ADDRESS_CLIENT_COUNTRY = 'address_client_country';
    public const ADDRESS_CLIENT_EMAIL = 'address_client_email';
    public const ADDRESS_CLIENT_PHONE_NUMBER = 'address_client_phone_number';
    public const ADDRESS_CLIENT_MOBILE_NUMBER = 'address_client_mobile_number';
    // Address : delivery
    public const ADDRESS_DELIVERY_CIVILITY = 'address_delivery_civility';
    public const ADDRESS_DELIVERY_NAME = 'address_delivery_name';
    public const ADDRESS_DELIVERY_ADDRESS = 'address_delivery_address';
    public const ADDRESS_DELIVERY_CITY = 'address_delivery_city';
    public const ADDRESS_DELIVERY_POSTAL_CODE = 'address_delivery_postal_code';
    public const ADDRESS_DELIVERY_COUNTRY = 'address_delivery_country';
    public const ADDRESS_DELIVERY_EMAIL = 'address_delivery_email';
    public const ADDRESS_DELIVERY_PHONE_NUMBER = 'address_delivery_phone_number';
    public const ADDRESS_DELIVERY_MOBILE_NUMBER = 'address_delivery_mobile_number';
    // Address : invoicee
    public const ADDRESS_INVOICEE_CIVILITY = 'address_invoicee_civility';
    public const ADDRESS_INVOICEE_NAME = 'address_invoicee_name';
    public const ADDRESS_INVOICEE_ADDRESS = 'address_invoicee_address';
    public const ADDRESS_INVOICEE_CITY = 'address_invoicee_city';
    public const ADDRESS_INVOICEE_POSTAL_CODE = 'address_invoicee_postal_code';
    public const ADDRESS_INVOICEE_COUNTRY = 'address_invoicee_country';
    public const ADDRESS_INVOICEE_EMAIL = 'address_invoicee_email';
    public const ADDRESS_INVOICEE_PHONE_NUMBER = 'address_invoicee_phone_number';
    public const ADDRESS_INVOICEE_MOBILE_NUMBER = 'address_invoicee_mobile_number';
    // Salesman
    public const SALESMAN_NAME = 'salesman_name';
    // Agencies
    public const AGENCY_NAME = 'agency_name';
    public const AGENCY_ADDRESS = 'agency_address';
    public const AGENCY_CITY = 'agency_city';
    public const AGENCY_POSTAL_CODE = 'agency_postal_code';
    public const AGENCY_COUNTRY = 'agency_country';
    public const AGENCY_PHONE_NUMBER = 'agency_phone_number';

    /**
     * @var InsuranceContractRead|PrivilegeContractRead|WebsiteContractRead
     */
    protected $contract;

    /**
     * ActContext constructor.
     *
     * @param ModelInterface $contract
     */
    public function __construct(ModelInterface $contract)
    {
        parent::__construct();
        $this->contract = $contract;
    }

    /**
     * @return array
     *
     * @throws \Exception
     */
    public function getContext(): array
    {
        return array_merge(parent::getContext(), $this->getActContext());
    }

    /**
     * @return array
     *
     * @throws \Exception
     */
    protected function getActContext(): array
    {
        if ($this->contract->getDate() instanceof \DateTime) {
            $contract_creation_date = new DateTimeImmutable($this->contract->getDate()->format('Y/m/d H:i:s'));
            $contract_closing_date = $this->contract->getClosingDate()
                ? new DateTimeImmutable($this->contract->getClosingDate()->format('Y/m/d H:i:s')) : null;
        } else {
            $contract_creation_date = new DateTimeImmutable($this->contract->getDate());
            $contract_closing_date = $this->contract->getClosingDate() ? new DateTimeImmutable($this->contract->getClosingDate()) : null;
        }

        // Contract
        $context[self::CONTRACT_CLOSING_DATE] = $contract_closing_date ? $contract_closing_date->format('d/m/Y') : null;
        $context[self::CONTRACT_DATE] = $contract_creation_date->format('d/m/Y');
        $context[self::CONTRACT_DATE_PLUS_1_MONTH] = $contract_creation_date->add(new \DateInterval('P1M'))->format('d/m/Y');
        $context[self::CONTRACT_DATE_PLUS_2_MONTHS] = $contract_creation_date->add(new \DateInterval('P2M'))->format('d/m/Y');
        $context[self::CONTRACT_DATE_PLUS_12_MONTHS] = $contract_creation_date->add(new \DateInterval('P12M'))->format('d/m/Y');
        $context[self::CONTRACT_MEAN_OF_PAYMENT] = $this->contract->getMeanOfPayment();
        $context[self::CONTRACT_NUMBER] = $this->contract->getNumber();
        $context[self::CONTRACT_PACKAGE_NAME] = $this->contract->getPackage()->getTradeName()->getName();
        $context[self::CONTRACT_STATUS] = $this->contract->getStatus();

        // Options
        if ($options = $this->contract->getOptions()) {
            foreach ($options as $key => $option) {
                $context[self::CONTRACT_OPTIONS_LIST][] = $option->getOption()->getName();
                /* @Todo Remove. For tests purpose only.  */
                $context[self::CONTRACT_OPTIONS_WITH_AMOUNTS_LIST]['Option n°'.((int) $key + 1)] = $option->getOption()->getName();
            }
        }

        // Client
        /* @Todo Remove if it is the same data as $address->getName() */
        $context[self::CLIENT_NAME] = $this->contract->getClient()->getName();

        // Addresses
        foreach (['CLIENT', 'DELIVERY', 'INVOICEE'] as $type) {
            $address = $this->getAddressByType(strtolower($type));
            $context[constant('self::ADDRESS_'.$type.'_CIVILITY')] = $address ? $address->getCivility() : null;
            $context[constant('self::ADDRESS_'.$type.'_NAME')] = $address ? $address->getName() : null;
            $context[constant('self::ADDRESS_'.$type.'_ADDRESS')] = $address ? $address->getAddress() : null;
            $context[constant('self::ADDRESS_'.$type.'_CITY')] = $address ? $address->getCity()->getName() : null;
            $context[constant('self::ADDRESS_'.$type.'_POSTAL_CODE')] = $address ? $address->getCity()->getPostalCode() : null;
            $context[constant('self::ADDRESS_'.$type.'_COUNTRY')] = $address ? $address->getCity()->getCountry()->getName() : null;
            $context[constant('self::ADDRESS_'.$type.'_EMAIL')] = $address ? $address->getEmail() : null;
            $context[constant('self::ADDRESS_'.$type.'_PHONE_NUMBER')] = $address ? $address->getPhoneNumber() : null;
            $context[constant('self::ADDRESS_'.$type.'_MOBILE_NUMBER')] = $address ? $address->getMobileNumber() : null;
        }
        // Salesman
        $context[self::SALESMAN_NAME] = ($salesman = $this->contract->getSalesman()) ? $salesman->getContact()->getName() : null;

        // Agencies
        $context[self::AGENCY_NAME] = $this->contract->getAgency()->getName();
        $context[self::AGENCY_ADDRESS] = $this->contract->getAgency()->getAddress()->getAddress();
        $context[self::AGENCY_CITY] = $this->contract->getAgency()->getAddress()->getCity()->getName();
        $context[self::AGENCY_POSTAL_CODE] = $this->contract->getAgency()->getAddress()->getCity()->getPostalCode();
        $context[self::AGENCY_COUNTRY] = $this->contract->getAgency()->getAddress()->getCity()->getCountry()->getName();
        $context[self::AGENCY_PHONE_NUMBER] = $this->contract->getAgency()->getAddress()->getPhoneNumber();

        return $context;
    }

    /**
     * @param string $addressType
     *
     * @return AddressRead|null
     */
    protected function getAddressByType(string $addressType = 'client'): ?AddressRead
    {
        $addresses = $this->contract->getClient()->getAddresses();

        foreach ($addresses as $address) {
            if ($address->getType() === $addressType) {
                return $address->getAddress();
            }
        }

        return null;
    }
}
