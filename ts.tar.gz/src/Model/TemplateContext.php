<?php

namespace App\Model;

use DateTime;
use Exception;
use ReflectionException;

/**
 * Class TemplateContext.
 */
class TemplateContext extends GlobalContext
{
    /**
     * @var array
     */
    protected $data;

    /**
     * TemplateContext constructor.
     *
     * @param array $data
     */
    public function __construct(array $data)
    {
        parent::__construct();

        $this->data = $data;
    }

    /**
     * Retrieve specific constants of a given context.
     *
     * @throws ReflectionException
     */
    public static function getSpecificConstants(): array
    {
        $parentConstants = [];
        $parentClass = get_parent_class(static::class);

        if ($parentClass) {
            $reflectionParent = new \ReflectionClass($parentClass);
            $parentConstants = $reflectionParent->getConstants();
        }

        return array_diff(static::getConstants(), $parentConstants);
    }

    /**
     * @return array
     *
     * @throws Exception
     */
    public function getContext(): array
    {
        return array_merge(parent::getContext(), $this->getTemplateContext());
    }

    /**
     * @return array
     *
     * @throws Exception
     */
    protected function getTemplateContext(): array
    {
        return $this->getDataForRendering($this->data);
    }

    /**
     * @param        $data
     * @param null   $parent
     * @param string $prefix
     * @param array  $simpleValues
     *
     * @return array
     *
     * @throws Exception
     */
    private function getDataForRendering($data, $parent = null, $prefix = '', &$simpleValues = []): array
    {
        $data = json_decode(json_encode($data));
        $isoDatePattern = '#(\d{4})-(\d{2})-(\d{2})T(\d{2})\:(\d{2})\:(\d{2})[+-](\d{2})\:(\d{2})#';
        $context = [];
        $separator = '_';

        foreach ($data as $property => $value) {
            if (is_array($value)) {
                $context[$property] = $this->getDataForRendering($value, $property);
            } elseif (is_object($value)) {
                if (null !== $parent) {
                    $context[$property] = $this->getDataForRendering($value, $property);
                } else {
                    $context[$property] = $this->getDataForRendering($value, null, $prefix.$separator.$property.$separator, $simpleValues);
                }
            } else {
                $simpleValues[trim($prefix.$property, $separator)] = $value;
            }
        }

        // Add each simple values (ie neither object nor class) to the context. Apply specific treatments before if needed.
        foreach ($simpleValues as $property => $value) {
            // Format date from ISO 8601 format to choosen one.
            if (preg_match($isoDatePattern, $value)) {
                // @TODO Format depends on the template language
                $dateFormat = 'd/m/Y';
                $value = (new DateTime($value))->format($dateFormat);
            }
            $property = preg_replace('/(_)+/', '_', $property);

            $context[$property] = $value;
        }

        return $context;
    }
}
