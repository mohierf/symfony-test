<?php

namespace App\Api\Action;

use App\Model\Ping;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class PingAction.
 */
class PingAction extends AbstractController
{
    /**
     * @Route("/api/ping",
     *     name="ping",
     *     methods={"POST"},
     *     defaults={
     *         "_api_respond"=true,
     *         "_api_normalization_context"={"api_sub_level"=true}
     *     })
     *
     * @return Ping
     */
    public function __invoke(): Ping
    {
        $ping = new Ping();
        $ping->setMessage('pong from template designer service');

        return $ping;
    }
}
