<?php

namespace App\Api\Action;

use App\Entity\Template;
use App\Services\PdfGeneratorService;
use DateTime;
use Sfk\Lib\ErpClient\ApiException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Twig\Error\LoaderError;
use Twig\Error\SyntaxError;

/**
 * Class PdfFromTemplateAction.
 */
class PdfFromTemplateAction
{
    /**
     * @Route("/api/template/{uuid}/pdf",
     *     name="template_pdf",
     *     methods={"POST"},
     * )
     *
     * @param Template            $data
     * @param Request             $request
     * @param PdfGeneratorService $pdfGenerator
     *
     * @return JsonResponse|Response
     *
     * @throws ApiException
     * @throws LoaderError
     * @throws SyntaxError
     */
    public function __invoke(Template $data, Request $request, PdfGeneratorService $pdfGenerator)
    {
        $requestBody = $request->getContent();
        $filename = sprintf('%s-%s.pdf', md5($requestBody), (new DateTime())->format('YmdHis'));
        $response = $pdfGenerator->generate($data, $requestBody, $filename);

        return $response;
    }
}
