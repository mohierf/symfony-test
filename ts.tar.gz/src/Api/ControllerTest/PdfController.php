<?php

namespace App\Api\ControllerTest;

use Sfk\StandardBundle\Controller\AbstractController;
use Sfk\TemplateDesignerClientBundle\Services\ClientRegistryInterface;
use Sfk\TemplateDesignerClientBundle\Services\ClientRegistryTrait;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class PdfController.
 */
class PdfController extends AbstractController implements ClientRegistryInterface
{
    use ClientRegistryTrait;

    /**
     * @Route("/pdf")
     *
     * @return Response
     *
     * @throws \Sfk\Lib\TemplateDesignerClient\ApiException
     */
    public function generateAction()
    {
        $json = <<<JSON
{
  "vatDetails": [
    {
      "rate": "20%",
      "value": "6 €"
    },
    {
      "rate": "5.5%",
      "value": "2 €"
    }
  ],
  "totalWithTax": "7,99 €",
  "totalWithoutTax": "6,66 €",
  "number": "HFRB52803294105",
  "date": "2019-03-05T11:03:59+01:00",
  "clientName": "Madame de Pique",
  "clientAddress": {
    "city": "VALENCE",
    "postalCode": "26000",
    "country": "France",
    "address": "154 avenue de la Relativité Générale"
  },
  "companyName": "Hubside",
  "companyAddress": {
    "city": "ROMANS SUR ISERE",
    "postalCode": "26100",
    "country": "FRANCE",
    "address": "1 RUE CAMILLE CLAUDEL"
  },
  "items": [
    {
      "content": "Exclusiv HUBSIDE du 1 January au 31 January",
      "price": true,
      "quantity": 1,
      "pricePerUnit": "6,66 €",
      "priceWithTax": "7,99 €",
      "taxRate": "20%",
      "subItems": [
        {
          "content": "Créez et gérez votre site grâce aux modèles et outils Hubside",
          "price": false,
          "quantity": null,
          "pricePerUnit": null,
          "priceWithTax": null,
          "taxRate": "20%",
          "subItems": []
        },
        {
          "content": "Antivirus Norton 2020 Pack Plus Mieux Bien",
          "price": true,
          "quantity": 1,
          "pricePerUnit": "10 €",
          "priceWithTax": "12 €",
          "taxRate": "20%",
          "subItems": []
        }
      ]
    }
  ],
  "paymentDeadline": null,
  "optionalMentions": "",
  "scheduledDate": "2019-01-01T00:00:00+01:00",
  "meanOfPayment": "direct_debit"
}

JSON;

        $template = $this->getTemplateDesignerClient()->getTemplateApi()->pdfFromTemplateTemplateItem('4cfc94de-1917-45b6-9614-86c620649eee', $json);

        $response = new Response($template);
        // Create the disposition of the file
        $disposition = $response->headers->makeDisposition(
            ResponseHeaderBag::DISPOSITION_ATTACHMENT,
            'example.pdf'
        );

        // Set the content disposition
        $response->headers->set('Content-Disposition', $disposition);
        $response->headers->set('Content-Type', 'application/pdf');

        return $response;
    }
}
