<?php

namespace App\Synchronizer;

use App\Entity\TypeOfAct;

/**
 * Class InsuranceSynchronizer.
 */
class InsuranceSynchronizer extends BaseTypeOfActSynchronizer
{
    const TYPE_OF_ACT = TypeOfAct::INSURANCE;
}
