<?php

namespace App\Synchronizer;

use App\Entity\TypeOfAct;

/**
 * Class WebsiteSynchronizer.
 */
class WebsiteSynchronizer extends BaseTypeOfActSynchronizer
{
    const TYPE_OF_ACT = TypeOfAct::WEBSITE;
}
