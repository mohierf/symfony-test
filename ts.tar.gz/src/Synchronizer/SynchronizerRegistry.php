<?php

namespace App\Synchronizer;

/**
 * Class SynchronizerRegistry.
 */
class SynchronizerRegistry
{
    /**
     * @var array
     */
    protected $synchronizers = [];

    /**
     * @param $table
     * @param $object
     */
    public function addSynchronizer(string $table, $object)
    {
        $this->synchronizers[$table] = $object;
    }

    /**
     * @return array
     */
    public function getSynchronizers()
    {
        return $this->synchronizers;
    }

    /**
     * @param string $table
     *
     * @return mixed
     */
    public function getSynchronizer(string $table)
    {
        if (!isset($this->synchronizers[$table])) {
            throw new \InvalidArgumentException(sprintf('No synchronizer found for table "%s"', $table));
        }

        return $this->synchronizers[$table];
    }
}
