<?php

namespace App\Synchronizer;

use App\Entity\TypeOfAct;

/**
 * Class PrivilegeSynchronizer.
 */
class PrivilegeSynchronizer extends BaseTypeOfActSynchronizer
{
    const TYPE_OF_ACT = TypeOfAct::PRIVILEGE;
}
