<?php

namespace App\Synchronizer;

use App\Entity\TypeOfAct;

/**
 * Class BaseTypeOfActSynchronizer.
 */
class BaseTypeOfActSynchronizer extends BaseSynchronizer
{
    const TYPE_OF_ACT = null;

    /**
     * @var array
     */
    protected $typeOfActs = [];

    /**
     * @param string $name
     *
     * @return TypeOfAct|mixed|null
     *
     * @throws \Exception
     */
    protected function getTypeOfAct(string $name)
    {
        if (empty($this->typeOfActs)) {
            $typeOfActs = $this->getManager()
                ->getRepository(TypeOfAct::class)
                ->findAll();

            foreach ($typeOfActs as $typeOfAct) {
                $this->typeOfActs[$typeOfAct->getName()] = $typeOfAct;
            }
        }

        $typeOfAct = $this->typeOfActs[$name] ?? null;
        if (null === $typeOfAct) {
            throw new \Exception(sprintf('Type of act not found: %s', static::TYPE_OF_ACT));
        }

        return $typeOfAct;
    }

    /**
     * @param array $data
     *
     * @return object|null
     *
     * @throws \Exception
     */
    protected function findExistingObject(array $data = [])
    {
        if (!isset($data['id'])) {
            return null;
        }

        return $this->getManager()->getRepository($this->model)->findOneBy([
            'erpId' => (int) $data['id'],
            'typeOfAct' => $this->getTypeOfAct(static::TYPE_OF_ACT),
        ]);
    }

    /**
     * @param $object
     * @param array $data
     *
     * @return mixed|void
     *
     * @throws \Exception
     */
    protected function setIdentifier($object, array $data = [])
    {
        if (isset($data['id'])) {
            $object->setErpId((int) $data['id']);
            $object->setTypeOfAct($this->getTypeOfAct(static::TYPE_OF_ACT));
        }
    }
}
