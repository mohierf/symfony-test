<?php

namespace App\Synchronizer;

use Symfony\Bridge\Doctrine\RegistryInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Class BaseSynchronizer.
 */
class BaseSynchronizer implements SynchronizerInterface
{
    /**
     * When data has been inserted into database.
     */
    const EVENT_INSERT = 'insert';

    /**
     * When data has been updated into database.
     */
    const EVENT_UPDATE = 'update';

    /**
     * When data has been deleted from database.
     */
    const EVENT_DELETE = 'delete';

    /**
     * @var string
     */
    protected $databaseName;

    /**
     * @var string
     */
    protected $tableName;

    /**
     * @var array
     */
    protected $supportedEvents = [];

    /**
     * @var array
     */
    protected $syncedAttributes = [];

    /**
     * @var array
     */
    protected $identifiers = [];

    /**
     * @var array
     */
    protected $mapping = [];

    /**
     * @var string
     */
    protected $model;

    /**
     * @var RegistryInterface
     */
    private $registry;

    /**
     * @var array
     */
    public static $events = [
        self::EVENT_INSERT,
        self::EVENT_UPDATE,
        self::EVENT_DELETE,
    ];

    /**
     * @param array $data
     *
     * @return object|null
     */
    protected function findExistingObject(array $data = [])
    {
        if (!isset($data['id'])) {
            return null;
        }

        return $this->getManager()->getRepository($this->model)->findOneBy([
            'erpId' => (int) $data['id'],
        ]);
    }

    /**
     * @param $object
     * @param array $data
     */
    protected function setIdentifier($object, array $data = [])
    {
        if (isset($data['id'])) {
            $object->setErpId((int) $data['id']);
        }
    }

    /**
     * @param $object
     * @param array $data
     */
    protected function setExtraData($object, array $data = [])
    {
    }

    /**
     * @return \Doctrine\Common\Persistence\ObjectManager
     */
    protected function getManager()
    {
        return $this->registry->getManager();
    }

    /**
     * BaseSynchronizer constructor.
     *
     * @param RegistryInterface $registry
     */
    public function __construct(RegistryInterface $registry)
    {
        $this->registry = $registry;
    }

    /**
     * {@inheritdoc}
     */
    public function setDatabaseName(string $databaseName)
    {
        $this->databaseName = $databaseName;

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setTableName(string $tableName)
    {
        $this->tableName = $tableName;

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setSupportedEvents(array $events)
    {
        foreach ($events as $event) {
            if (!in_array($event, self::$events)) {
                throw new \InvalidArgumentException(
                    sprintf('Invalid configured event "%s". Allowed are "%s"', $event, join(', ', self::$events))
                );
            }
        }
        $this->supportedEvents = $events;

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setSyncedAttributes(array $attributes)
    {
        $this->syncedAttributes = $attributes;

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setIdentifiers(array $identifiers)
    {
        $this->identifiers = $identifiers;

        return $this;
    }

    /**
     * {@inheritdoc}
     */
    public function setAttributesMapping(array $mapping)
    {
        $this->mapping = $mapping;

        return $this;
    }

    /**
     * @param array $data
     *
     * @return array
     */
    public function getUsefulData(array $data)
    {
        $usefulAttributes = array_merge($this->syncedAttributes, $this->identifiers);
        $usefulData = array_intersect_key($data, array_flip($usefulAttributes));

        if (empty(array_diff_key($usefulData, array_flip($this->identifiers)))) {
            return $usefulData;
        }

        return $usefulData;
    }

    /**
     * {@inheritdoc}
     */
    public function setModel(string $model)
    {
        $this->model = $model;

        return $this;
    }

    /**
     * @param array $options
     *
     * @return mixed|void
     *
     * @throws \Exception
     */
    public function synchronize(array $options = [])
    {
        $connection = $this->getManager()->getConnection();
        $connection->getConfiguration()->setSQLLogger(null);

        $resolver = new OptionsResolver();
        $resolver->setRequired(['database', 'table', 'type', 'data']);
        $options = $resolver->resolve($options);

        if ($this->tableName !== $options['table']) {
            throw new \Exception(sprintf(
                'Synchronizer and message table config must be the same (%s VS %s)',
                $this->tableName, $options['table']
            ));
        }

        if ($this->databaseName !== $options['database']) {
            throw new \Exception(sprintf(
                'Synchronizer and message database config must be the same (%s VS %s)',
                $this->databaseName, $options['database']
            ));
        }

        if (!in_array($options['type'], self::$events)) {
            throw new \Exception(sprintf(
                'The synchronizer CANNOT manage type %s',
                $options['type']
            ));
        }

        $errorFields = array_diff_key(array_flip($this->syncedAttributes), $options['data']);
        if (!empty($errorFields)) {
            throw new \Exception(sprintf('Fields not found in message: %s', join(', ', array_keys($errorFields))));
        }

        $this->synchronizeData($options);
    }

    /**
     * @param array $options
     *
     * @throws \Exception
     */
    protected function synchronizeData(array $options = [])
    {
        $data = $options['data'];
        $mapping = $this->mapping;
        $sourceObject = $this->findExistingObject($data);

        if (null === $sourceObject) {
            $className = $this->model;
            $sourceObject = new $className();
        }
        $this->setIdentifier($sourceObject, $data);

        $classMetadata = $this->getManager()->getClassMetadata($this->model);

        $selfReferencing = [];
        foreach ($mapping as $rabbitField => $attribute) {
            $projectField = $attribute['project_field'] ?? $attribute['rabbitmq_field'];
            if (isset($data[$rabbitField]) && false === $attribute['translated']) {
                $association = $classMetadata->associationMappings[$projectField] ?? null;
                $setterName = sprintf('set%s', ucfirst($projectField));

                if (null !== $association) {
                    $targetEntity = $association['targetEntity'];
                    if ($targetEntity === $this->model) {
                        $selfReferencing[] = [
                            'setter' => $setterName,
                            'value' => $data[$rabbitField],
                        ];
                    } else {
                        $object = $this->getManager()->getRepository($targetEntity)->find((int) $data[$rabbitField]);
                        if (null !== $object) {
                            $sourceObject->$setterName($object);
                        }
                    }
                } else {
                    $sourceObject->$setterName($data[$rabbitField]);
                }
            }
        }
        $this->setExtraData($sourceObject, $data);

        $this->getManager()->persist($sourceObject);
        $this->getManager()->flush();

        // For self referencing relations we need to link the newly created entities.
        $needFlush = false;
        foreach ($selfReferencing as $config) {
            $setterName = $config['setter'];
            $existing = $this->getManager()->getRepository($this->model)->find((int) $config['value']);
            if (null !== $existing) {
                $sourceObject->$setterName($existing);
                $needFlush = true;
            }
        }

        if ($needFlush) {
            $this->getManager()->persist($sourceObject);
            $this->getManager()->flush();
        }
    }
}
