<?php

namespace App\Synchronizer;

use App\Entity\Language;

/**
 * Class CountrySynchronizer.
 */
class CountrySynchronizer extends BaseSynchronizer
{
    /**
     * {@inheritdoc}
     */
    protected function setExtraData($object, array $data = [])
    {
        $object->translate(Language::LANGUAGE_FR)->setName($data['name']);
        $object->mergeNewTranslations();
    }
}
