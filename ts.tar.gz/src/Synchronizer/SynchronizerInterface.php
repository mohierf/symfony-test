<?php

namespace App\Synchronizer;

/**
 * Interface SynchronizerInterface.
 */
interface SynchronizerInterface
{
    /**
     * @param string $databaseName
     *
     * @return self
     */
    public function setDatabaseName(string $databaseName);

    /**
     * @param string $tableName
     *
     * @return self
     */
    public function setTableName(string $tableName);

    /**
     * @param array $events
     *
     * @return self
     */
    public function setSupportedEvents(array $events);

    /**
     * @param array $attributes
     *
     * @return self
     */
    public function setSyncedAttributes(array $attributes);

    /**
     * @param array $identifiers
     *
     * @return self
     */
    public function setIdentifiers(array $identifiers);

    /**
     * @param array $mapping
     *
     * @return self
     */
    public function setAttributesMapping(array $mapping);

    /**
     * @param string $model
     */
    public function setModel(string $model);

    /**
     * @param array $message
     *
     * @return mixed
     */
    public function getUsefulData(array $message);

    /**
     * Synchronize data.
     *
     * @param array $options
     *
     * @return mixed
     */
    public function synchronize(array $options = []);
}
