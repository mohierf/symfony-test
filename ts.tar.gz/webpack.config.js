// webpack.config.js
var Encore = require('@symfony/webpack-encore');
var webpack = require('webpack');
var CopyWebpackPlugin = require('copy-webpack-plugin');
const OptimizeCSSAssetsPlugin = require("optimize-css-assets-webpack-plugin");

rebuildAngle = false;
if (rebuildAngle) {
    Encore
        .setOutputPath('assets/lib/angle/generated')
        .setPublicPath('/angle')
        .addEntry('angle-rebuild', './assets/lib/angle/angle-rebuild.js')
        .addPlugin(new webpack.optimize.UglifyJsPlugin({
            parallel: true
        }))
        .addPlugin(new OptimizeCSSAssetsPlugin({}))
        .cleanupOutputBeforeBuild()
    ;
    const angleRebuild = Encore.getWebpackConfig();
    angleRebuild.name = 'angle-rebuild';
    module.exports = [angleRebuild];
} else {
    Encore.reset();
    Encore
        .setOutputPath('public/angle')
        .setPublicPath('/angle')
        .addEntry('angle', [
            './assets/lib/angle/generated/angle-rebuild.css',
            './assets/lib/angle/generated/angle-rebuild.js',
        ])
        .addPlugin(new webpack.optimize.UglifyJsPlugin({
            parallel: true
        }))
        .addPlugin(new OptimizeCSSAssetsPlugin({}))
        .addPlugin(new CopyWebpackPlugin([{
            from: 'assets/lib/angle/generated/images',
            to: 'images'
        },{
            from: 'assets/lib/angle/generated/fonts',
            to: 'fonts'
        }]))
        .cleanupOutputBeforeBuild()
        .enableBuildNotifications()
        .enableVersioning()
    ;
    const angle = Encore.getWebpackConfig();
    angle.name = 'angle';

    Encore.reset();
    Encore
        .setOutputPath('public/app')
        .setPublicPath('/app')
        .addEntry('app', './assets/js/app.js')
        .addEntry('template-page', './assets/js/template-page.js')
        .addEntry('email-page', './assets/js/email-page.js')
        .addEntry('custom-variable-page', './assets/js/custom-variable-page.js')
        .enableSassLoader()
        .enableSourceMaps(!Encore.isProduction())
        .cleanupOutputBeforeBuild()
        .enableBuildNotifications()
        .enableVersioning()
    ;
    const app = Encore.getWebpackConfig();
    app.name = 'app';

    module.exports = [
        angle,
        app
    ];
}




