<?php

const ROLE_SUPER_ADMIN = 'ROLE_SUPER_ADMIN';
const ROLE_ADMIN = 'ROLE_ADMIN';
const ROLE_USER = 'ROLE_USER';

const ROLES = [
    ROLE_SUPER_ADMIN,
    ROLE_ADMIN,
    ROLE_USER,
];

const FEATURE_EMAIL_MESSAGE = 'FEATURE_EMAIL';
const FEATURE_EMAIL_MESSAGES = [
    'email' => [
        FEATURE_EMAIL_MESSAGE => 'Gestion des emails'
    ]
];

const FEATURE_SMS_MESSAGE = 'FEATURE_SMS';
const FEATURE_SMS_MESSAGES = [
    'sms' => [
        FEATURE_SMS_MESSAGE => 'Gestion des SMS'
    ]
];

const FEATURE_DOCUMENT = 'FEATURE_DOCUMENT';
const FEATURE_DOCUMENTS = [
    'document' => [
        FEATURE_DOCUMENT => 'Gestion des documents'
    ]
];

const FEATURE_TEMPLATE = 'FEATURE_TEMPLATE';
const FEATURE_TEMPLATES = [
    'template' => [
        FEATURE_TEMPLATE => 'Gestion des templates génériques'
    ]
];

const FEATURES = [
    'emails' => FEATURE_EMAIL_MESSAGES,
    'sms' => FEATURE_SMS_MESSAGES,
    'document' => FEATURE_DOCUMENTS,
    'template' => FEATURE_TEMPLATES,
];
