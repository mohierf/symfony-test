import emailForm from './components/email-form';

$(document).ready(function () {
    // Add additional validation for email templates
    const form = document.getElementById('template-form');
    form.addEventListener('submit', event => {
        emailForm.submit(event);
    });

    form.querySelectorAll('.js-sending-period').forEach(function (periodItem) {
        (periodItem.querySelector('.btn')).addEventListener('click', function () {
            periodItem.querySelector('input').valueAsDate = null;
        });
    });

    // Trigger specific behavior when activating/deactivating the template
    emailForm.activeCheckboxBehavior();
    // Do not allow to have a template both automatic and scheduled
    emailForm.automaticXorScheduledCheckbox();
});
