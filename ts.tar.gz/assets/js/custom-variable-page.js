import $ from 'jquery';
import GrapeJsManager from './components/grapesjs-manager';
import '../css/custom-variable-page.scss';

$(document).ready(function () {
    const form = document.getElementById('custom-variable-form');
    const options = {
        'container': 'gjs',
        'height': '400px'
    };

    const gjsManager = new GrapeJsManager(form, options);

    gjsManager.init();

    form.addEventListener('submit', () => {
        gjsManager
            .copyDataFromLocalStorageToForm()
            .init();
    });
});
