import '../css/app.scss';

$(document).ready(function () {
    $('[data-toggle="popover"]').popover();
    $('.js-select2').select2({
        placeholder: $(this).attr('data-placeholder') || Translator.trans('action.choose_a_value'),
        allowClear: true
    });
    $.fn.select2.defaults.set("theme", "bootstrap");

    $(document).on('click', '[data-delete-confirm]', function (e) {
        let message = $(this).attr('data-delete-confirm') || '';
        message = message.length > 0 ? message : Translator.trans('action.confirm');
        if (!confirm(message)) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }

        // Check if we need to delete file block from HTML
        if ($(this).hasClass('js-delete-file')) {
            $(this).parent('.js-file-container').remove();
            e.preventDefault();
            e.stopPropagation();
            return false;
        }

        return true;
    });

    // Dealing with form collection prototype
    $(document).on('click', '.js-add-attachment', function (e) {
        const $container = $($(this).data('prototype-add'));
        let index = $container.find(':input').length;
        const template = $container.attr('data-prototype').replace(/__name__/g, index);
        const $prototype = $(template);
        $container.append($prototype);
        index++;
        e.preventDefault();
        e.stopPropagation();
        return false;
    });

    // Handle addition and removal of items in collection of fields
    // @TODO Use same behavior for attachment form collection prototype
    $('[data-prototype]')
        .on('click', '.js-add-item', function (e) {
            addCollectionItem(e);
        })
        .on('click', '.js-remove-item', function (e) {
            removeCollectionItem(e)
        })
    ;

    function addCollectionItem(e) {
        e.preventDefault();
        e.stopPropagation();
        const $btnAdd = $(e.target);
        const $collectionWrapper = $btnAdd.closest('[data-prototype]');
        const $collection = $collectionWrapper.find('.js-collection');
        const prototype = $collectionWrapper.data('prototype');
        const index = $collectionWrapper.data('index');
        const $newForm = $(prototype.replace(/__name__/g, index));
        $collectionWrapper.data('index', index + 1);
        $newForm.appendTo($collection);
        $collection.find('.js-collection-item').last().addClass('new');
    }

    function removeCollectionItem(e) {
        e.preventDefault();
        e.stopPropagation();
        const $collectionItem = $(e.target).closest('.js-collection-item');
        if (!confirm(Translator.trans('action.remove_this_item'))) {
            return false;
        }
        $collectionItem.fadeOut().remove();
    }


    $(document).on('click', '[data-delete-confirm]', function (e) {
        let message = $(this).attr('data-delete-confirm') || '';
        message = message.length > 0 ? message : Translator.trans('action.confirm');
        if (!confirm(message)) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }

        // Check if we need to delete file block from HTML
        if ($(this).hasClass('js-delete-file')) {
            $(this).parent('.js-file-container').remove();
            e.preventDefault();
            e.stopPropagation();
            return false;
        }

        return true;
    });

    const $customVariablesButton = $('#js-custom-variables-toggle button');
    if ($customVariablesButton.length > 0) {
        const $arrow = $customVariablesButton.find('i');
        $customVariablesButton.click(function () {
            $('#custom-variables-list').toggle(function () {
                if (! $(this).is(":visible")) {
                    $arrow.removeClass('fa-caret-up').addClass('fa-caret-down')
                } else {
                    $arrow.removeClass('fa-caret-down').addClass('fa-caret-up');
                }
            });
        })
    }

});
