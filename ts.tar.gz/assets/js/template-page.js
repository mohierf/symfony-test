import $ from 'jquery';
import GrapeJsManager from './components/grapesjs-manager';
import '../css/template-page.scss';

$(document).ready(function () {

    const form = document.getElementById('template-form');
    const options = {
        'container': 'gjs',
        'height': '900px'
    };

    if (typeof translatedPlaceholdersUrl !== 'undefined') {
        options.translatedPlaceholdersUrl = translatedPlaceholdersUrl;
    }

    if (typeof translatedCustomVariablesUrl !== 'undefined') {
        options.translatedCustomVariablesUrl = translatedCustomVariablesUrl;
    }

    if (typeof displayCustomVariablesUrl !== 'undefined') {
        options.displayCustomVariablesUrl = displayCustomVariablesUrl;
    }


    const gjsManager = new GrapeJsManager(form, options);

    gjsManager.init();

    form.addEventListener('submit', () => {
        gjsManager.copyDataFromLocalStorageToForm();
    });

    const $previewForm = $("#form_preview");
    const $previewButtons = $previewForm.find('button');

    $previewButtons.click(function (event) {
        event.preventDefault();
        $previewForm.attr('action', $(this).attr('href')).submit();
    });

});
