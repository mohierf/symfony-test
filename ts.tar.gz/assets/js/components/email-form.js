import swal from "sweetalert";

function submit(event) {

    const reducer = (nbAgencies, typeOfAgencies) => nbAgencies + $(`#email_agencyFields_${typeOfAgencies}`).select2('data').length;
    const totalAgencies = ['agencies', 'mainAgencies', 'groupAgencies'].reduce(reducer, 0);

    if (totalAgencies === 0) {

        event.preventDefault();
        event.stopPropagation();

        const form = event.target;

        swal({
            title: Translator.trans('action.template.no_agencies_title'),
            text: Translator.trans('action.template.no_agencies_warning'),
            icon: 'warning',
            buttons: {
                cancel: {
                    text: Translator.trans('action.cancel'),
                    value: false,
                    visible: true,
                    className: "bg-primary",
                    closeModal: true,
                },
                confirm: {
                    text: Translator.trans('action.save'),
                    value: true,
                    visible: true,
                    className: "bg-danger",
                    closeModal: true
                }
            }
        }).then(function (value) {
            if (value) {
                form.submit();
            }
        });
    }
}

function activeCheckboxBehavior() {

    const activeCheckbox = document.getElementById('email_template_activable_active');
    const lockedCheckbox = document.getElementById('email_template_lockable_locked');

    activeCheckbox.addEventListener('click', function (event) {

        event.preventDefault();

        if (this.checked) {
            let message = Translator.trans('action.template.activation_warning');
            if (!lockedCheckbox.checked) {
                message += "\n\n"
            }
            swal({
                title: Translator.trans('action.template.activation'),
                text: message,
                icon: 'warning',
                buttons: {
                    cancel: {
                        text: Translator.trans('action.cancel'),
                        value: 'cancel',
                        visible: true,
                        className: "bg-primary",
                        closeModal: true
                    },
                    confirm: {
                        text: Translator.trans('action.template.activate'),
                        value: 'activate',
                        visible: true,
                        className: "bg-danger",
                        closeModal: true
                    }
                }
            }).then(value => {
                if ('activate' === value) {
                    let message = Translator.trans('action.template.activated');
                    if (!lockedCheckbox.checked) {
                        lockedCheckbox.checked = true;
                        message += '\n' + Translator.trans('action.template.locked');
                    }
                    activeCheckbox.checked = true;
                    swal(message, {
                        icon: "success"
                    });
                } else {
                    activeCheckbox.checked = false;
                }
            });
        } else {
            swal({
                title: Translator.trans('action.template.deactivation'),
                text: Translator.trans('action.template.deactivation_warning'),
                icon: 'warning',
                buttons: {
                    cancel: {
                        text: Translator.trans('action.cancel'),
                        value: 'cancel',
                        visible: true,
                        className: "bg-primary",
                        closeModal: true
                    },
                    confirm: {
                        text: Translator.trans('action.template.deactivate'),
                        value: 'activate',
                        visible: true,
                        className: "bg-danger",
                        closeModal: true
                    }
                }
            }).then(function (value) {
                if ('activate' === value) {
                    swal(Translator.trans('action.template.deactivated'), {
                        icon: "success"
                    });
                    activeCheckbox.checked = false;
                }
            });
        }
    });
}

function automaticXorScheduledCheckbox() {

    const automatic = document.getElementById('email_automatic');
    const scheduled = document.getElementById('email_scheduled');

    [automatic, scheduled].forEach(function (checkbox) {
        checkbox.addEventListener('click', function (event) {
                if (automatic.checked && scheduled.checked) {
                    event.preventDefault();
                    swal(Translator.trans('action.template.automatic_xor_scheduled_warning'), {
                        title: Translator.trans('action.template.automatic_xor_scheduled_title'),
                        icon: "error"
                    });
                }
            }
        );
    });
}

export default {submit, activeCheckboxBehavior, automaticXorScheduledCheckbox};
