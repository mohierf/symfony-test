class PlaceholdersDropdown {

    /**
     * PlaceholdersDropdown constructor
     *
     * @param translatedPlaceholdersUrl
     * @param dropdownId
     * @param textInputId
     */
    constructor(translatedPlaceholdersUrl, dropdownId, textInputId) {
        this.translatedPlaceholdersUrl = translatedPlaceholdersUrl;
        this.dropdownId = dropdownId;
        this.textInput = $(`#${textInputId}`);
        this.dropdown = $(`#${dropdownId}`);
    }

    init() {
        this.textInput.on('keydown', (event) => {
            if (event.key === " " && event.ctrlKey) {
                if (this.dropdown.css('display') === 'none' || (this.dropdown.children().length === 0 && this.dropdown.css('display') === 'block')) {
                    this.displayDropdown(event)
                } else {
                    this.hideDropdown(event);
                }
            }
        });

        $(document).on('keydown', (event) => {
            if (event.key === "Escape") {
                this.hideDropdown(event);
            }
        });
    }

    hideDropdown(event) {
        event.preventDefault();
        this.dropdown.hide();
    }

    displayDropdown(event) {
        event.preventDefault();
        if (!this.translatedPlaceholdersUrl) {
            throw new Error('No URL found to load placeholders');
        } else {
            $.ajax({
                url: this.translatedPlaceholdersUrl,
            }).then(placeholders => {
                    this.dropdown.replaceWith(this.createDropdown(placeholders));
                    this.dropdown = $(`#${this.dropdownId}`);
                }
            );
        }
    }

    /**
     * Create placeholders dropdown
     *
     * @param placeholders
     */
    createDropdown(placeholders) {
        const $list = $(`<ul id="${this.dropdownId}" class="dropdown-menu show card-columns position-absolute clearfix" x-placement="top-start" />`);
        Object.entries(placeholders).forEach((item) => {
            $('<li />', {class: 'dropdown-item', 'data-value': item[0], text: item[1]})
                .on('click', (event) => this.insertPlaceholder(event))
                .appendTo($list);
        });

        return $list;
    }

    /**
     * Insert clicked placeholder in the text input
     *
     * @param event
     */
    insertPlaceholder(event) {
        const placeholder = event.target.dataset.value;
        const cursorPos = this.textInput.prop('selectionStart');
        const text = this.textInput.val();
        const textBefore = text.substring(0, cursorPos);
        const textAfter = text.substring(cursorPos, text.length);
        this.dropdown.hide();
        this.textInput.val(`${textBefore}\{\{ ${placeholder} }}${textAfter}`).focus();
    }
}

export default PlaceholdersDropdown;
