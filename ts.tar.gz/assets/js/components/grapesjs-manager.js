import grapesjs from 'grapesjs';
import 'grapesjs-preset-webpage';
import isUuid from 'uuid-validate';

const plugins = [];
plugins.push('gjs-preset-webpage');

class grapeJsManager {

    constructor(form, options) {
        this.form = form;
        this.options = options;
        this.templateId = this.form.dataset.templateId;
        this.items = this.getTemplateItems(this.templateId);
        this.editor = {};
    }

    /**
     * Get the prefix for local storage items related to a given template
     *
     * @param id
     */
    static getLocalStoragePrefix(id) {
        return `gjs-${id}-`;
    }

    /**
     * Get the template ID related to a given local storage item
     *
     * @param localStorageItemKey
     */
    static getTemplateIdFromLocalStorageItem(localStorageItemKey) {
        const regexp = '^gjs-(.*)-(html|components|css|styles|assets)$';
        const id = localStorageItemKey.match(regexp);
        if (id && id[1]) {
            return id[1]
        }
        return null;
    }

    /**
     * Check if temporary items exist in local storage and return related ID if so
     *
     * @returns {*}
     */
    static getTemporaryTemplateIdFromLocalStorage() {
        for (let item of Object.entries(localStorage)) {
            const id = grapeJsManager.getTemplateIdFromLocalStorageItem(item[0]);
            if (isUuid(id)) {
                return id;
            }
        }

        return null;
    }

    /**
     * Add specific behavior to placeholders :
     * - remove placeholder on double click
     */
    static activatePlaceholdersBehavior() {
        const placeholders = window.frames[0].document.getElementsByClassName('placeholder');
        if (placeholders.length) {
            for (let placeholder of placeholders) {
                placeholder.contentEditable = false;
                placeholder.addEventListener('dblclick', () => {
                    placeholder.remove();
                })
            }
        }
    }

    init() {
        this.editor = grapesjs.init({
            height: this.options.height,
            width: '100%',
            container: `#${this.options.container}`,
            overflow: 'hidden',
            plugins: plugins,
            styleManager: {
                clearProperties: 1,
            },
            storageManager: {
                id: grapeJsManager.getLocalStoragePrefix(this.templateId),
                type: 'local',
                autosave: true,
                autoload: true,
                stepsBeforeSave: 0,
                storeComponents: true,
                storeStyles: true,
                storeHtml: true,
                storeCss: true,
            },
        });

        this.loadEditorDropdownMenu(this.options.translatedPlaceholdersUrl, 'insert_placeholder', 'placeholder-select')
            .loadEditorDropdownMenu(this.options.translatedCustomVariablesUrl, 'insert_custom_variable', 'custom-variable-select');

        grapeJsManager.activatePlaceholdersBehavior();

        this.configureDomComponents()
            .configureBlockManager()
            .configureStyleManager()
            .configureCssComposer();

        const id = `${grapeJsManager.getLocalStoragePrefix(this.templateId)}html`;

        if (localStorage.getItem(id) === null) {
            this.copyDataFromFormToLocalStorage();
        } else {
            this.updateCustomVariablesNames();
        }

        return this.editor;
    }

    /**
     * Get the prefix for form fields
     */
    getFormPrefix() {
        return this.form.name + '_htmlContentFields_';
    }

    /**
     * Set mapping between form elements and local storage items for a given template
     *
     * @param templateId
     */
    getTemplateItems(templateId) {
        const baseItems = {
            html: 'html',
            htmlMetadata: 'components',
            css: 'css',
            cssMetadata: 'styles',
            assets: 'assets',
        };
        const localStoragePrefix = grapeJsManager.getLocalStoragePrefix(templateId);
        const formPrefix = this.getFormPrefix();

        const items = {};
        Object.entries(baseItems).forEach((baseItem) => {
            items[formPrefix.concat(baseItem[0])] = localStoragePrefix.concat(baseItem[1]);
        });

        return items;
    }

    /**
     * Copy form fields values to local storage items
     *
     * In case of a new template, check if there are already temporary items in local storage. If so, use these items for the current template.
     * Set localstorage data only if there is no local storage data for the current template or if the template is a copy
     */
    copyDataFromFormToLocalStorage() {
        if (isUuid(this.templateId) && this.form.dataset.copy === "0") {
            const temporaryId = grapeJsManager.getTemporaryTemplateIdFromLocalStorage();
            if (temporaryId) {
                this.moveLocalStorageItems(temporaryId, this.templateId);
            }
        } else if (!Object.keys(localStorage).includes(grapeJsManager.getLocalStoragePrefix().concat('html')) || this.form.dataset.copy) {
            const items = this.items;
            if ((Object.values(items)[0]).includes('gjs-cv')) {
                Object.entries(items).map((item) => {
                    const formItem = document.getElementById(item[0]);
                    const localValue = item[1];
                    localStorage.removeItem(item[1]);
                    localStorage.setItem(localValue, formItem.value);
                });
            } else {
                this.updateCustomVariablesNames(true);
            }
        }
        this.editor.load();

        return this;
    }

    /**
     * Convert custom variables names from their store names to their display names.
     * Ex. : {{ cv15 }} to {{ cv15_current_variable_name }}
     */
    updateCustomVariablesNames(editorLoad = false) {
        const items = this.items;
        $.ajax({
            url: this.options.displayCustomVariablesUrl,
        }).then((customVariablesDisplayNames) => {
            Object.entries(items)
                .forEach(function (item) {
                    let localValue = document.getElementById(item[0]).value;
                    Object.entries(customVariablesDisplayNames).forEach(function (el) {
                        if (localValue.match("{{ " + el[0] + " }}")) {
                            const regexp = new RegExp("{{ " + el[0] + " }}", "g");
                            localValue = localValue.replace(regexp, '{{ ' + el[1] + ' }}');
                        }
                    });

                    localStorage.setItem(item[1], localValue);
                });

            if (editorLoad) {
                this.editor.load();
            }
        });
    }

    /**
     * Copy local storage items to form fields values
     */
    copyDataFromLocalStorageToForm() {
        Object.entries(this.items).forEach((item) => {
            const localValue = localStorage.getItem(item[1]);
            const formItem = document.getElementById(item[0]);
            formItem.value = localValue;
            localStorage.removeItem(item[1]);
        });
        this.updateCustomVariablesNames();

        return this;
    }

    /**
     * Get items related to an given template
     *
     * @param templateId
     */
    getTemplateLocalStorageItems(templateId) {
        return this.getTemplateItems(templateId);
    }

    /**
     * Replace values of local storage items related to a template by values of another and remove the latter
     *
     * @param from
     * @param to
     */
    moveLocalStorageItems(from, to) {
        const fromItems = this.getTemplateLocalStorageItems(from);
        const toItems = this.getTemplateLocalStorageItems(to);
        for (let element of Object.entries(fromItems)) {
            localStorage.setItem(toItems[element[0]], localStorage.getItem(element[1]));
            localStorage.removeItem(element[1]);
        }
    }

    /**
     * Load list of elements to populate a dropdown menu in editor
     */
    loadEditorDropdownMenu(url, translation, id) {
        if (url) {
            $.ajax({
                url: url,
            }).then(elements => {
                const select = this.buildDropdownMenu(elements, translation, id);
                this.editor.RichTextEditor.add(translation, {
                    icon: select,
                    event: 'change',
                    result: (rte, action) => {
                        rte.insertHTML(`<span class="placeholder">${action.btn.firstChild.value}</span>`);
                        grapeJsManager.activatePlaceholdersBehavior();
                    },
                    update: (rte, action) => {
                        action.btn.firstChild.value = "";
                        grapeJsManager.activatePlaceholdersBehavior();
                    }
                });
            });
        }

        return this;
    }

    /**
     * Create a select from elements
     *
     * @returns {string}
     * @param elements
     * @param translation
     * @param id
     */
    buildDropdownMenu(elements, translation, id) {
        let optionsHtml = `<option value="">${Translator.trans('editor.action.' + translation)}</option>`;
        Object.entries(elements).forEach((item) => {
            optionsHtml += `<option value="{{ ${item[0]} }}">${item[1]}</option>`;
        });

        return `<select id="${id}" class="gjs-field form-control-sm">${optionsHtml}</select>`;
    }

    /**
     * Block manager configuration
     */
    configureBlockManager() {
        const blockManager = this.editor.BlockManager;
        const blocksToRemove = ['textarea', 'h-navbar', 'countdown', 'form', 'input', 'select', 'button', 'label', 'checkbox', 'radio', 'link-block', 'quote', 'text-basic', 'map', 'video'];
        blocksToRemove.forEach(blockId => blockManager.remove(blockId));

        blockManager.add('table', {
            label: 'Table',
            category: 'Table',
            attributes: {
                class: 'fa fa-table'
            },
            content: {
                type: 'table',
                style: {height: 'auto', width: '100%'},
            }
        });
        blockManager.add('tbody', {
            label: 'Body',
            category: 'Table',
            attributes: {
                class: 'fa fa-th'
            },
            content: {
                type: 'tbody',
            }
        });
        blockManager.add('row', {
            label: 'Row',
            category: 'Table',
            attributes: {
                class: 'fa fa-bars'
            },
            content: {
                type: 'row',
            }
        });
        blockManager.add('cell', {
            label: 'Cell',
            category: 'Table',
            attributes: {
                class: 'fa fa-square'
            },
            content: {
                type: 'cell',
                style: {height: 'auto', width: '100%'},
            }
        });
        blockManager.add('thead', {
            label: 'Header',
            category: 'Table',
            attributes: {
                class: 'fa fa-heading'
            },
            content: {
                type: 'thead',
                columns: 6,
            }
        });
        blockManager.add('tfoot', {
            label: 'Footer',
            category: 'Table',
            attributes: {
                class: 'fa fa-shoe-prints'
            },
            content: {
                type: 'tfoot',
                columns: 6,
            }
        });

        return this;
    }

    /**
     * Dom components configuration
     */
    configureDomComponents() {
        const domComponents = this.editor.DomComponents;
        const originalTbody = domComponents.getType('tbody');
        domComponents.addType('tbody', {
            model: originalTbody.model.extend({
                defaults: Object.assign({}, originalTbody.model.prototype.defaults, {
                    columns: 6,
                    rows: 2
                })
            }),
        });

        return this;
    }

    /**
     * Style manager configuration
     */
    configureStyleManager() {
        const styleManager = this.editor.StyleManager;

        styleManager.addProperty('decorations', {
            name: 'Border top',
            property: 'border-top',
            type: 'composite',
            properties: [{
                name: 'Width',
                type: 'integer',
                units: ['px', 'em', 'rem'],
                property: 'border-top-width',
            }, {
                name: 'Style',
                type: 'select',
                property: 'border-top-style',
                options: [
                    {value: 'none'},
                    {value: 'solid'},
                    {value: 'dotted'},
                    {value: 'dashed'},
                    {value: 'double'},
                    {value: 'groove'},
                    {value: 'ridge'},
                    {value: 'inset'},
                    {value: 'outset'}
                ]
            }, {
                name: 'Color',
                type: 'color',
                property: 'border-top-color',
            }]
        });

        styleManager.addProperty('decorations', {
            name: 'Border bottom',
            property: 'border-bottom',
            type: 'composite',
            properties: [{
                name: 'Width',
                type: 'integer',
                units: ['px', 'em', 'rem'],
                property: 'border-bottom-width',
            }, {
                name: 'Style',
                type: 'select',
                property: 'border-bottom-style',
                options: [
                    {value: 'none'},
                    {value: 'solid'},
                    {value: 'dotted'},
                    {value: 'dashed'},
                    {value: 'double'},
                    {value: 'groove'},
                    {value: 'ridge'},
                    {value: 'inset'},
                    {value: 'outset'}
                ]
            }, {
                name: 'Color',
                type: 'color',
                property: 'border-bottom-color',
            }]
        });

        styleManager.addProperty('decorations', {
            name: 'Border left',
            property: 'border-left',
            type: 'composite',
            properties: [{
                name: 'Width',
                type: 'integer',
                units: ['px', 'em', 'rem'],
                property: 'border-left-width',
            }, {
                name: 'Style',
                type: 'select',
                property: 'border-left-style',
                options: [
                    {value: 'none'},
                    {value: 'solid'},
                    {value: 'dotted'},
                    {value: 'dashed'},
                    {value: 'double'},
                    {value: 'groove'},
                    {value: 'ridge'},
                    {value: 'inset'},
                    {value: 'outset'}
                ]
            }, {
                name: 'Color',
                type: 'color',
                property: 'border-left-color',
            }]
        });

        styleManager.addProperty('decorations', {
            name: 'Border right',
            property: 'border-right',
            type: 'composite',
            properties: [{
                name: 'Width',
                type: 'integer',
                units: ['px', 'em', 'rem'],
                property: 'border-right-width',
            }, {
                name: 'Style',
                type: 'select',
                property: 'border-right-style',
                options: [
                    {value: 'none'},
                    {value: 'solid'},
                    {value: 'dotted'},
                    {value: 'dashed'},
                    {value: 'double'},
                    {value: 'groove'},
                    {value: 'ridge'},
                    {value: 'inset'},
                    {value: 'outset'}
                ]
            }, {
                name: 'Color',
                type: 'color',
                property: 'border-right-color',
            }]
        });

        styleManager.addProperty('decorations', {
            name: 'Border collapse',
            property: 'border-collapse',
            type: 'select',
            default: 'collapse',
            list: [
                {
                    value: "collapse",
                }, {
                    value: "separate",
                },
                {
                    value: "initial",
                },
                {
                    value: "inherit",
                }
            ]

        });

        styleManager.addProperty('decorations', {
            name: 'Vertical align',
            property: 'vertical-align',
            type: 'select',
            default: 'baseline',
            list: [
                {
                    value: "baseline",
                }, {
                    value: "sub",
                },
                {
                    value: "super",
                },
                {
                    value: "text-top",
                },
                {
                    value: "text-bottom",
                },
                {
                    value: "middle",
                },
                {
                    value: "top",
                },
                {
                    value: "bottom",
                }
            ]

        });

        return this;
    }

    /**
     * Style manager configuration
     */
    configureCssComposer() {
        const cssComposer = this.editor.CssComposer;
        if (cssComposer.getClassRule('cell')) {
            cssComposer.getClassRule('cell').setStyle({display: "table-cell", height: "15px", 'min-height': '15px', width: "8%"});
        }

        return this;
    }
}

export default grapeJsManager;
